"""Reduced electrical model and independent operating-margin calculations.

Uses explicitly documented equations, not a vendor SPICE engine or sound model.
Only Python's standard library is needed for the numerical checks and CSV files.
"""
from pathlib import Path
import math
import csv
import json
from itertools import product

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'simulation/results'
VTH=3.0
KP=.16
BUZZ_R=5/.030
C_GATE=1e-9+60e-12

def gate_dc(vs,rprobe,rpull=10e6,rseries=100e3,leak_into_gate=0):
    rs=rprobe+rseries
    g=1/rpull+1/rs
    return (vs/rs+leak_into_gate)/g, C_GATE/g

def mos_current(vg,vd,threshold=VTH,kp=KP):
    overdrive=vg-threshold
    if overdrive<=0:return 0.
    vd=max(vd,0)
    return kp*(overdrive*vd-.5*vd*vd) if vd<overdrive else .5*kp*overdrive**2

def drain_dc(vs,vg,threshold=VTH):
    lo,hi=0.,vs
    for _ in range(70):
        mid=(lo+hi)/2
        if mos_current(vg,mid,threshold)>(vs-mid)/BUZZ_R:hi=mid
        else:lo=mid
    vd=(lo+hi)/2
    return vd,(vs-vd)/BUZZ_R

def dump_csv(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    OUT.mkdir(exist_ok=True,parents=True)
    checks=[]
    def check(name,ok,value):checks.append({'name':name,'passed':bool(ok),'result':value})
    sweep=[]
    for i in range(181):
        rp=10**(3+i/20)
        vg,tau=gate_dc(5,rp)
        vd,current=drain_dc(5,vg)
        sweep.append(dict(probe_ohm=rp,gate_v=vg,buzzer_proxy_v=5-vd,load_proxy_ma=current*1e3,tau_ms=tau*1e3))
    dump_csv('probe-resistance-sweep.csv',sweep)
    trajectory=[];vg=0.;dt=.00005
    for i in range(5001):
        t=i*dt
        wet=.05<=t<.15
        rp=100e3 if wet else 1e12
        final,tau=gate_dc(5,rp)
        # Exact linear RC state update; drain state is quasi-static.
        if i:vg=final+(vg-final)*math.exp(-dt/tau)
        vd,current=drain_dc(5,vg)
        trajectory.append(dict(time_s=t,wet=int(wet),gate_v=vg,buzzer_proxy_v=5-vd,load_proxy_ma=current*1e3))
    dump_csv('wet-dry-transient.csv',trajectory)
    wet=trajectory[2000];dry=trajectory[4800]
    check('Wet RC trajectory reaches gate drive >=4.5 V',wet['gate_v']>=4.5,wet)
    check('Dry RC trajectory returns below 0.2 V',dry['gate_v']<.2,dry)
    corners=[]
    for vs,rpull,rseries,leak,rp in product([4.75,5.25],[9.5e6,10.5e6],[95e3,105e3],[-10e-9,10e-9],[0.,100e3]):
        vg,tau=gate_dc(vs,rp,rpull,rseries,leak)
        # Independent calculation uses the datasheet bound, not the illustrative MOS model.
        buz_min=vs-.030*5.3
        corners.append(dict(supply_v=vs,rpull_ohm=rpull,rseries_ohm=rseries,leak_into_gate_a=leak,probe_ohm=rp,gate_v=vg,buzzer_min_v_at_30ma=buz_min))
    dump_csv('wet-operating-corners.csv',corners)
    gate_min=min(c['gate_v'] for c in corners)
    buzz_min=min(c['buzzer_min_v_at_30ma'] for c in corners)
    check('All wet operating corners meet 4.5 V gate-drive condition',gate_min>=4.5,{'minimum_gate_v':gate_min,'corners':len(corners)})
    check('Buzzer lower voltage bound stays above its 3 V operating minimum',buzz_min>=3,{'minimum_buzzer_v':buzz_min,'assumed_current_a':.030,'rds_bound_ohm':5.3})
    check('Supply upper bound below buzzer 7 V operating maximum',5.25<7,5.25)
    check('MOSFET load current below 200 mA rating at stated 25 C conditions',.030<.2,.030)
    check('MOSFET conduction loss at 30 mA below 10 mW',.030**2*5.3<.010,.030**2*5.3)
    dry_gate_max=max(gate_dc(vs,1e12,rp,rs,10e-9)[0] for vs,rp,rs in product([4.75,5.25],[9.5e6,10.5e6],[95e3,105e3]))
    check('Dry gate including +/-10 nA input leakage remains below 0.2 V',dry_gate_max<.2,dry_gate_max)
    # Include 10 Mohm voltmeter loading explicitly, since it matters at this impedance.
    meter_gate=gate_dc(4.75,100e3,1/(1/9.5e6+1/10e6),105e3,-10e-9)[0]
    check('Wet gate with a 10 Mohm meter still exceeds 4.5 V in the stated envelope',meter_gate>=4.5,meter_gate)
    # Analytical inverse RC crossing time after probes open.
    dry_final,dry_tau=gate_dc(5,1e12)
    initial=gate_dc(5,100e3)[0]
    release=dry_tau*math.log((initial-dry_final)/(.2-dry_final))
    check('Nominal dry gate falls below 0.2 V within 50 ms',release<.05,{'seconds':release})
    report={'status':'PASS' if all(c['passed'] for c in checks) else 'FAIL','model_kind':'Reduced analytical/numerical RC and illustrative level-1 MOSFET model. Not a vendor model, native SPICE execution, acoustic test, or hardware validation.','assumptions':{'supply_v':[4.75,5.25],'wet_probe_ohm':[0,100000],'dry_probe_ohm':1e12,'resistor_tolerance_fraction':.05,'gate_leakage_a':[-1e-8,1e-8],'gate_capacitance_f':C_GATE,'illustrative_mos_threshold_v':VTH,'illustrative_mos_kp_a_per_v2':KP,'buzzer_proxy_resistance_ohm':BUZZ_R,'independent_rds_bound_ohm':5.3,'current_for_bound_a':.030,'datasheet_electrical_bound_temperature_c':25},'checks':checks}
    (ROOT/'verification/model-checks.json').write_text(json.dumps(report,indent=2)+'\n')
    for c in checks:print(('PASS' if c['passed'] else 'FAIL'),c['name'])
    print('Minimum wet gate:',round(gate_min,6),'V; minimum buzzer voltage bound:',buzz_min,'V')
    raise SystemExit(report['status']!='PASS')

if __name__=='__main__':main()
