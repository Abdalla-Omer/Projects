"""Fault injection checks for the independent board verifier."""
from pathlib import Path
import tempfile
import unittest
from verify_design import verify, ROOT
from kicad_sexpr import parse, patch

class VerifierTests(unittest.TestCase):
    def run_board(self,text):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'injected.kicad_pcb';p.write_text(text)
            return verify(p,ROOT/'hardware/water-alarm.kicad_sch')
    def test_corrected_design_passes(self):
        text=(ROOT/'hardware/water-alarm.kicad_pcb').read_text()
        self.assertEqual(self.run_board(text)['status'],'PASS')
    def test_physical_supply_short_is_detected(self):
        text=(ROOT/'hardware/water-alarm.kicad_pcb').read_text()
        text=text.rstrip()[:-1]+'\n(segment (start 12 17) (end 12 10.7) (width 0.5) (layer "F.Cu") (net "VCC")))\n'
        report=self.run_board(text)
        self.assertIn('Conservative 0.20 mm copper clearance',report['failed'])
    def test_unrouted_ground_is_detected(self):
        text=(ROOT/'hardware/water-alarm.kicad_pcb').read_text();root=parse(text)
        segment=next(n for n in root.children('segment') if n.value('net')=='GND' and n.values('start')==['12','10.7'])
        report=self.run_board(patch(text,[(segment.start,segment.end,'')]))
        self.assertIn('Physical copper connectivity including both layers',report['failed'])
if __name__=='__main__':unittest.main()
