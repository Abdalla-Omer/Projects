"""Run genuine KiCad 10 ERC/DRC and ngspice. Never silently substitutes a model."""
from pathlib import Path
import subprocess
import shutil
import json
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'verification'
def main():
    OUT.mkdir(exist_ok=True)
    missing=[tool for tool in ['kicad-cli','ngspice'] if not shutil.which(tool)]
    if missing:
        report={'status':'NOT RUN','missing_tools':missing,'reason':'Native tools unavailable; no native ERC/DRC/SPICE pass is claimed.'}
        (OUT/'native-status.json').write_text(json.dumps(report,indent=2)+'\n')
        print(report['reason'],', '.join(missing));return 2
    version=subprocess.run(['kicad-cli','version'],capture_output=True,text=True,check=True).stdout.strip()
    if not re.search(r'\b10\.',version):
        print('KiCad 10.x is required for the supplied file formats. Found:',version);return 2
    commands=[
      ['kicad-cli','sch','erc','--format','json','--severity-all','--output','verification/kicad-erc.json','hardware/water-alarm.kicad_sch'],
      ['kicad-cli','sch','erc','--format','json','--severity-error','--exit-code-violations','--output','verification/kicad-erc-errors.json','hardware/water-alarm.kicad_sch'],
      ['kicad-cli','pcb','drc','--schematic-parity','--format','json','--severity-all','--output','verification/kicad-drc.json','hardware/water-alarm.kicad_pcb'],
      ['kicad-cli','pcb','drc','--schematic-parity','--format','json','--severity-error','--exit-code-violations','--output','verification/kicad-drc-errors.json','hardware/water-alarm.kicad_pcb'],
      ['ngspice','-b','-o','verification/ngspice.log','simulation/water-alarm.cir'],
    ]
    results=[]
    for command in commands:
        r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
        results.append({'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
        print(' '.join(command),'->',r.returncode)
    log=(OUT/'ngspice.log').read_text(errors='replace') if (OUT/'ngspice.log').exists() else ''
    measured={}
    for name in ['gate_wet','gate_dry']:
        m=re.search(r'\b'+name+r'\s*=\s*([\deE+.\-]+)',log)
        if m:measured[name]=float(m.group(1))
    values_ok=measured.get('gate_wet',-1)>=4.5 and measured.get('gate_dry',1)<.2
    # Full reports preserve warnings; separate error-only reports control the failure gate.
    passed=all(r['exit_code']==0 for r in results) and values_ok
    report={'status':'PASS' if passed else 'FAIL','kicad_version':version,'results':results,'ngspice_gate_measurements_v':measured,'ngspice_checks_passed':values_ok,'scope':'Native ERC/DRC error gate and illustrative ngspice model; inspect all warnings. No hardware validation.'}
    (OUT/'native-status.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if passed else 1
if __name__=='__main__':sys.exit(main())
