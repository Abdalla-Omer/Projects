"""Small read-only parser for KiCad S-expressions, preserving source spans."""
from __future__ import annotations
import json
import re
from dataclasses import dataclass
from pathlib import Path

@dataclass
class Node:
    items: list
    start: int
    end: int
    @property
    def key(self):
        return self.items[0] if self.items else None
    def children(self, key):
        return [v for v in self.items if isinstance(v, Node) and v.key == key]
    def child(self, key):
        return next(iter(self.children(key)), None)
    def values(self, key):
        n = self.child(key)
        return n.items[1:] if n else []
    def value(self, key, default=None):
        vals = self.values(key)
        return vals[0] if vals else default
    def properties(self):
        return {n.items[1]: n.items[2] for n in self.children('property') if len(n.items) >= 3}

def parse(text):
    tokens = list(re.finditer(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+', text))
    def one(i):
        token = tokens[i]
        s = token.group()
        if s == '(':
            items = []
            j = i + 1
            while tokens[j].group() != ')':
                item, j = one(j)
                items.append(item)
            return Node(items, token.start(), tokens[j].end()), j + 1
        if s == ')':
            raise ValueError('Unexpected close parenthesis')
        return (json.loads(s) if s.startswith('"') else s), i + 1
    result, end = one(0)
    assert end == len(tokens)
    return result

def load(path):
    return parse(Path(path).read_text())

def patch(text, edits):
    """Apply (start, end, replacement) edits without reformatting untouched data."""
    previous = len(text) + 1
    for start, end, replacement in sorted(edits, reverse=True):
        assert end <= previous, 'Overlapping edits'
        text = text[:start] + replacement + text[end:]
        previous = start
    parse(text)
    return text

if __name__ == '__main__':
    import sys
    for name in sys.argv[1:]:
        root = load(name)
        print('\nFILE', Path(name).name, 'VERSION', root.value('version'))
        if root.key == 'kicad_sch':
            lib = {s.items[1]: s for s in root.child('lib_symbols').children('symbol')}
            for s in root.children('symbol'):
                print('SYMBOL', json.dumps({'props':s.properties(), 'at':s.values('at'), 'mirror':s.values('mirror'), 'id':s.value('lib_id'), 'uuid':s.value('uuid')}))
                definition=lib[s.value('lib_id')]
                for sub in definition.children('symbol'):
                    for pin in sub.children('pin'):
                        print(' PIN',pin.value('number'),pin.value('name'),pin.values('at'))
            for kind in ['wire','junction','label','global_label','no_connect']:
                for n in root.children(kind):
                    if kind=='wire':
                        print('WIRE',[v.items[1:] for v in n.child('pts').children('xy')])
                    else: print(kind,n.items[1] if kind.endswith('label') else '',n.values('at'))
        else:
            for fp in root.children('footprint'):
                print('FOOTPRINT',fp.items[1],json.dumps(fp.properties()),'AT',fp.values('at'))
                for p in fp.children('pad'):
                    print(' PAD',p.items[1:4], 'AT',p.values('at'),'SIZE',p.values('size'),'NET',p.values('net'),'FUNC',p.value('pinfunction'))
            for kind in ['segment','via','zone','gr_line','gr_rect','gr_arc']:
                for n in root.children(kind):
                    print(kind, {k:n.values(k) for k in ['start','end','mid','at','layer','net','width','clearance','min_thickness'] if n.child(k)})
