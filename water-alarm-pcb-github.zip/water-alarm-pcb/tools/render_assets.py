"""Create documentation previews directly from the KiCad geometry and model CSVs.

These are source-derived documentation drawings, not native KiCad screenshots.
Requires matplotlib only. The delivered repository includes the generated files.
"""
from pathlib import Path
import math
import csv
import json
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle
from matplotlib.collections import LineCollection
from kicad_sexpr import load, Node
from verify_design import global_pcb, xy, dist, rotate, copper_shapes

ROOT=Path(__file__).resolve().parents[1]
IMG=ROOT/'docs/images'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})

def save(fig,name):
    fig.savefig(IMG/(name+'.png'),dpi=180,bbox_inches='tight',facecolor=fig.get_facecolor())
    fig.savefig(IMG/(name+'.svg'),bbox_inches='tight',facecolor=fig.get_facecolor())
    plt.close(fig)

def pcb():
    root=load(ROOT/'hardware/water-alarm.kicad_pcb')
    fig,ax=plt.subplots(figsize=(9.8,8.5),facecolor='#f3f6f8')
    ax.set_facecolor('#f3f6f8')
    ax.add_patch(Rectangle((0,0),60,55,facecolor='#143e35',edgecolor='#22332e',lw=2,zorder=0))
    shapes,holes,_,_=copper_shapes(root)
    colors={'F.Cu':'#ee8c54','B.Cu':'#75bde6'}
    def capsule(a,b,r,color,z):
        if dist(a,b)<1e-8:ax.add_patch(Circle(a,r,facecolor=color,edgecolor='none',zorder=z));return
        theta=math.atan2(b[1]-a[1],b[0]-a[0])
        pts=[(a[0]+r*math.cos(t),a[1]+r*math.sin(t)) for t in np.linspace(theta+math.pi/2,theta+3*math.pi/2,20)]
        pts += [(b[0]+r*math.cos(t),b[1]+r*math.sin(t)) for t in np.linspace(theta-math.pi/2,theta+math.pi/2,20)]
        ax.add_patch(Polygon(pts,facecolor=color,edgecolor='none',zorder=z))
    for layer in ['B.Cu','F.Cu']:
        for s in root.children('segment'):
            if s.value('layer')!=layer:continue
            a,b=xy(s.values('start')),xy(s.values('end'))
            capsule(a,b,float(s.value('width'))/2,colors[layer],2 if layer=='B.Cu' else 3)
    for fp in root.children('footprint'):
        ref=fp.properties()['Reference']
        for g in fp.items:
            if not isinstance(g,Node) or g.value('layer')!='F.SilkS':continue
            style=dict(edgecolor='#e9efe8',facecolor='none',lw=.85,zorder=4)
            if g.key=='fp_line':
                a,b=[global_pcb(xy(g.values(k)),fp) for k in ['start','end']]
                ax.plot([a[0],b[0]],[a[1],b[1]],color='#e9efe8',lw=.85,zorder=4)
            elif g.key=='fp_circle':
                c=global_pcb(xy(g.values('center')),fp);r=dist(xy(g.values('center')),xy(g.values('end')))
                ax.add_patch(Circle(c,r,**style))
            elif g.key=='fp_rect':
                a,b=xy(g.values('start')),xy(g.values('end'))
                ax.add_patch(Polygon([global_pcb(v,fp) for v in [a,(b[0],a[1]),b,(a[0],b[1])]],**style))
            elif g.key=='fp_arc':
                # The supplied TO-92 outline includes a three-point arc.
                points=[global_pcb(xy(g.values(k)),fp) for k in ['start','mid','end']]
                a,b,c=map(np.array,points)
                mat=np.array([2*(b-a),2*(c-a)])
                if abs(np.linalg.det(mat))>1e-8:
                    center=np.linalg.solve(mat,np.array([b@b-a@a,c@c-a@a]));radius=np.linalg.norm(a-center)
                    t0,t1,t2=[math.atan2(*(v-center)[::-1]) for v in [a,b,c]]
                    positive=(t1-t0)%(2*math.pi)<(t2-t0)%(2*math.pi)
                    span=(t2-t0)%(2*math.pi) if positive else -((t0-t2)%(2*math.pi))
                    ts=np.linspace(t0,t0+span,60)
                    ax.plot(center[0]+radius*np.cos(ts),center[1]+radius*np.sin(ts),color='#e9efe8',lw=.85,zorder=4)
        for pn in fp.children('property'):
            if pn.items[1]=='Reference':
                x,y=global_pcb(xy(pn.values('at')),fp)
                ax.text(x,y,ref,color='#f2f5d4',ha='center',va='center',fontsize=9,weight='bold',zorder=7)
        for p in fp.children('pad'):
            c=global_pcb(xy(p.values('at')),fp)
            if p.items[2]=='np_thru_hole':
                ax.add_patch(Circle(c,max(xy(p.values('size')))/2,color='#f3f6f8',zorder=8));continue
            s=next(s for s in shapes if s.name==ref+'.'+p.items[1])
            if s.polygon:ax.add_patch(Polygon(s.points,facecolor='#d2b76e',edgecolor='#f4d590',lw=.6,zorder=5))
            else:
                a,b=s.points
                capsule(a,b,s.radius,'#d2b76e',5)
            drill=p.values('drill')
            if drill and drill[0]=='oval':
                w,h=float(drill[1]),float(drill[2]);r=min(w,h)/2;delta=(max(w,h)-min(w,h))/2
                pts=[(-delta,0),(delta,0)] if w>=h else [(0,-delta),(0,delta)]
                angle=float(fp.values('at')[2]) if len(fp.values('at'))>2 else 0
                pts=[rotate(v,-angle) for v in pts]
                capsule((c[0]+pts[0][0],c[1]+pts[0][1]),(c[0]+pts[1][0],c[1]+pts[1][1]),r,'#0d231f',6)
            else:ax.add_patch(Circle(c,float(drill[0])/2,facecolor='#0d231f',zorder=6))
    for n in root.children('gr_text'):
        x,y=xy(n.values('at'));size=float(n.child('effects').child('font').value('size'))
        ax.text(x,y,n.items[1],color='#ecf0d9',ha='center',va='center',fontsize=size*7,zorder=7)
    ax.text(0,-5.5,'WATER ALARM PCB',fontsize=19,weight='bold',color='#153e35')
    ax.text(0,-2.8,'Revision 1.1  /  60 × 55 mm  /  Two copper layers',fontsize=11,color='#56666b')
    ax.plot([1,4],[58,58],color=colors['F.Cu'],lw=3);ax.text(5,58,'Front copper',va='center',color='#435057')
    ax.plot([23,26],[58,58],color=colors['B.Cu'],lw=3);ax.text(27,58,'Back copper',va='center',color='#435057')
    ax.text(0,61.5,'Preview generated from the corrected KiCad file. Component outlines are shown.',fontsize=8,color='#647177')
    ax.set_xlim(-2,62);ax.set_ylim(63,-8);ax.set_aspect('equal');ax.axis('off')
    save(fig,'corrected-pcb')

def schematic():
    root=load(ROOT/'hardware/water-alarm.kicad_sch')
    lib={n.items[1]:n for n in root.child('lib_symbols').children('symbol')}
    fig,ax=plt.subplots(figsize=(12,10.5),facecolor='white')
    def line(points,color='#227455',width=1.1):
        ax.plot([p[0] for p in points],[p[1] for p in points],color=color,lw=width,zorder=2)
    for n in root.children('wire'):line([xy(v.items[1:]) for v in n.child('pts').children('xy')])
    for n in root.children('junction'):ax.add_patch(Circle(xy(n.values('at')),.4,color='#227455'))
    for n in root.children('label'):
        x,y=xy(n.values('at'));ax.text(x,y-.7,n.items[1],fontsize=8,color='#227455',va='bottom')
    for n in root.children('no_connect'):
        x,y=xy(n.values('at'));line([(x-.6,y-.6),(x+.6,y+.6)],'#9e3535');line([(x-.6,y+.6),(x+.6,y-.6)],'#9e3535')
    for s in root.children('symbol'):
        at=s.values('at');origin=xy(at);a=float(at[2]);definition=lib[s.value('lib_id')]
        def transform(p):
            x,y=rotate(p,a);return (origin[0]+x,origin[1]-y)
        for sub in definition.children('symbol'):
            for g in sub.items:
                if not isinstance(g,Node):continue
                if g.key=='polyline':line([transform(xy(v.items[1:])) for v in g.child('pts').children('xy')],'#8a3434')
                elif g.key=='rectangle':
                    aa,bb=xy(g.values('start')),xy(g.values('end'))
                    ax.add_patch(Polygon([transform(v) for v in [aa,(bb[0],aa[1]),bb,(aa[0],bb[1])]],facecolor='#fffdf0',edgecolor='#8a3434',lw=1))
                elif g.key=='circle':
                    ax.add_patch(Circle(transform(xy(g.values('center'))),float(g.value('radius')),fill=False,edgecolor='#8a3434',lw=1))
                elif g.key=='arc':
                    pts=[np.array(xy(g.values(k))) for k in ['start','mid','end']];aa,bb,cc=pts
                    mat=np.array([2*(bb-aa),2*(cc-aa)])
                    if abs(np.linalg.det(mat))>1e-8:
                        c=np.linalg.solve(mat,np.array([bb@bb-aa@aa,cc@cc-aa@aa]));r=np.linalg.norm(aa-c)
                        ts=[math.atan2(*(p-c)[::-1]) for p in pts]
                        positive=(ts[1]-ts[0])%(2*math.pi)<(ts[2]-ts[0])%(2*math.pi)
                        span=(ts[2]-ts[0])%(2*math.pi) if positive else -((ts[0]-ts[2])%(2*math.pi))
                        line([transform(tuple(c+r*np.array([math.cos(t),math.sin(t)]))) for t in np.linspace(ts[0],ts[0]+span,40)],'#8a3434')
                elif g.key=='pin':
                    p=xy(g.values('at'));angle=float(g.values('at')[2]);length=float(g.value('length'))
                    end=(p[0]+length*math.cos(math.radians(angle)),p[1]+length*math.sin(math.radians(angle)))
                    line([transform(p),transform(end)],'#8a3434',.85)
        for p in s.children('property'):
            if p.items[1] in ['Reference','Value','Label'] and not p.child('hide'):
                x,y=xy(p.values('at'));ax.text(x,y,p.items[2],fontsize=8,color='#303a45',va='center',weight='bold' if p.items[1]=='Reference' else 'normal')
    for n in root.children('text'):
        x,y=xy(n.values('at'));size=float(n.child('effects').child('font').value('size'))
        ax.text(x,y,n.items[1],fontsize=size*6,color='#263f4a',va='center',weight='bold' if size>1.3 else 'normal')
    ax.text(45,189,'Source-derived schematic preview • local project symbols and net labels • Rev 1.1',fontsize=8,color='#69777e')
    ax.set_xlim(38,200);ax.set_ylim(194,32);ax.set_aspect('equal');ax.axis('off')
    save(fig,'corrected-schematic')

def plots():
    def read(name):
        with (ROOT/'simulation/results'/name).open() as f:return [{k:float(v) for k,v in row.items()} for row in csv.DictReader(f)]
    rows=read('wet-dry-transient.csv');sweep=read('probe-resistance-sweep.csv')
    fig,axes=plt.subplots(1,2,figsize=(11.5,4.0),facecolor='white',layout='constrained')
    ax=axes[0];t=[r['time_s']*1000 for r in rows]
    ax.axvspan(50,150,color='#dceee6',label='Wet probes: 100 kΩ')
    ax.plot(t,[r['gate_v'] for r in rows],color='#17654b',lw=2,label='Gate voltage')
    ax.plot(t,[r['buzzer_proxy_v'] for r in rows],color='#c46c33',lw=1.7,label='Buzzer load proxy')
    ax.set(xlabel='Time (ms)',ylabel='Voltage (V)',title='Wet / dry response at 5 V',ylim=(-.1,5.4));ax.grid(alpha=.15);ax.legend(fontsize=8,loc='lower center')
    ax=axes[1];x=[r['probe_ohm'] for r in sweep]
    ax.semilogx(x,[r['gate_v'] for r in sweep],color='#17654b',lw=2,label='Gate voltage')
    ax.semilogx(x,[r['buzzer_proxy_v'] for r in sweep],color='#c46c33',lw=1.7,label='Buzzer load proxy')
    ax.axvspan(1e3,1e5,color='#dceee6');ax.axhline(4.5,color='#55768c',ls='--',lw=1,label='Datasheet drive condition')
    ax.set(xlabel='Probe resistance (Ω)',ylabel='Voltage (V)',title='Sensitivity depends on probe resistance',ylim=(-.1,5.4));ax.grid(alpha=.15);ax.legend(fontsize=8)
    fig.suptitle('Reduced electrical model — predictions, not bench measurements',fontsize=12,weight='bold')
    save(fig,'model-results')

def models():
    d=ROOT/'hardware/models';d.mkdir(exist_ok=True)
    def transform(center,geometry,color,rotation=''):
        return f'Transform {{ translation {center[0]/2.54} {center[1]/2.54} {center[2]/2.54} '+rotation+f' children [ Shape {{ appearance Appearance {{ material Material {{ diffuseColor {color} }} }} geometry {geometry} }} ] }}\n'
    def cylinder(radius,height,center,color):
        return transform(center,f'Cylinder {{ radius {radius/2.54} height {height/2.54} }}',color,'rotation 1 0 0 1.57079632679 ')
    def leads(xs,r=.3):return ''.join(cylinder(r,6,(x,0,-3),'.7 .7 .72') for x in xs)
    (d/'active-buzzer.wrl').write_text('#VRML V2.0 utf8\n# Approximate body only; dimensions in KiCad VRML 0.1-inch units.\n'+cylinder(6,9.5,(3.8,0,4.75),'.08 .09 .10')+cylinder(1.1,.05,(3.8,0,9.52),'.025 .025 .025')+leads([0,7.6]))
    cap=transform((2.5,0,3.5),f'Box {{ size {5/2.54} {2.5/2.54} {5/2.54} }}','.70 .44 .20')+leads([0,5],.25)
    (d/'ceramic-p5.wrl').write_text('#VRML V2.0 utf8\n# Approximate nonpolar capacitor body; match the real part before manufacture.\n'+cap)
    diode=transform((3.81,0,1.2),f'Cylinder {{ radius {1/2.54} height {4/2.54} }}','.65 .28 .12','rotation 0 0 1 1.57079632679 ')+leads([0,7.62],.22)
    (d/'diode-do35.wrl').write_text('#VRML V2.0 utf8\n# Approximate axial diode body.\n'+diode)

if __name__=='__main__':
    IMG.mkdir(exist_ok=True,parents=True)
    models();pcb();schematic();plots()
    print('Created corrected PCB/schematic previews, model plots and local approximate 3D bodies.')
