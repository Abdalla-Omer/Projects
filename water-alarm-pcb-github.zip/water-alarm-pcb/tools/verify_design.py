"""Independent schematic/PCB topology and conservative copper-geometry checks.

This supplements, and does not impersonate, KiCad ERC/DRC. No third-party modules.
"""
from pathlib import Path
from dataclasses import dataclass
import math
import json
import argparse
from itertools import combinations
from kicad_sexpr import load, Node

ROOT=Path(__file__).resolve().parents[1]
EPS=1e-6
EXPECTED={
 'VCC':{'J1.1','J2.1','BZ1.1','D1.1','C2.1'},
 'GND':{'J1.2','Q1.1','R1.2','C1.2','C2.2'},
 'SENSE':{'J2.2','R2.1'},
 'GATE':{'R2.2','R1.1','C1.1','Q1.2'},
 'BUZZER_NEG':{'BZ1.2','Q1.3','D1.2'},
}
def xy(v): return tuple(map(float,v[:2]))
def dist(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
def rotate(p,angle):
    c,s=math.cos(math.radians(angle)),math.sin(math.radians(angle))
    return (c*p[0]-s*p[1],s*p[0]+c*p[1])
def global_pcb(p,fp):
    at=fp.values('at'); origin=xy(at); a=float(at[2]) if len(at)>2 else 0
    r=rotate(p,-a)
    return (origin[0]+r[0],origin[1]+r[1])
def on_segment(p,a,b):
    return abs((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))<EPS and min(a[0],b[0])-EPS<=p[0]<=max(a[0],b[0])+EPS and min(a[1],b[1])-EPS<=p[1]<=max(a[1],b[1])+EPS
def point_segment(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1]; l=dx*dx+dy*dy
    if l<EPS*EPS:return dist(p,a)
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/l))
    return dist(p,(a[0]+t*dx,a[1]+t*dy))
def seg_distance(a,b,c,d):
    def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    if (cross(a,b,c)*cross(a,b,d)<0 and cross(c,d,a)*cross(c,d,b)<0) or any(on_segment(p,u,v) for p,u,v in [(a,c,d),(b,c,d),(c,a,b),(d,a,b)]):return 0.
    return min(point_segment(a,c,d),point_segment(b,c,d),point_segment(c,a,b),point_segment(d,a,b))
def inside(p,poly):
    signs=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        v=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
        if abs(v)>EPS:signs.append(v>0)
    return not signs or all(signs) or not any(signs)
@dataclass
class Shape:
    name:str
    net:str
    layers:set
    points:list
    radius:float=0
    polygon:bool=False
    pad:bool=False
    def edges(self):return list(zip(self.points,self.points[1:]+self.points[:1])) if self.polygon else [(self.points[0],self.points[-1])]
def clearance(a,b):
    if a.polygon and any(inside(p,a.points) for p in b.points):return -b.radius
    if b.polygon and any(inside(p,b.points) for p in a.points):return -a.radius
    return min(seg_distance(x,y,u,v) for x,y in a.edges() for u,v in b.edges())-a.radius-b.radius
class UF:
    def __init__(self,n):self.p=list(range(n))
    def find(self,a):
        while self.p[a]!=a:self.p[a]=self.p[self.p[a]];a=self.p[a]
        return a
    def join(self,a,b):self.p[self.find(a)]=self.find(b)

def schematic_nets(root):
    library={s.items[1]:s for s in root.child('lib_symbols').children('symbol')}
    wires=[tuple(xy(p.items[1:]) for p in n.child('pts').children('xy')) for n in root.children('wire')]
    terminals=[]
    for s in root.children('symbol'):
        ref=s.properties()['Reference']; at=s.values('at'); origin=xy(at); a=float(at[2]) if len(at)>2 else 0
        mir=s.value('mirror')
        for sub in library[s.value('lib_id')].children('symbol'):
            for p in sub.children('pin'):
                x,y=xy(p.values('at'))
                if mir=='y':x=-x
                if mir=='x':y=-y
                x,y=rotate((x,y),a)
                terminals.append((ref+'.'+p.value('number'),(round(origin[0]+x,6),round(origin[1]-y,6))))
    labels=[(n.items[1],xy(n.values('at'))) for key in ['label','global_label'] for n in root.children(key)]
    # Power symbols are global labels even when the original contains no explicit labels.
    for s in root.children('symbol'):
        if s.value('lib_id') in ['power:VCC','power:GND']:
            labels.append((s.properties()['Value'],xy(s.values('at'))))
    points=list(dict.fromkeys([p for w in wires for p in w]+[p for _,p in terminals]+[p for _,p in labels]))
    ids={p:i for i,p in enumerate(points)};uf=UF(len(points))
    for a,b in wires:
        for p in points:
            if on_segment(p,a,b):uf.join(ids[a],ids[p])
    label_id={}
    for name,p in labels:
        if name in label_id:uf.join(ids[p],label_id[name])
        label_id[name]=ids[p]
    groups={}
    for name,p in terminals:
        if not name.startswith('#'):groups.setdefault(uf.find(ids[p]),set()).add(name)
    labelled={}
    for name,p in labels:labelled.setdefault(uf.find(ids[p]),set()).add(name)
    return [{'pins':sorted(pins),'labels':sorted(labelled.get(k,[]))} for k,pins in groups.items()]

def copper_shapes(board):
    shapes=[];holes=[];padnets={}; footprints={}
    for fp in board.children('footprint'):
        ref=fp.properties()['Reference'];footprints[ref]=fp
        for p in fp.children('pad'):
            number=p.items[1];center=global_pcb(xy(p.values('at')),fp)
            size=xy(p.values('size')); shape=p.items[3]
            if p.items[2]=='np_thru_hole':
                holes.append((ref,center,max(size)/2));continue
            name=ref+'.'+number;net=p.value('net')
            if net:padnets.setdefault(net,set()).add(name)
            else:net='NC:'+name
            # This design uses only 0/180 degree footprints. Conservative rectangles
            # deliberately overestimate roundrect copper rather than hide clearances.
            a=float(fp.values('at')[2]) if len(fp.values('at'))>2 else 0
            ang=float(p.values('at')[2]) if len(p.values('at'))>2 else a
            layers=set(p.values('layers'))
            layers={'F.Cu','B.Cu'} if '*.Cu' in layers else layers&{'F.Cu','B.Cu'}
            if shape in ['rect','roundrect']:
                pts=[]
                for x,y in [(-size[0]/2,-size[1]/2),(size[0]/2,-size[1]/2),(size[0]/2,size[1]/2),(-size[0]/2,size[1]/2)]:
                    x,y=rotate((x,y),-ang);pts.append((center[0]+x,center[1]+y))
                shapes.append(Shape(name,net,layers,pts,polygon=True,pad=True))
            else:
                radius=min(size)/2; delta=(max(size)-min(size))/2
                ends=[(-delta,0),(delta,0)] if size[0]>=size[1] else [(0,-delta),(0,delta)]
                pts=[]
                for e in ends:
                    x,y=rotate(e,-ang);pts.append((center[0]+x,center[1]+y))
                shapes.append(Shape(name,net,layers,pts,radius,pad=True))
    for i,s in enumerate(board.children('segment')):
        shapes.append(Shape('track'+str(i),s.value('net'),{s.value('layer')},[xy(s.values('start')),xy(s.values('end'))],float(s.value('width'))/2))
    return shapes,holes,padnets,footprints

def verify(boardpath,schpath):
    board=load(boardpath);sch=load(schpath); errors=[];checks=[]
    def check(name,ok,detail):
        checks.append({'name':name,'passed':bool(ok),'detail':detail})
        if not ok:errors.append(name)
    groups=schematic_nets(sch)
    actual=[set(g['pins']) for g in groups if g['pins']!=['J1.3']]
    expected=list(EXPECTED.values())
    check('Schematic topology',sorted(map(sorted,actual))==sorted(map(sorted,expected)),groups)
    anchors=[]
    for n in sch.items:
        if not isinstance(n,Node):continue
        if n.key in ['symbol','label','global_label','junction','no_connect']:anchors.append(xy(n.values('at')))
        elif n.key=='wire':anchors.extend(xy(p.items[1:]) for p in n.child('pts').children('xy'))
    offgrid=[p for p in anchors if any(abs(v/1.27-round(v/1.27))>EPS for v in p)]
    check('Schematic connection anchors on 1.27 mm grid',not offgrid,offgrid)
    for net,pins in EXPECTED.items():
        group=next((g for g in groups if set(g['pins'])==pins),None)
        check('Schematic label '+net,group is not None and group['labels']==[net],group)
    shapes,holes,padnets,footprints=copper_shapes(board)
    check('Schematic to PCB net agreement',padnets==EXPECTED,{k:sorted(v) for k,v in padnets.items()})
    # All footprint symbols must remain tied to the matching schematic instance.
    schids={s.properties()['Reference']:s.value('uuid') for s in sch.children('symbol') if not s.properties()['Reference'].startswith('#')}
    mismatches=[r for r,i in schids.items() if footprints.get(r) is None or footprints[r].value('path')!='/'+i or footprints[r].properties()['Value']!=next(s.properties()['Value'] for s in sch.children('symbol') if s.properties()['Reference']==r)]
    check('Footprint instance and value agreement',not mismatches,mismatches)
    allids=[]
    def collect(n):
        if n.key=='uuid':allids.append(n.items[1])
        for c in n.items:
            if isinstance(c,Node):collect(c)
    collect(board)
    check('Unique PCB object IDs',len(allids)==len(set(allids)),{'objects_with_ids':len(allids)})
    uf=UF(len(shapes));violations=[];minimum=math.inf
    for (i,a),(j,b) in combinations(enumerate(shapes),2):
        if not a.layers&b.layers:continue
        gap=clearance(a,b)
        if a.net==b.net:
            if gap<=EPS:uf.join(i,j)
        else:
            minimum=min(minimum,gap)
            if gap<.2-EPS:violations.append({'a':a.name,'b':b.name,'gap_mm':round(gap,6)})
    check('Conservative 0.20 mm copper clearance',not violations,{'minimum_mm':round(minimum,6),'violations':violations})
    disconnected={}
    for net in EXPECTED:
        members=[i for i,s in enumerate(shapes) if s.net==net]
        components={uf.find(i) for i in members}
        if len(components)!=1:disconnected[net]=len(components)
    check('Physical copper connectivity including both layers',not disconnected,disconnected)
    rectangles=[n for n in board.children('gr_rect') if n.value('layer')=='Edge.Cuts']
    other_edges=[n for n in board.items if isinstance(n,Node) and n.key in ['gr_line','gr_arc','gr_poly'] and n.value('layer')=='Edge.Cuts']
    outline_ok=len(rectangles)==1 and not other_edges and xy(rectangles[0].values('start'))==(0.,0.) and xy(rectangles[0].values('end'))==(60.,55.)
    check('One closed 60 x 55 mm board outline',outline_ok,{'rectangles':len(rectangles),'other_edges':len(other_edges)})
    edge_errors=[]
    for s in shapes:
        for x,y in s.points:
            margin=min(x,y,60-x,55-y)-s.radius
            if margin<.5-EPS:edge_errors.append(s.name)
    check('Copper to board edge at least 0.50 mm',not edge_errors,sorted(set(edge_errors)))
    hole_errors=[]
    for ref,p,r in holes:
        hole=Shape(ref,'HOLE',{'F.Cu','B.Cu'},[p,p],r)
        for s in shapes:
            gap=clearance(hole,s)
            if gap<.25-EPS:hole_errors.append({'hole':ref,'copper':s.name,'gap_mm':gap})
    check('Nonplated mounting holes clear of copper',not hole_errors,hole_errors)
    courtyards=[]
    for ref,fp in footprints.items():
        graphics=[n for n in fp.items if isinstance(n,Node) and n.value('layer')=='F.CrtYd']
        points=[]
        for g in graphics:
            if g.key=='fp_circle':
                c=global_pcb(xy(g.values('center')),fp);r=dist(xy(g.values('center')),xy(g.values('end')))
                courtyards.append(Shape(ref,'COURTYARD',set(),[c,c],r))
            elif g.key=='fp_rect':
                a,b=xy(g.values('start')),xy(g.values('end'))
                points.extend(global_pcb(v,fp) for v in [a,b,(a[0],b[1]),(b[0],a[1])])
            elif g.key=='fp_line':points.extend(global_pcb(xy(g.values(k)),fp) for k in ['start','end'])
        if points:
            x0,y0=min(v[0] for v in points),min(v[1] for v in points)
            x1,y1=max(v[0] for v in points),max(v[1] for v in points)
            courtyards.append(Shape(ref,'COURTYARD',set(),[(x0,y0),(x1,y0),(x1,y1),(x0,y1)],polygon=True))
    courtyard_overlap=[];courtyard_edges=[]
    for a,b in combinations(courtyards,2):
        if a.name!=b.name and clearance(a,b)<-EPS:courtyard_overlap.append([a.name,b.name])
    for a in courtyards:
        if any(min(x,y,60-x,55-y)-a.radius<-EPS for x,y in a.points):courtyard_edges.append(a.name)
    check('Conservative component courtyard separation',not courtyard_overlap,courtyard_overlap)
    check('Component courtyards fit on board',not courtyard_edges,courtyard_edges)
    silk=[]
    for ref,fp in footprints.items():
        for k,g in enumerate(fp.items):
            if not isinstance(g,Node) or g.value('layer')!='F.SilkS':continue
            pts=[]
            if g.key=='fp_line':pts=[global_pcb(xy(g.values(v)),fp) for v in ['start','end']]
            elif g.key=='fp_rect':
                a,b=xy(g.values('start')),xy(g.values('end'))
                pts=[global_pcb(v,fp) for v in [a,(b[0],a[1]),b,(a[0],b[1]),a]]
            elif g.key=='fp_circle':
                c=global_pcb(xy(g.values('center')),fp);r=dist(xy(g.values('center')),xy(g.values('end')))
                pts=[(c[0]+r*math.cos(i*math.tau/100),c[1]+r*math.sin(i*math.tau/100)) for i in range(101)]
            elif g.key=='fp_arc':
                a,b,c=[global_pcb(xy(g.values(v)),fp) for v in ['start','mid','end']]
                d=2*(a[0]*(b[1]-c[1])+b[0]*(c[1]-a[1])+c[0]*(a[1]-b[1]))
                if abs(d)>EPS:
                    aa,bb,cc=[v[0]**2+v[1]**2 for v in [a,b,c]]
                    center=((aa*(b[1]-c[1])+bb*(c[1]-a[1])+cc*(a[1]-b[1]))/d,(aa*(c[0]-b[0])+bb*(a[0]-c[0])+cc*(b[0]-a[0]))/d)
                    angles=[math.atan2(v[1]-center[1],v[0]-center[0]) for v in [a,b,c]]
                    span=(angles[2]-angles[0])%math.tau if (angles[1]-angles[0])%math.tau<(angles[2]-angles[0])%math.tau else -((angles[0]-angles[2])%math.tau)
                    r=dist(a,center)
                    pts=[(center[0]+r*math.cos(angles[0]+span*i/100),center[1]+r*math.sin(angles[0]+span*i/100)) for i in range(101)]
            if pts:
                width=float(g.child('stroke').value('width',.12))/2
                for a,b in zip(pts,pts[1:]):silk.append(Shape(ref+':'+str(k),'SILK',{'F.Cu'},[a,b],width))
    silk_errors=[];silk_min=math.inf
    for graphic in silk:
        for p in shapes:
            if not p.pad:continue
            gap=clearance(graphic,p);silk_min=min(silk_min,gap)
            if gap<.1-EPS:silk_errors.append({'graphic':graphic.name,'pad':p.name,'gap_mm':round(gap,6)})
    check('Silkscreen line and arc clearance to pads at least 0.10 mm',not silk_errors,{'minimum_mm':round(silk_min,6),'violations':silk_errors,'scope':'Graphic strokes only; glyph/text clearance remains a native DRC/visual-review item.'})
    j1={p.items[1] for p in footprints['J1'].children('pad')}
    check('Barrel jack contact 3 restored and intentionally unconnected',j1=={'1','2','3'} and any(n.items[1]=='3' and n.child('net') is None for n in footprints['J1'].children('pad')),sorted(j1))
    buzz=footprints['BZ1'];bp={p.items[1]:xy(p.values('at')) for p in buzz.children('pad')}
    check('Active buzzer identity and 7.6 mm lead pitch',buzz.properties()['Value']=='AI-1223-TWT-5V-R' and abs(dist(bp['1'],bp['2'])-7.6)<EPS,buzz.properties())
    cap=footprints['C1']
    required_values={'R1':'10M','R2':'100k','C1':'1nF','C2':'100nF','Q1':'2N7000-G','D1':'1N4148'}
    actual_values={r:footprints[r].properties()['Value'] for r in required_values}
    check('Model component values and C1 nonpolar footprint',actual_values==required_values and 'Nonpolar' in cap.items[1],actual_values)
    diode=next(s for s in sch.children('symbol') if s.properties()['Reference']=='D1')
    check('Flyback diode cathode on VCC', 'D1.1' in padnets['VCC'] and 'D1.2' in padnets['BUZZER_NEG'],{'pin1':'cathode','pin2':'anode'})
    check('No unfilled copper zones relied upon',not board.children('zone'),len(board.children('zone')))
    return {'status':'PASS' if not errors else 'FAIL','scope':'Independent file-level checks; not a native KiCad ERC/DRC run. Roundrect pads are conservatively checked as rectangles. No fabrication or hardware validation.','checks':checks,'failed':errors}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--board',type=Path,default=ROOT/'hardware/water-alarm.kicad_pcb');ap.add_argument('--schematic',type=Path,default=ROOT/'hardware/water-alarm.kicad_sch');ap.add_argument('--output',type=Path,default=ROOT/'verification/static-checks.json');args=ap.parse_args()
    report=verify(args.board,args.schematic);args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
    for check in report['checks']:
        print(('PASS' if check['passed'] else 'FAIL'),check['name'])
        if not check['passed']:print(json.dumps(check['detail'],indent=2))
    raise SystemExit(bool(report['failed']))
if __name__=='__main__':main()
