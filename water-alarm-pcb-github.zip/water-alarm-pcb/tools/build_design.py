"""Rebuild revision 1.1 from the preserved upload. Python standard library only."""
from pathlib import Path
import json
import re
import uuid
from kicad_sexpr import parse, load, patch, Node

ROOT = Path(__file__).resolve().parents[1]
HW = ROOT / 'hardware'
NS = uuid.UUID('d1f6257e-bd9f-4455-86b8-dfb3a817ba00')
def uid(name): return str(uuid.uuid5(NS, name))
def q(s): return json.dumps(str(s))
def raw(text, n): return text[n.start:n.end]
def prop(name, value, x=0, y=0, hidden=False, layer=None):
    return f'(property {q(name)} {q(value)} (at {x} {y} 0) '+(f'(layer {q(layer)}) ' if layer else '')+('(hide yes) ' if hidden else '')+'(effects (font (size 1 1)'+(' (thickness 0.15)' if layer else '')+')))'
def fp_line(a,b,layer='F.SilkS',w=.12):
    return f'(fp_line (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (stroke (width {w}) (type solid)) (layer "{layer}"))'
def fp_rect(a,b,layer='F.CrtYd',w=.05):
    return f'(fp_rect (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (stroke (width {w}) (type solid)) (fill no) (layer "{layer}"))'
def fp_circle(c,r,layer='F.SilkS',w=.12):
    return f'(fp_circle (center {c[0]} {c[1]}) (end {c[0]+r} {c[1]}) (stroke (width {w}) (type solid)) (fill no) (layer "{layer}"))'
def pad(number,x,y,net,size=(1.8,1.8),drill=.8,shape='circle',function=None,drill_oval=None):
    d=f'(drill {drill})' if drill_oval is None else f'(drill oval {drill_oval[0]} {drill_oval[1]})'
    return f'(pad "{number}" thru_hole {shape} (at {x} {y}) (size {size[0]} {size[1]}) {d} (layers "*.Cu" "*.Mask")'+(f' (net {q(net)})' if net else '')+(f' (pinfunction {q(function)})' if function else '')+' (pintype "passive"))'

def model(name):
    return '(model "${KIPRJMOD}/models/'+name+'.wrl" (offset (xyz 0 0 0)) (scale (xyz 1 1 1)) (rotate (xyz 0 0 0)))'

PARTS = {
 'J1':dict(template='J1',symbol='PowerJack',value='DCJ200-10-A',fp='BarrelJack_DCJ200_3Pin',sch=(50,80,0),pcb=(12,17,180),nets={'1':'VCC','2':'GND','3':None},datasheet='https://gct.co/files/drawings/dcj200-10.pdf'),
 'J2':dict(template='J2',symbol='ProbeConnector',value='PROBES',fp='Probe_Header_P5mm',sch=(50,110,180),pcb=(47,13,180),nets={'1':'VCC','2':'SENSE'}),
 'R1':dict(template='R1',symbol='Resistor',value='10M',fp='R_Axial_P5.08mm',sch=(105,105,0),pcb=(28,31,0),nets={'1':'GATE','2':'GND'}),
 'R2':dict(template='R1',symbol='Resistor',value='100k',fp='R_Axial_P5.08mm',sch=(90,90,90),pcb=(32,20,0),nets={'1':'SENSE','2':'GATE'}),
 'C1':dict(template='C1',symbol='Capacitor',value='1nF',fp='C_Nonpolar_P5mm',sch=(120,105,0),pcb=(37.08,27,0),nets={'1':'GATE','2':'GND'}),
 'C2':dict(template='C1',symbol='Capacitor',value='100nF',fp='C_Nonpolar_P5mm',sch=(70,140,0),pcb=(18,26,0),nets={'1':'VCC','2':'GND'}),
 'Q1':dict(template='Q1',symbol='NMOS_2N7000',value='2N7000-G',fp='TO92_SGD_P1.27',sch=(155,100,0),pcb=(28.73,39,0),nets={'1':'GND','2':'GATE','3':'BUZZER_NEG'},datasheet='https://ww1.microchip.com/downloads/en/DeviceDoc/2N7000-N-Channel-Enhancement-Mode-Vertical-DMOS-FET-Data-Sheet-20005695A.pdf'),
 'BZ1':dict(template='BZ1',symbol='ActiveBuzzer',value='AI-1223-TWT-5V-R',fp='ActiveBuzzer_D12_P7.6',sch=(160.08,70,0),pcb=(47,40,180),nets={'1':'VCC','2':'BUZZER_NEG'},datasheet='https://www.mouser.com/datasheet/2/334/AI-1223-TWT-5V-R-62026.pdf'),
 'D1':dict(template=None,symbol='Diode',value='1N4148',fp='D_DO35_P7.62',sch=(177.8,75,270),pcb=(46,27,0),nets={'1':'VCC','2':'BUZZER_NEG'},datasheet='https://www.vishay.com/docs/81857/1n4148.pdf'),
}

def main():
    original = HW/'original'
    sch_text = (original/'water-alarm-original.kicad_sch').read_text()
    sch = parse(sch_text)
    pcb_text = (original/'water-alarm-original.kicad_pcb').read_text()
    pcb = parse(pcb_text)
    symbols = {s.properties()['Reference']:s for s in sch.children('symbol')}
    fps = {f.properties()['Reference']:f for f in pcb.children('footprint') if f.properties()['Reference']!='REF**'}
    embedded = {s.items[1]:s for s in sch.child('lib_symbols').children('symbol')}
    rootid = uid('schematic-root')
    definitions={}
    def custom_symbol(name, graphics, pins, ref='D'):
        return f'(symbol "WaterAlarm:{name}" (pin_names (offset 0.5)) (in_bom yes) (on_board yes) '+prop('Reference',ref)+prop('Value',name)+prop('Footprint','',hidden=True)+prop('Datasheet','',hidden=True)+f' (symbol "{name}_0_1" {graphics}) (symbol "{name}_1_1" {pins}))'
    def pin(num,name,x,y,angle,kind='passive'):
        return f'(pin {kind} line (at {x} {y} {angle}) (length 2.54) (name "{name}" (effects (font (size 1 1)))) (number "{num}" (effects (font (size 1 1)))))'
    for ref, p in PARTS.items():
        if p['symbol'] in definitions: continue
        if p['template']:
            libid=symbols[p['template']].value('lib_id')
            definition=raw(sch_text,embedded[libid])
            old=libid.split(':')[-1]
            definition=definition.replace('"'+libid+'"','"WaterAlarm:'+p['symbol']+'"').replace('"'+old+'_','"'+p['symbol']+'_')
            if ref=='J1':
                n=parse(definition)
                sub=next(s for s in n.children('symbol') if s.children('pin'))
                definition=definition[:sub.end-1]+pin('3','SW',7.62,0,180)+definition[sub.end-1:]
            if ref=='Q1':
                definition=definition.replace('0.2A Id, 200V Vds, N-Channel MOSFET, 2.6V Logic Level, TO-92','N-channel MOSFET, 60 V; pin 1 S, 2 G, 3 D')
            definitions[p['symbol']]=definition
        else:
            graphics='(polyline (pts (xy -1.27 1.27) (xy -1.27 -1.27)) (stroke (width 0.25) (type default)) (fill (type none))) (polyline (pts (xy -1.27 0) (xy 1.27 1.27) (xy 1.27 -1.27) (xy -1.27 0)) (stroke (width 0.25) (type default)) (fill (type none)))'
            definitions['Diode']=custom_symbol('Diode',graphics,pin('1','K',-3.81,0,0)+pin('2','A',3.81,0,180))
    definitions['PowerFlag']=custom_symbol('PowerFlag','(polyline (pts (xy 0 0) (xy 0 2.54) (xy -1.27 1.905) (xy 0 1.27) (xy 1.27 1.905) (xy 0 2.54)) (stroke (width 0.2) (type default)) (fill (type none)))',pin('1','pwr',0,0,90,'power_out'),'#FLG')
    # Bind local library defaults to the revision's component data.
    for name, definition in list(definitions.items()):
        n=parse(definition); changes=[]
        sample=next((p for p in PARTS.values() if p['symbol']==name),None)
        if sample:
            for field,value in [('Footprint','WaterAlarm:'+sample['fp']),('Datasheet',sample.get('datasheet',''))]:
                node=next((v for v in n.children('property') if v.items[1]==field),None)
                if node:
                    old=raw(definition,node)
                    changes.append((node.start,node.end,old.replace(q(node.items[2]),q(value),1)))
        definitions[name]=patch(definition,changes)
    # A project-local symbol library keeps editing independent of global library caches.
    library='(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'
    library+='\n'.join(v.replace('"WaterAlarm:'+k+'"','"'+k+'"',1) for k,v in definitions.items())+'\n)\n'
    (HW/'water-alarm.kicad_sym').write_text(library)
    (HW/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "WaterAlarm") (type "KiCad") (uri "${KIPRJMOD}/water-alarm.kicad_sym") (options "") (descr "Project symbols")))\n')
    sch_out=f'(kicad_sch (version 20260306) (generator "eeschema") (generator_version "10.0") (uuid "{rootid}") (paper "A4")\n(title_block (title "Water Alarm") (date "2026-10-18") (rev "1.1") (comment 1 "5 V DC active-buzzer revision"))\n(lib_symbols\n'+'\n'.join(definitions.values())+'\n)\n'
    for ref,p in PARTS.items():
        x,y,a=p['sch']
        # A consistent label position independent of inherited, crowded formatting.
        labelx=x+6 if p['symbol'] not in ['PowerJack','ProbeConnector'] else x-6
        sch_out+=f'(symbol (lib_id "WaterAlarm:{p["symbol"]}") (at {x} {y} {a}) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid "{uid(ref)}")\n'
        if p['symbol'] in ['PowerJack','ProbeConnector']:
            sch_out+=prop('Reference',ref,x-8,y-9)+prop('Value',p['value'],x-8,y-6.5)
        elif p['symbol']=='ActiveBuzzer':
            sch_out+=prop('Reference',ref,labelx,y-2)+prop('Value',p['value'],labelx,y+1,True)+prop('Label','5V active',labelx,y+1)
        else:
            sch_out+=prop('Reference',ref,labelx,y-2)+prop('Value',p['value'],labelx,y+1)
        sch_out+=prop('Footprint','WaterAlarm:'+p['fp'],x,y,True)+prop('Datasheet',p.get('datasheet',''),x,y,True)
        sch_out+=f'(instances (project "water-alarm" (path "/{rootid}" (reference "{ref}") (unit 1)))))\n'
    count=0
    def wire(a,b):
        nonlocal count
        count+=1
        return f'(wire (pts (xy {a[0]} {a[1]}) (xy {b[0]} {b[1]})) (stroke (width 0) (type default)) (uuid "{uid("wire"+str(count))}"))\n'
    def label(name,at):
        nonlocal count
        count+=1
        return f'(label "{name}" (at {at[0]} {at[1]} 0) (effects (font (size 1.0 1.0)) (justify left bottom)) (uuid "{uid("label"+str(count))}"))\n'
    def labelled(pinpos,end,net): return wire(pinpos,end)+label(net,end)
    sch_out+=labelled((57.62,77.46),(65,77.46),'VCC')+labelled((57.62,82.54),(65,82.54),'GND')
    sch_out+=f'(no_connect (at 57.62 80) (uuid "{uid("jack-nc")}"))\n'
    sch_out+=labelled((55.08,110),(65,110),'VCC')+labelled((55.08,107.46),(65,107.46),'SENSE')
    sch_out+=labelled((87.46,90),(80,90),'SENSE')+wire((92.54,90),(105,90))+label('GATE',(105,90))
    sch_out+=wire((105,90),(105,102.46))+wire((105,90),(120,90))+wire((120,90),(120,102.46))
    sch_out+=wire((105,107.54),(105,115))+wire((120,107.54),(120,115))+wire((105,115),(120,115))+label('GND',(105,115))
    sch_out+=labelled((149.92,100),(140,100),'GATE')+labelled((157.54,105.08),(157.54,115),'GND')
    sch_out+=wire((157.54,94.92),(157.54,85))+wire((157.54,72.54),(157.54,85))+label('BUZZER_NEG',(157.54,85))
    sch_out+=labelled((157.54,67.46),(157.54,60),'VCC')
    sch_out+=labelled((177.8,71.19),(177.8,60),'VCC')+wire((177.8,78.81),(177.8,85))+wire((157.54,85),(177.8,85))
    sch_out+=labelled((70,137.46),(70,130),'VCC')+labelled((70,142.54),(70,150),'GND')
    for i,(x,net,end_y) in enumerate([(90,'VCC',130),(105,'GND',150)],1):
        ref=f'#FLG0{i}'
        sch_out+=f'(symbol (lib_id "WaterAlarm:PowerFlag") (at {x} 140 0) (unit 1) (in_bom no) (on_board no) (dnp no) (uuid "{uid(ref)}") '+prop('Reference',ref,x,140,True)+prop('Value','PWR_FLAG',x,140,True)+f'(instances (project "water-alarm" (path "/{rootid}" (reference "{ref}") (unit 1)))))\n'
        sch_out+=labelled((x,140),(x,end_y),net)
    for at in [(105,90),(105,115),(157.54,85)]:
        sch_out+=f'(junction (at {at[0]} {at[1]}) (diameter 0) (color 0 0 0 0) (uuid "{uid("junction"+str(at))}"))\n'
    for text,x,y,size in [('WATER ALARM  Rev 1.1',45,40,2),('POWER AND PROBES',45,58,1.4),('SENSE AND FILTER',80,72,1.4),('ACTIVE BUZZER SWITCH',145,48,1.4),('Regulated 5 V DC. J2 connects to two external probes.',45,167,1.2),('BZ1 must contain an internal oscillator. Pin 1 is positive.',45,173,1.2),('C1 is nonpolar. R1 sets sensitivity; this circuit has no hysteresis.',45,179,1.2)]:
        sch_out+=f'(text {q(text)} (at {x} {y} 0) (effects (font (size {size} {size})) (justify left)) (uuid "{uid(text)}"))\n'
    sch_out+='(embedded_fonts no))\n'
    # Keep all connection anchors on KiCad's conventional 50 mil (1.27 mm) grid.
    n=parse(sch_out); edits=[]
    def snapped(v):return f'{round(round(float(v)/1.27)*1.27,6):g}'
    for item in n.items:
        if not isinstance(item,Node):continue
        if item.key in ['symbol','label','global_label','junction','no_connect','text']:
            a=item.child('at')
            if a:edits.append((a.start,a.end,'(at '+' '.join([snapped(a.items[1]),snapped(a.items[2])]+a.items[3:])+')'))
        if item.key=='wire':
            for a in item.child('pts').children('xy'):
                edits.append((a.start,a.end,'(xy '+snapped(a.items[1])+' '+snapped(a.items[2])+')'))
    sch_out=patch(sch_out,edits)
    (HW/'water-alarm.kicad_sch').write_text(sch_out)
    # Footprints derived from the uploaded library data, with pin/net bindings regenerated.
    boardparts=[]; standalone={}
    for ref,p in PARTS.items():
        custom=p['symbol'] in ['Capacitor','ActiveBuzzer','Diode']
        if custom:
            fp=f'(footprint "WaterAlarm:{p["fp"]}" (layer "F.Cu") (uuid "{uid("fp"+ref)}") (at {p["pcb"][0]} {p["pcb"][1]} {p["pcb"][2]})\n'
            fp+=prop('Reference',ref,3.8 if p['symbol']=='ActiveBuzzer' else 0,-7.4 if p['symbol']=='ActiveBuzzer' else -3,layer='F.SilkS')+prop('Value',p['value'],0,3,layer='F.Fab')
            fp+=f'(path "/{uid(ref)}") (sheetname "/") (sheetfile "water-alarm.kicad_sch") (attr through_hole)\n'
            if p['symbol']=='Capacitor':
                fp+=fp_line((0,-1.35),(5,-1.35))+fp_line((0,1.35),(5,1.35))+fp_rect((-1.2,-1.75),(6.2,1.75))+fp_rect((0,-1.25),(5,1.25),'F.Fab',.1)
                fp+=pad('1',0,0,p['nets']['1'])+pad('2',5,0,p['nets']['2'])+model('ceramic-p5')
            elif p['symbol']=='ActiveBuzzer':
                fp+=fp_circle((3.8,0),6.1)+fp_circle((3.8,0),6.35,'F.CrtYd',.05)+fp_circle((3.8,0),6,'F.Fab',.1)
                fp+=fp_line((-1.3,-2),(-.3,-2))+fp_line((-.8,-2.5),(-.8,-1.5))
                fp+=pad('1',0,0,p['nets']['1'],shape='rect',function='+')+pad('2',7.6,0,p['nets']['2'],function='-')+model('active-buzzer')
            else:
                fp+=fp_rect((1.8,-1),(5.82,1),'F.SilkS',.12)+fp_rect((-1.1,-1.35),(8.72,1.35))+fp_line((2.2,-1),(2.2,1))
                fp+=pad('1',0,0,p['nets']['1'],size=(1.6,1.6),drill=.7,shape='rect',function='K')+pad('2',7.62,0,p['nets']['2'],size=(1.6,1.6),drill=.7,function='A')+model('diode-do35')
            fp+='\n)'
        else:
            node=fps[p['template']]; fp=raw(pcb_text,node); n=parse(fp); edits=[]
            # Replace footprint library identifier and placement.
            first=re.search(r'"(?:\\.|[^"\\])*"',fp)
            edits.append((first.start(),first.end(),q('WaterAlarm:'+p['fp'])))
            for name,value in [('Reference',ref),('Value',p['value']),('Datasheet',p.get('datasheet',''))]:
                pn=next((a for a in n.children('property') if a.items[1]==name),None)
                if pn: edits.append((pn.start,pn.end,raw(fp,pn).replace(q(pn.items[2]),q(value),1)))
            if ref=='Q1':
                pn=next(a for a in n.children('property') if a.items[1]=='Description')
                edits.append((pn.start,pn.end,raw(fp,pn).replace(q(pn.items[2]),q('N-channel MOSFET, 60 V; S-G-D pin order'),1)))
            at=n.child('at'); edits.append((at.start,at.end,f'(at {p["pcb"][0]} {p["pcb"][1]} {p["pcb"][2]})'))
            pn=n.child('path'); edits.append((pn.start,pn.end,f'(path "/{uid(ref)}")'))
            sf=n.child('sheetfile'); edits.append((sf.start,sf.end,'(sheetfile "water-alarm.kicad_sch")'))
            un=n.child('uuid'); edits.append((un.start,un.end,f'(uuid "{uid("fp"+ref)}")'))
            for pn in n.children('pad'):
                nn=pn.child('net'); number=pn.items[1]
                if nn: edits.append((nn.start,nn.end,'(net '+q(p['nets'][number])+')'))
            fp=patch(fp,edits)
            if ref=='J1':
                node=parse(fp)
                corrections=[(c.start,c.end,'') for c in node.items if isinstance(c,Node) and c.value('layer')=='F.CrtYd']
                for c in node.children('fp_line'):
                    if c.value('layer')=='F.SilkS' and c.values('start')==['4.6','-0.7']:
                        en=c.child('end');corrections.append((en.start,en.end,'(end 4.6 0.6)'))
                fp=patch(fp,corrections)
                fp=fp[:-1]+pad('3',4.8,2.9,None,size=(2,4.2),shape='oval',drill_oval=(1,3.2))
                fp+=fp_rect((-5,-1.5),(6.3,14.2))+'\n)'
        # A cloned footprint must never retain another instance's object UUIDs.
        fp=re.sub(r'\(uuid "([^"]+)"\)',lambda m:'(uuid "'+uid(ref+'-'+m.group(1))+'")',fp)
        pn=parse(fp); pinmeta={}
        for sub in parse(definitions[p['symbol']]).children('symbol'):
            for pin_node in sub.children('pin'):
                pinmeta[pin_node.value('number')]=(pin_node.value('name',''),pin_node.items[1])
        edits=[]
        for pad_node in pn.children('pad'):
            name,kind=pinmeta[pad_node.items[1]]
            for key,value in [('pinfunction',name),('pintype',kind)]:
                existing=pad_node.child(key)
                replacement=f'({key} {q(value)})' if value else ''
                if existing:edits.append((existing.start,existing.end,replacement))
                elif replacement:edits.append((pad_node.end-1,pad_node.end-1,replacement))
        fp=patch(fp,edits)
        boardparts.append(fp)
        # Remove board-only identity, pad nets and pin metadata from library copies.
        n=parse(fp); edits=[]
        for key in ['at','uuid','path','sheetname','sheetfile','units']:
            for t in n.children(key): edits.append((t.start,t.end,''))
        for pn in n.children('pad'):
            for key in ['net','pinfunction','pintype','uuid']:
                for t in pn.children(key): edits.append((t.start,t.end,''))
        for pn in n.children('property'):
            if pn.items[1] in ['Reference','Value']:
                value='REF**' if pn.items[1]=='Reference' else p['fp']
                edits.append((pn.start,pn.end,raw(fp,pn).replace(q(pn.items[2]),q(value),1)))
        standalone[p['fp']]=patch(fp,edits)
    # Non-electrical mounting holes are explicitly identified and stay inside the board.
    holes=[f for f in pcb.children('footprint') if f.properties()['Reference']=='REF**']
    for i,(x,y) in enumerate([(5,49),(55,49)],1):
        fp=raw(pcb_text,holes[i-1]); n=parse(fp); edits=[]
        at=n.child('at'); edits.append((at.start,at.end,f'(at {x} {y})'))
        pn=next(a for a in n.children('property') if a.items[1]=='Reference')
        edits.append((pn.start,pn.end,raw(fp,pn).replace('"REF**"',q('H'+str(i)))))
        attr=n.child('attr')
        edits.append((attr.start,attr.end,'(attr board_only exclude_from_pos_files exclude_from_bom)'))
        boardparts.append(patch(fp,edits))
    header='(kicad_pcb\n'+'\n'.join(raw(pcb_text,pcb.child(k)) for k in ['version','generator','generator_version','general','paper','layers','setup'] if pcb.child(k))+'\n'
    header+='(title_block (title "Water Alarm") (date "2026-10-18") (rev "1.1"))\n'
    board=header+'\n'.join(boardparts)+'\n'
    routes=[
      ('VCC','F.Cu',.5,[(12,17),(12,18),(47,18),(47,13)]),
      ('VCC','F.Cu',.5,[(47,18),(55,18),(55,40),(47,40)]),
      ('VCC','F.Cu',.5,[(55,22),(46,22),(46,27)]),
      ('VCC','F.Cu',.5,[(12,17),(12,26),(18,26)]),
      ('SENSE','B.Cu',.25,[(42,13),(32,13),(32,20)]),
      ('GATE','F.Cu',.2,[(37.08,20),(37.08,27),(37.08,33),(30,33),(30,39)]),
      ('GATE','F.Cu',.2,[(28,31),(28,29),(37.08,29)]),
      ('GND','B.Cu',.5,[(12,10.7),(20,10.7),(20,22),(23,22),(23,26),(23,39),(28.73,39)]),
      ('GND','B.Cu',.5,[(42.08,27),(42.08,31),(35.81,31),(35.81,35),(28.73,35),(28.73,39)]),
      ('GND','B.Cu',.5,[(33.08,31),(33.08,35),(35.81,35)]),
      ('BUZZER_NEG','F.Cu',.3,[(31.27,39),(32.5,37.77),(53.62,37.77),(53.62,27)]),
      ('BUZZER_NEG','F.Cu',.3,[(39.4,37.77),(39.4,40)]),
    ]
    count=0
    for net,layer,width,points in routes:
        for a,b in zip(points,points[1:]):
            count+=1
            board+=f'(segment (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (width {width}) (layer "{layer}") (net "{net}") (uuid "{uid("track"+str(count))}"))\n'
    # One closed 60 x 55 mm outline; no accidental internal cutout.
    board+='(gr_rect (start 0 0) (end 60 55) (stroke (width 0.05) (type default)) (fill no) (layer "Edge.Cuts") (uuid "'+uid('outline')+'"))\n'
    for text,x,y,size in [('WATER ALARM',30,46.5,1.4),('5V DC  |  REV 1.1',30,50.2,1),('PROBES',44,17,1),('5V ONLY',12,20.8,1),('S  G  D',30,43,0.9)]:
        board+=f'(gr_text {q(text)} (at {x} {y}) (layer "F.SilkS") (uuid "{uid("silk"+text)}") (effects (font (size {size} {size}) (thickness 0.15))))\n'
    board+='(embedded_fonts no))\n'
    parse(board); (HW/'water-alarm.kicad_pcb').write_text(board)
    for name,fp in standalone.items():
        fp=fp.replace('"WaterAlarm:'+name+'"','"'+name+'"',1)
        fp=fp.replace('(layer "F.Cu")','(version 20260206) (generator "pcbnew") (layer "F.Cu")',1)
        (HW/'water-alarm.pretty'/f'{name}.kicad_mod').write_text(fp+'\n')
    (HW/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "WaterAlarm") (type "KiCad") (uri "${KIPRJMOD}/water-alarm.pretty") (options "") (descr "Project footprints")))\n')
    project=json.loads((original/'water-alarm-original.kicad_pro').read_text())
    project['meta']['filename']='water-alarm.kicad_pro'
    project['sheets']=[[rootid,'']]
    # Exclusions from the student's original project do not hide checks in the new revision.
    for k in ['erc_exclusions','drc_exclusions']:
        if k in project.get('erc',{}): project['erc'][k]=[]
        if k in project.get('board',{}): project['board'][k]=[]
    (HW/'water-alarm.kicad_pro').write_text(json.dumps(project,indent=2)+'\n')
    (ROOT/'verification/design-manifest.json').write_text(json.dumps({'revision':'1.1','board_mm':[60,55],'supply_v':[4.75,5.25],'wet_probe_max_ohm':100000,'parts':PARTS,'routes':routes},indent=2)+'\n')
    print('Built corrected KiCad 10 schematic, PCB and project-local libraries.')

if __name__=='__main__': main()
