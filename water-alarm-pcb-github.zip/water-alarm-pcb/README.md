# Water Alarm PCB

A 5 V water-detection circuit using a 2N7000 MOSFET and a self-driven audible indicator. Two external probes detect a conductive water path; the circuit switches the buzzer without a microcontroller.

**Revision 1.1 is a corrected design candidate. File-level checks and the reduced electrical model pass. Native KiCad/ERC/DRC, native ngspice and physical hardware testing remain unverified in this package.**

![Corrected PCB layout](docs/images/corrected-pcb.png)

## Open the design

Open [hardware/water-alarm.kicad_pro](hardware/water-alarm.kicad_pro) in **KiCad 10.x**. Keep the entire `hardware` folder together: it includes project-local symbols, footprints and approximate models for the new parts. Standard KiCad 10 model libraries provide the remaining 3D bodies.

- [Schematic preview](docs/images/corrected-schematic.svg)
- [Circuit operation and calculations](docs/CIRCUIT.md)
- [Bill of materials](docs/BOM.md) and [CSV](hardware/BOM.csv)
- [Audit and corrections](docs/AUDIT.md)
- [Checks, bench procedure and manufacturing exports](docs/TESTING.md)
- [Upload to GitHub](docs/GITHUB.md)

## How it works

J1 accepts regulated, centre-positive **5 V DC**. J2 connects to two external metal probes. When dry, R1 pulls Q1's gate toward ground. When water conducts between the probes, the gate rises through R2 and Q1 supplies a return path for the active buzzer.

| Connection | Function |
| --- | --- |
| J1 pin 1 | +5 V, barrel centre contact |
| J1 pin 2 | Ground, barrel sleeve contact |
| J1 pin 3 | Unused switch contact, intentionally not connected |
| J2 pin 1 | Probe connected to VCC |
| J2 pin 2 | Sensing probe, connected to R2 |

The working envelope evaluated here is a 4.75–5.25 V supply and a wet probe resistance of 0–100 kΩ. Water resistance depends on composition and probe geometry; the board has not been tested in water. Keep the PCB dry and expose only the probes.

## Changes in revision 1.1

- Replaced the original passive TDK sounder selection with the **PUI AI-1223-TWT-5V-R active indicator**, suitable for DC activation, and a matching 7.6 mm pitch footprint.
- Replaced C1's polarized footprint with a nonpolar 1 nF capacitor footprint.
- Restored the barrel jack's missing third contact and marked it unused in the schematic.
- Added a 100 kΩ gate-input resistor, a supply decoupling capacitor and a diode across the magnetic indicator.
- Routed a new 60 × 55 mm two-layer board with a single closed outline, separated component courtyards and identified mounting holes.
- Preserved the uploaded project unchanged in [hardware/original](hardware/original). The two supplied screenshots are retained as original-design references in `docs/images`.

## Verification evidence

| Check | Delivered status |
| --- | --- |
| Independent schematic topology, PCB net agreement and conservative geometry checks | **23 checks passed** |
| Reduced RC/MOSFET model and operating-margin checks | **10 checks passed**, including 32 wet corners |
| Verifier fault-injection tests | **3 tests passed** |
| Native KiCad 10 ERC/DRC and schematic parity | **Not run locally**; workflow and commands included |
| Native ngspice model | **Not run locally**; runnable deck included |
| Fabrication, acoustic output and real-water performance | **Not tested** |

Machine-readable reports are in [verification](verification). The independent geometry checker does not replace KiCad's native rules engine. The model uses a documented resistive buzzer-load proxy and illustrative MOSFET equations; it does not simulate sound or the buzzer's internal oscillator.

![Reduced electrical-model results](docs/images/model-results.png)

## Reproduce the checks

From the repository root, using Python 3.10 or later:

```bash
python tools/verify_design.py
python tools/simulate.py
python tools/test_verifier.py
```

Those commands need only the Python standard library. To run native KiCad 10 and ngspice checks after installing both tools:

```bash
python tools/run_native_checks.py
```

The script returns a nonzero exit status if a tool is missing or a native check fails. GitHub Actions contains separate independent and native-check jobs; its actual result is established only after the repository is uploaded and the workflow runs.

To regenerate the revised CAD files from the preserved original:

```bash
python tools/build_design.py
```

To regenerate the documentation images and approximate models:

```bash
python -m pip install -r requirements.txt
python tools/render_assets.py
```

## Repository contents

| Folder | Contents |
| --- | --- |
| `hardware/` | Corrected KiCad project, local libraries, models and BOM |
| `hardware/original/` | Three unchanged uploaded CAD/project files |
| `docs/` | Circuit explanation, audit, part requirements and test instructions |
| `simulation/` | Native SPICE deck and reduced-model CSV results |
| `verification/` | Actual local check results and native-tool status |
| `tools/` | Rebuild, verification, numerical model and drawing scripts |
| `.github/workflows/` | Checks to execute on GitHub |

The original and corrected designs are separate revisions. Use the corrected `hardware/water-alarm` project for further work. KiCad session preferences and lock files are excluded.

## Attribution and licence

See [THIRD_PARTY.md](THIRD_PARTY.md) for KiCad-library attribution and component references. A project-wide licence has not been assigned; publishing the repository does not automatically make all its contents open source.
