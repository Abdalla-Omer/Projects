# Attribution and licensing

The preserved original CAD files and screenshots were supplied for this project. Their underlying tutorial or other external provenance was not provided; no authorship claim about such sources is added here.

Embedded symbols and footprints derived from standard KiCad libraries remain attributable to **The KiCad Library Team and contributors**. Project-local library copies include modified data from those libraries.

KiCad library material is distributed under **Creative Commons Attribution-ShareAlike 4.0 International**, with KiCad's additional exception for electronic designs and generated design files. Modified library collections retain their applicable library licensing. Consult the full licence and exact exception at the links below:

- [KiCad library licence and design exception](https://www.kicad.org/libraries/license/)
- [CC BY-SA 4.0 legal code](https://creativecommons.org/licenses/by-sa/4.0/legalcode)
- [KiCad symbols](https://gitlab.com/kicad/libraries/kicad-symbols)
- [KiCad footprints](https://gitlab.com/kicad/libraries/kicad-footprints)

Manufacturer names, part numbers and linked documents belong to their respective owners. No manufacturer datasheet has been bundled or relicensed. The new simple VRML bodies are approximate documentation models rather than manufacturer CAD.

A project-wide open-source licence has not been selected for the original design and newly assembled repository. The author can choose an appropriate project licence when publishing while retaining the third-party notices above.
