# Reproduce verification and test the board

Run commands from the repository root. The reports distinguish local file/model checks from native tool runs and physical measurements.

## Independent checks

Python 3.10 or later is sufficient; these commands do not require additional packages:

```bash
python tools/verify_design.py
python tools/simulate.py
python tools/test_verifier.py
```

The first command updates `verification/static-checks.json`. The second updates `verification/model-checks.json` and `simulation/results/*.csv`. The third intentionally introduces a short and an open trace in temporary copies to test detection.

## Native KiCad and SPICE checks

Install KiCad **10.x** and ngspice. KiCad 9 or earlier is not the target for the uploaded/current file formats.

```bash
python tools/run_native_checks.py
```

The script executes genuine schematic ERC, board DRC with schematic parity, and the supplied ngspice deck. It writes new reports and verifies two gate-voltage measurements from the ngspice output. It fails explicitly if a native tool is absent. The distributed native status is **NOT RUN**, not a simulated pass.

Native checks fail the script on error-level violations. Inspect all warning entries in their reports too; warnings are not silently reclassified as manufacturing approval. Also open the schematic and PCB in KiCad to inspect labels, pad assignments, local libraries, soldermask, component courtyards and 3D fit. Some original component models need the standard KiCad 10 3D model package.

The prepared GitHub Actions workflow performs the same native installation and checks on Ubuntu 24.04. Native success has not been observed in this package. If it reports a parser or design issue, retain the report and resolve that issue before fabrication.

## Generate manufacturing files after native review

The package contains source CAD rather than unverified Gerbers. Once the native reports and selected-part dimensions have been reviewed:

```bash
kicad-cli pcb export gerbers --output manufacturing/ --layers F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,Edge.Cuts hardware/water-alarm.kicad_pcb
kicad-cli pcb export drill --output manufacturing/ hardware/water-alarm.kicad_pcb
```

Inspect the resulting Gerbers and drills in KiCad's Gerber Viewer. Check that the board is 60 × 55 mm, all plated holes and slots exist, the third jack contact is present, there are two nonplated mounting holes, and no unintended inner cutout remains. Apply the actual manufacturer's minimum rules before ordering.

## First hardware test

This procedure has **not been performed** for the distributed design.

1. Inspect unpowered assembly. Check transistor orientation, diode band, capacitor type, buzzer polarity, connector pinout and solder joints. Check VCC-to-ground for an unintended short.
2. Leave J2 open. Apply a regulated centre-positive 5 V supply with an initial current limit around 50 mA. The buzzer should remain silent. Record voltage and actual idle current.
3. Connect a known 100 kΩ resistor between J2 pins 1 and 2. This is a repeatable electrical substitute for the stated wet-input condition. The gate should rise above 4.5 V and the selected active buzzer should sound.
4. Remove the resistor. Verify silence returns. Record the gate waveform with suitable high-impedance instrumentation if timing is needed; a 10 MΩ meter loads the sensing node.
5. Repeat with known resistors through the intended range and with the actual chosen supply. Record buzzer current during startup and steady operation; the model's 30 mA load assumption needs confirmation.
6. Connect external probes and test the intended water and spacing while keeping the PCB dry. Record the actual probe resistance or electrical response. A successful resistor test does not determine real-water sensitivity.

Do not infer an acoustic level, long-term reliability or a precise water-level threshold from the model plots. The circuit has no Schmitt-trigger hysteresis, enclosure qualification or reverse-polarity protection.

## Rebuild CAD and drawings

```bash
python tools/build_design.py
python tools/verify_design.py
python tools/simulate.py
python -m pip install -r requirements.txt
python tools/render_assets.py
```

`build_design.py` deliberately regenerates revision 1.1 from the preserved upload. It overwrites the corrected files, so commit manual revisions before running it. Documentation previews are drawn from CAD source geometry and CSVs, not exported by native KiCad. New local VRML bodies are approximate and labelled accordingly.
