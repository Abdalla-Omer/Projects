# Bill of materials

Revision 1.1 contains nine electrical parts and two mounting holes. [BOM.csv](../hardware/BOM.csv) contains the same purchasing/design requirements in a machine-readable table.

| Reference | Value or part | Required package and selection details |
| --- | --- | --- |
| J1 | GCT DCJ200-10-A connector family | Original 5.5 mm barrel-jack footprint with contact 3 restored; centre-positive 5 V wiring. Manufacturer drawing is marked obsolete; confirm the exact suffix and availability before procurement. |
| J2 | Two-pin probe connector | Phoenix MSTBA 2,5/2-G, 5.00 mm pitch footprint retained. It is a PCB header requiring a matching mating plug for screw-terminal wire attachment. |
| R1 | 10 MΩ, ±5% or better | Axial, 5.08 mm lead pitch; body fits the supplied 3.6 × 1.6 mm outline; at least 0.125 W. |
| R2 | 100 kΩ, ±5% or better | Same physical envelope as R1; at least 0.125 W. |
| C1 | 1 nF, nonpolar | Ceramic/film; 5.00 mm lead pitch, body no larger than 5 × 2.5 mm in plan; at least 25 V. |
| C2 | 100 nF, nonpolar | Ceramic; 5.00 mm lead pitch, same plan envelope as C1; at least 25 V. |
| Q1 | Microchip 2N7000-G | TO-92 inline, 1.27 mm adjacent lead pitch; pin 1 S, pin 2 G, pin 3 D. |
| BZ1 | PUI AI-1223-TWT-5V-R | Self-driven 5 V indicator; 3–7 V published operating range, rated current maximum 30 mA at rated voltage; 12 mm diameter, 9.5 mm body height, 7.6 mm pin pitch. |
| D1 | 1N4148 | DO-35 axial, bent to 7.62 mm lead pitch; cathode/band at pad 1, VCC. |
| H1, H2 | M3 mounting positions | 3.2 mm nonplated holes; confirm screw-head and standoff clearance for the chosen enclosure. |

R1, R2, C1 and C2 are defined by electrical and physical requirements, not an invented vendor part number. Select actual purchasing SKUs that satisfy both columns and recheck their dimensions before ordering a board. Generic appearance models are not substitutes for dimensional drawings.

## Important compatibility details

- **Active versus passive buzzer:** BZ1 needs an internal oscillator. Substituting the original TDK PS1240P02BT into this DC switching circuit will not provide the intended continuous alarm.
- **Buzzer lead spacing changed:** the corrected part uses 7.6 mm, replacing the original footprint's 5 mm spacing.
- **C1 is nonpolar:** its original capacitor value was 1 nF; a polarized axial electrolytic appearance/footprint was inappropriate for that specification.
- **J1 pin 3 is physical:** it is the unused switch contact, so it still needs a solder pad even though the schematic marks it unconnected.
- **MOSFET pinout:** verify the selected manufacturer's drawing. A part with a different lead order is not automatically interchangeable.

Manufacturer documents and the reference footprint are linked in [SOURCES.md](SOURCES.md).
