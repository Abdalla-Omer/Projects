# Technical references

References checked on 18 October 2026. Manufacturer documents are linked rather than redistributed.

1. **Microchip 2N7000 data sheet, DS20005695A.** Source/gate/drain pin order, gate threshold range, gate leakage, on-resistance test condition and operating limits used in the electrical-margin calculation. [Manufacturer PDF](https://ww1.microchip.com/downloads/en/DeviceDoc/2N7000-N-Channel-Enhancement-Mode-Vertical-DMOS-FET-Data-Sheet-20005695A.pdf).
2. **PUI Audio AI-1223-TWT-5V-R manufacturer data sheet.** Self-drive DC indicator selection, rated electrical conditions and mechanical outline. The distributor-hosted PDF includes the manufacturer's specification/drawing; it also contains an unrelated inherited heading on one page, so use the matching model's overview and dimensional/specification page. [Manufacturer-authored PDF](https://www.mouser.com/datasheet/2/334/AI-1223-TWT-5V-R-62026.pdf).
3. **TDK PS-series catalogue, PS1240P02BT section.** Original passive sounder selection and required alternating excitation. [Manufacturer PDF](https://product.tdk.com/en/system/files/dam/doc/product/sw_piezo/sw_piezo/piezo-buzzer/catalog/piezoelectronic_buzzer_ps_en.pdf).
4. **GCT DCJ200-10 drawing.** Three-contact connector and mechanical specification. The linked revision is marked obsolete; check the intended purchasing part before manufacture. [Manufacturer drawing](https://gct.co/files/drawings/dcj200-10.pdf).
5. **KiCad reference footprint for GCT DCJ200-10-A.** Confirms the third pad at local coordinates (4.8, 2.9) mm with a 1 × 3.2 mm plated slot. [Official library history](https://gitlab.com/kicad/libraries/kicad-footprints/-/blob/v7/Connector_BarrelJack.pretty/BarrelJack_GCT_DCJ200-10-A_Horizontal.kicad_mod).
6. **Vishay 1N4148 data sheet.** Reference for the DO-35 small-signal diode; verify the selected supplier's package and cathode marking. [Manufacturer PDF](https://www.vishay.com/docs/81857/1n4148.pdf).
7. **KiCad 10 command-line reference.** Native ERC/DRC, schematic parity and manufacturing export commands. [Official documentation](https://docs.kicad.org/10.0/en/cli/cli.html).
8. **KiCad Ubuntu installation.** Source for the stable KiCad 10 PPA used by the native GitHub Actions job. [Official installation page](https://www.kicad.org/download/details/ubuntu/).
9. **ngspice documentation.** Native execution and behavioural-device modelling reference. [Official documentation](https://ngspice.sourceforge.io/docs.html).

The Python MOSFET model is illustrative and is not supplied, certified or fitted by a transistor manufacturer. The active-buzzer resistor is a load approximation. Documents above support the stated component facts, not a claim that this assembled PCB has passed laboratory tests.
