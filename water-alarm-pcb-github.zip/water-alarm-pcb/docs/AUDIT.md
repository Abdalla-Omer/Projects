# Design audit and revision record

The uploaded files describe a conductivity detector with a gate pull-down, a gate capacitor and a low-side MOSFET. Their core schematic connections are internally consistent. The original physical selections and board data needed corrections before presenting the project as a working design.

The original `.kicad_pro`, `.kicad_sch` and `.kicad_pcb` are preserved byte for byte in `hardware/original`. Corrected files use the separate `hardware/water-alarm` name.

## Findings and corrections

| Finding in uploaded data | Effect | Revision 1.1 action |
| --- | --- | --- |
| BZ1 footprint names the TDK PS1240P02BT passive sounder; no oscillator appears in the circuit | Steady DC does not supply the alternating excitation needed for continuous sound | Selected a self-driven PUI 5 V indicator and changed lead pitch to 7.6 mm |
| BZ1 circular fabrication outline has an 11.1 mm radius, despite the named TDK body being 12.2 mm in diameter | Footprint geometry no longer represents the named component; its outline also extends beyond the uploaded board | Replaced the modified footprint with a documented 12 mm active-indicator envelope and moved it fully inside the board |
| C1 is a 1 nF nonpolar schematic symbol, but its footprint is an axial polarized capacitor | Misleading assembly and package selection | New nonpolar 5 mm pitch footprint and appearance model |
| J1 footprint has pads 1 and 2 only, while the named GCT connector has a third switch terminal | Missing physical contact/solder-pad provision | Restored pad 3 at the reference footprint position and added an explicit schematic no-connect |
| A 0.5 × 0.5 mm internal rectangle exists on Edge.Cuts | Unintended tiny routed cutout | Replaced the contour with one closed 60 × 55 mm rectangle |
| Two mounting footprints use the same REF** reference | Ambiguous assembly references | Identified them as board-only H1 and H2 |
| Copper zones exist but contain no saved filled polygons | A screenshot does not demonstrate a usable copper fill | Removed reliance on zones; every required net is explicitly routed |
| Q1 description claims 200 V and a specific logic level | Incorrect description for the selected 2N7000 | Corrected metadata and tied the choice to the Microchip pinout/specification |

R2, D1 and C2 are additions in the corrected revision, not parts claimed to exist in the uploaded circuit. They provide input resistance, a buzzer clamp and local supply decoupling respectively.

## What was actually checked

[static-checks.json](../verification/static-checks.json) records 23 independent checks, including extraction of the schematic's connected pin groups, connection-grid alignment, equality with PCB pad nets, trace-to-pad copper continuity on both layers, inter-net copper clearance, outline integrity, mounting-hole clearance, conservative component-courtyard separation and silkscreen graphic-to-pad clearance. Roundrect pads are conservatively treated as full rectangles; glyph/text clearances remain a native DRC and visual-review item.

[model-checks.json](../verification/model-checks.json) records 10 reduced-model checks. The supply/resistor/leakage/probe corners are explicitly enumerated in the CSV files. These are electrical-model predictions within a specified envelope.

Three fault-injection tests check that the verifier passes the corrected file, detects an added physical VCC-to-ground short and detects a removed ground trace. They do not elevate the checker into a complete KiCad DRC implementation.

## Verification boundaries

| Activity | Actual delivered status |
| --- | --- |
| Parsing uploaded and revised KiCad data | Completed |
| Independent topology and conservative copper/component geometry checks | Passed |
| Reduced electrical-model calculations and CSV generation | Passed |
| Visual review of source-derived documentation drawings | Completed |
| Native KiCad 10 loading, ERC, DRC and schematic parity | Not run: native tool unavailable in the build workspace |
| Native ngspice execution | Not run: native tool unavailable in the build workspace |
| Physical fit, manufacture, soldering, actual current and acoustic output | Not tested |
| Actual water, wet resistance and long-term probe behaviour | Not tested |

`verification/native-status.json` records missing native tools explicitly. A GitHub Actions job installs KiCad 10 and ngspice and runs the provided commands after upload; its future results must be reviewed. No CI badge claiming a successful remote run is included.

The corrected files are a reviewable design candidate. Passing file-level checks does not establish native parser acceptance, every manufacturing rule, enclosure fit or real-world alarm reliability. Use [TESTING.md](TESTING.md) to complete those steps.
