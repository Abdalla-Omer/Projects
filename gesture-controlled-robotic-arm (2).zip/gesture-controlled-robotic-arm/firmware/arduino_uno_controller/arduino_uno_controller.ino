/* USB laptop -> ESP32 relay -> Uno RX D0. See docs/WIRING.md.
   Protocol: AA 55 base shoulder claw CRC8. Flash all three components together.
   Loss policy: hold last target for 1 s, then slew to calibrated rest.
   This is not an emergency stop: cut servo supply for an emergency stop. */
#include <Servo.h>
#include "protocol.h"

Servo servo[3];
const uint8_t PINS[3] = {5, 6, 8};
const uint8_t REST[3] = {90, 90, 150};
const uint8_t MINIMUM[3] = {0, 30, 99}, MAXIMUM[3] = {180, 90, 150};
const float RATE[3] = {90, 60, 120};  // degrees per second
uint8_t target[3] = {90, 90, 150};
float current[3] = {90, 90, 150};
PacketParser parser;
unsigned long lastPacket = 0, lastByte = 0, lastStep = 0;

void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < 3; ++i) {
    servo[i].write(REST[i]);
    servo[i].attach(PINS[i]);
  }
  lastPacket = lastStep = millis();
}

void loop() {
  unsigned long now = millis();
  if (now - lastByte > 50) parser.reset();
  uint8_t angles[3];
  while (Serial.available()) {
    lastByte = now;
    if (parser.feed((uint8_t)Serial.read(), angles)) {
      for (uint8_t i = 0; i < 3; ++i)
        target[i] = constrain(angles[i], MINIMUM[i], MAXIMUM[i]);
      lastPacket = now;
    }
  }
  if (now - lastPacket >= 1000) memcpy(target, REST, 3);
  if (now - lastStep < 20) return;
  float dt = min(now - lastStep, 100UL) / 1000.0f;
  lastStep = now;
  for (uint8_t i = 0; i < 3; ++i) {
    float delta = target[i] - current[i];
    float step = RATE[i] * dt;
    current[i] += constrain(delta, -step, step);
    servo[i].write((int)(current[i] + 0.5f));
  }
}
