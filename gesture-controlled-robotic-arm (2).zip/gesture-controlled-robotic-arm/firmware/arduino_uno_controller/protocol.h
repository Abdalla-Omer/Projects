#pragma once
#include <stdint.h>
#include <string.h>

inline uint8_t crc8(const uint8_t *data, uint8_t length) {
  uint8_t crc = 0;
  while (length--) {
    crc ^= *data++;
    for (uint8_t i = 0; i < 8; ++i)
      crc = (crc << 1) ^ ((crc & 0x80) ? 0x07 : 0);
  }
  return crc;
}

// A six-byte sliding window recovers after inserted/lost/corrupted bytes.
struct PacketParser {
  uint8_t window[6] = {}, size = 0;
  void reset() { size = 0; }
  bool feed(uint8_t byte, uint8_t out[3]) {
    if (size == 6) {
      memmove(window, window + 1, 5);
      size = 5;
    }
    window[size++] = byte;
    if (size != 6 || window[0] != 0xAA || window[1] != 0x55 ||
        crc8(window + 2, 3) != window[5]) return false;
    memcpy(out, window + 2, 3);
    size = 0;
    return true;
  }
};
