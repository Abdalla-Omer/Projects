/* Uses the WROVER_KIT camera pin map from the supplied working sketch.
   Video runs in an ESP-IDF HTTP server task; UART relay stays responsive.
   Arduino ESP32 core target: 3.0.7, ESP32 Wrover Module, PSRAM enabled.
   Verify the physical board and disable SD/JTAG users of GPIO13/14. */
#include "esp_camera.h"
#include "esp_http_server.h"
#include <WiFi.h>
#include "secrets.h"  // Copy secrets.example.h to this ignored local file.

HardwareSerial Relay(1);
const int RELAY_TX = 13;
const int UNUSED_RELAY_RX = 14;  // Leave physically disconnected.
httpd_handle_t streamServer = nullptr;

static esp_err_t stream(httpd_req_t *req) {
  esp_err_t result = httpd_resp_set_type(req,
      "multipart/x-mixed-replace; boundary=frame");
  if (result != ESP_OK) return result;
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  while (true) {
    camera_fb_t *frame = esp_camera_fb_get();
    if (!frame) return ESP_FAIL;
    char header[96];
    int length = snprintf(header, sizeof(header),
        "\r\n--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",
        (unsigned)frame->len);
    result = httpd_resp_send_chunk(req, header, length);
    if (result == ESP_OK)
      result = httpd_resp_send_chunk(req, (const char *)frame->buf, frame->len);
    esp_camera_fb_return(frame);  // Return even after a client disconnects.
    if (result != ESP_OK) return result;
    delay(1);
  }
}

void setup() {
  Serial.begin(115200);
  Relay.begin(115200, SERIAL_8N1, UNUSED_RELAY_RX, RELAY_TX);
  camera_config_t c = {};
  c.ledc_channel = LEDC_CHANNEL_0;
  c.ledc_timer = LEDC_TIMER_0;
  c.pin_d0 = 4; c.pin_d1 = 5; c.pin_d2 = 18; c.pin_d3 = 19;
  c.pin_d4 = 36; c.pin_d5 = 39; c.pin_d6 = 34; c.pin_d7 = 35;
  c.pin_xclk = 21; c.pin_pclk = 22; c.pin_vsync = 25; c.pin_href = 23;
  c.pin_sccb_sda = 26; c.pin_sccb_scl = 27;
  c.pin_pwdn = -1; c.pin_reset = -1;
  c.xclk_freq_hz = 20000000;
  c.pixel_format = PIXFORMAT_JPEG;
  c.frame_size = FRAMESIZE_QVGA;
  c.jpeg_quality = 12;
  c.fb_count = psramFound() ? 2 : 1;
  c.fb_location = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
  c.grab_mode = CAMERA_GRAB_LATEST;
  if (esp_camera_init(&c) != ESP_OK) {
    Serial.println("Camera init failed; check WROVER pin map and power.");
    while (true) delay(1000);
  }
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000) delay(100);
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi failed; check secrets.h, then reset.");
    while (true) delay(1000);
  }
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 81;
  config.stack_size = 8192;
  config.send_wait_timeout = 2;
  httpd_uri_t uri = {};
  uri.uri = "/stream";
  uri.method = HTTP_GET;
  uri.handler = stream;
  if (httpd_start(&streamServer, &config) != ESP_OK ||
      httpd_register_uri_handler(streamServer, &uri) != ESP_OK) {
    Serial.println("HTTP server failed.");
    while (true) delay(1000);
  }
  Serial.print("Stream: http://"); Serial.print(WiFi.localIP()); Serial.println(":81/stream");
}

void loop() {
  // Inbound bytes only. Debug text is never forwarded to the Uno.
  while (Serial.available()) Relay.write((uint8_t)Serial.read());
  delay(1);
}
