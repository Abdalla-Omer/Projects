# Gesture-Controlled Robotic Arm

A camera-to-motion project using an ESP32 camera, a laptop running OpenCV / MediaPipe, and an Arduino Uno driving **base, shoulder and claw servos**.

**Start with the simulation:** open [`docs/circuit_3d.html`](docs/circuit_3d.html) in a browser. It is one self-contained file: no installation, server, internet connection or camera permission required. Download it first if your file viewer only shows source text.

![Assembled arm, electronics and camera view](docs/images/simulation-preview.png)

## Try it

1. Drag the virtual hand in the side panel. The outlined rectangle is the camera frame.
2. Select **Open hand** or **Closed fist** to move the claw.
3. Move outside the rectangle or beyond the simulated distance limits. Commands stop; after one second the arm slews to its rest pose.
4. Drag the 3D view to orbit, scroll/pinch to zoom, or shift-drag to pan. Hover for component names, click for details, or double-click to focus. The inspector provides keyboard-accessible component selection.
5. Use **Arm** for a close view, **Wiring** to inspect connections, or **Play gesture demo** to see the complete loop.

The model is a functional illustration, **not a reconstruction from measured parts or a physics/electrical simulator**. It models two positioning axes and a gripper—the three channels present in the provided code. Its elbow is a fixed bracket. It does not invent another elbow servo. Board geometry, link lengths, lens angle and virtual distance units are illustrative. The browser controls a virtual hand; actual camera tracking is provided by the Python program.

## Signal path

```mermaid
flowchart TD
  C["ESP32 camera"] -->|"Wi-Fi MJPEG video"| L["Laptop: OpenCV + MediaPipe"]
  L -->|"USB serial commands"| C
  C -->|"GPIO13 TX to D0 RX"| U["Arduino Uno"]
  U -->|"D5, D6, D8 signals"| S["Base, shoulder, claw"]
  P["External servo supply"] -->|"Servo power"| S
```

This follows the interfaces in the supplied ESP32/Python files: **video over Wi-Fi, commands over USB serial and then UART**. The earlier chat described several conflicting routes; the supplied ESP32 firmware contains no Wi-Fi command receiver. Connect `--port` to the **ESP32**, not the Uno, for this configuration.

## Repository

| Location | Purpose |
|---|---|
| `firmware/esp32_cam_relay/` | WROVER camera stream and independent UART relay |
| `firmware/arduino_uno_controller/` | CRC-checked packets, angle limits, timed motion and loss timeout |
| `software/hand_tracking.py` | One-hand tracker, latest-frame capture and 20 Hz command limit |
| `software/control.py` | Gesture mapping and packet encoding without hardware dependencies |
| `docs/circuit_3d.html` | Standalone offline simulation |
| `docs/simulator/` | Editable simulation source |
| `docs/images/circuit_diagram.svg` | Labeled wiring schematic |
| `docs/WIRING.md` | Connection tables and power setup |
| `docs/SETUP.md` | Flashing, Python setup and calibration |
| `docs/AUDIT.md` | Confirmed defects and corrections |
| `docs/VALIDATION.md` | Executed checks and remaining limitations |
| `tests/` | Mapping, serial parser, Uno logic and scene checks |

## Hardware setup

Read [WIRING](docs/WIRING.md) and [SETUP](docs/SETUP.md) before applying servo power. The corrected firmware changes the packet format and relay pin: **update the Python program and both boards together**. The old raw-three-byte and text protocols are incompatible.

- Camera profile: `CAMERA_MODEL_WROVER_KIT` pin assignments from the supplied sketch. This does not establish the exact physical carrier board.
- Relay: ESP32 **GPIO13 → Uno D0/RX**, with a common ground. GPIO14 is configured as unused receive; leave it disconnected. Verify both pins are free on your board and not used for SD/JTAG.
- Servo signals: base **D5**, shoulder **D6**, claw **D8**. Servo power comes from a suitable external supply, not the Uno regulator.
- The included starting limits and rest pose must be calibrated to your mechanism with the load removed.

## Run the tracker

Use Python 3.11 in a virtual environment; install the pinned requirements:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r software/requirements.txt
python software/hand_tracking.py --stream http://ESP32-IP:81/stream --dry-run
python software/hand_tracking.py --stream http://ESP32-IP:81/stream --port COM9
```

Replace the IP and serial port. `--mirror` reverses the displayed image before tracking. Press **Q** to exit. When fresh hand observations stop, no commands are sent; the Uno holds its previous target for up to one second, then slews to rest. This behavior includes opening the claw; it is not an emergency stop.

## Mapping and protocol

| Input | Target | Limits / rate |
|---|---|---|
| Wrist x, left → right in processed image | Base 0 → 180° | 90°/s |
| Wrist y, top → bottom | Shoulder 30 → 90° | 60°/s; interpolation between y = 0.25 and 0.75 |
| Open hand / fist | Claw 150° / 99° | 120°/s |
| No valid packet for 1 s | Rest 90°, 90°, 150° | Same rate limits |

A six-byte frame is `AA 55 BASE SHOULDER CLAW CRC`. CRC-8 uses polynomial `0x07`, initial value 0, no reflection and no final XOR, over the three angle bytes. Commands are target angles, not coordinates. This is image-plane position control, not metric hand-depth estimation or discrete directional sweeps.

## Development

```bash
python -m unittest discover -s tests -p 'test_*.py' -v
c++ -std=c++11 -Wall -Wextra tests/protocol_test.cpp -o /tmp/arm-protocol-test
/tmp/arm-protocol-test
c++ -std=c++11 -Wall -Wextra -I tests/stubs tests/uno_logic_test.cpp -o /tmp/arm-uno-test
/tmp/arm-uno-test
python tools/build_simulator.py
# Optional scene raster tests (Node.js):
npm install --no-save @napi-rs/canvas@0.1.100
node tests/simulator_test.cjs
```

GitHub serves HTML source from repository links. To make the simulator an ordinary web page, enable GitHub Pages for the repository's `/docs` directory and visit `/circuit_3d.html`. Nothing has been published or pushed by this package.

See [VALIDATION](docs/VALIDATION.md) for what was tested. No physical response latency, electrical current rating, exact dimensions or hardware reliability claim has been independently measured.

## License

Project code is MIT licensed; see [LICENSE](LICENSE). External tools and libraries retain their own licenses. No third-party JavaScript library is bundled in the simulator. Wi-Fi credentials from the uploaded files are excluded; copy `secrets.example.h` to `secrets.h` locally.
