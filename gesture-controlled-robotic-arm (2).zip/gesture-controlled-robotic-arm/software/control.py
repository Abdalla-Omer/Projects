"""Pure, dependency-free gesture mapping and framed serial protocol."""
import math

REST = (90, 90, 150)
LIMITS = ((0, 180), (30, 90), (99, 150))
RATES = (90.0, 60.0, 120.0)  # degrees/second; mirrored in Uno and simulator
HEADER = b'\xaa\x55'


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def angles_for_hand(x, y, opened):
    """Image coordinates: x right, y down; no depth measurement is implied."""
    return (round(clamp(x, 0, 1) * 180),
            round(30 + clamp((y - .25) / .5, 0, 1) * 60),
            150 if opened else 99)


def crc8(data):
    """CRC-8, polynomial 0x07, init 0; no reflection or final XOR."""
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ (0x07 if crc & 0x80 else 0)) & 255
    return crc


def packet(angles):
    if len(angles) != 3:
        raise ValueError('Exactly three angles required')
    values = bytes(round(clamp(v, *lim)) for v, lim in zip(angles, LIMITS))
    return HEADER + values + bytes([crc8(values)])


def hand_open(landmarks, was_open=True):
    """Scale-independent four-finger extension heuristic with hysteresis.

    Uses MediaPipe's 3D normalized landmarks. This is a heuristic, not a
    universal gesture classifier; edge-on hands and occlusion remain hard.
    """
    def point(i):
        p = landmarks[i]
        return (p.x, p.y, p.z)

    extended = 0
    for mcp, pip, dip, tip in ((5, 6, 7, 8), (9, 10, 11, 12),
                                (13, 14, 15, 16), (17, 18, 19, 20)):
        a, b, c = point(mcp), point(pip), point(tip)
        u, v = [a[i] - b[i] for i in range(3)], [c[i] - b[i] for i in range(3)]
        norm = math.sqrt(sum(x*x for x in u) * sum(x*x for x in v))
        cosine = sum(x*y for x, y in zip(u, v)) / max(norm, 1e-9)
        far = math.dist(point(0), c) > math.dist(point(0), b) * 1.08
        extended += cosine < -.65 and far
    if extended >= 3:
        return True
    if extended <= 1:
        return False
    return was_open
