"""ESP32 video -> laptop hand tracking -> USB serial -> ESP32 -> Uno."""
import argparse
import contextlib
import threading
import time

from control import angles_for_hand, hand_open, packet


class LatestFrame:
    """Drain capture in a worker so old frames do not queue behind inference."""
    def __init__(self, cap):
        self.cap = cap
        self.lock = threading.Lock()
        self.latest = None
        self.stopped = threading.Event()
        self.finished = threading.Event()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        try:
            while not self.stopped.is_set():
                ok, frame = self.cap.read()
                if not ok:
                    break
                with self.lock:
                    self.latest = (time.monotonic(), frame)
        finally:
            self.cap.release()
            self.finished.set()

    def get(self):
        with self.lock:
            return self.latest

    def close(self):
        self.stopped.set()
        self.thread.join(timeout=3)
        # The worker owns release(), avoiding concurrent release/read calls.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stream', required=True, help='http://ESP32-IP:81/stream')
    port = parser.add_mutually_exclusive_group(required=True)
    port.add_argument('--port', help='ESP32 USB serial port, e.g. COM9 or /dev/ttyUSB0')
    port.add_argument('--dry-run', action='store_true', help='Track without sending commands')
    parser.add_argument('--mirror', action='store_true', help='Mirror image before tracking')
    args = parser.parse_args()

    import cv2
    import mediapipe as mp
    import serial
    if not hasattr(mp, 'solutions'):
        raise SystemExit('Install the pinned requirements in a Python 3.11 environment.')

    reader = None
    try:
        with contextlib.ExitStack() as stack:
            conn = None
            if not args.dry_run:
                # Open serial BEFORE video: USB control lines can reset ESP32.
                conn = serial.Serial(port=None, baudrate=115200,
                                     timeout=.1, write_timeout=.1)
                conn.dtr = False
                conn.rts = False
                conn.port = args.port
                conn.open()
                stack.enter_context(conn)
                time.sleep(2)
            # Allow the camera to rejoin Wi-Fi after a USB-triggered reset.
            deadline = time.monotonic() + 25
            while True:
                cap = cv2.VideoCapture(args.stream, cv2.CAP_FFMPEG,
                                      [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 5000,
                                       cv2.CAP_PROP_READ_TIMEOUT_MSEC, 2000])
                if cap.isOpened():
                    break
                cap.release()
                if time.monotonic() >= deadline:
                    raise SystemExit('Cannot open stream. Check IP, Wi-Fi and :81/stream.')
                time.sleep(.5)
            reader = LatestFrame(cap)
            hands = stack.enter_context(mp.solutions.hands.Hands(
                max_num_hands=1, min_detection_confidence=.7, min_tracking_confidence=.7))
            last_stamp, last_send, opened = -1, 0, True
            while True:
                if reader.finished.is_set():
                    raise SystemExit('Camera stream ended. Check Wi-Fi/camera and restart.')
                item = reader.get()
                now = time.monotonic()
                if item is None or now - item[0] > .5 or item[0] == last_stamp:
                    # No repeats/heartbeats from an old image; Uno handles link loss.
                    if item is not None and now - item[0] > .5:
                        stale = item[1].copy()
                        cv2.putText(stale, 'STALE VIDEO - commands stopped', (8, 22),
                                    cv2.FONT_HERSHEY_SIMPLEX, .45, (0, 80, 255), 1)
                        cv2.imshow('ESP32 hand tracking | Q to quit', stale)
                    if cv2.waitKey(10) & 255 == ord('q'):
                        break
                    continue
                stamp, raw = item
                last_stamp = stamp
                frame = cv2.flip(raw, 1) if args.mirror else raw.copy()
                result = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                status = 'NO HAND - hold, then rest after 1 s'
                now = time.monotonic()
                if result.multi_hand_landmarks and now - stamp <= .5:
                    hand = result.multi_hand_landmarks[0]
                    wrist = hand.landmark[0]
                    if 0 <= wrist.x <= 1 and 0 <= wrist.y <= 1:
                        opened = hand_open(hand.landmark, opened)
                        angles = angles_for_hand(wrist.x, wrist.y, opened)
                        status = f'Base {angles[0]}  Shoulder {angles[1]}  Claw {angles[2]}'
                        if now - last_send >= 1 / 20:
                            if conn:
                                conn.write(packet(angles))
                            last_send = now
                    mp.solutions.drawing_utils.draw_landmarks(
                        frame, hand, mp.solutions.hands.HAND_CONNECTIONS)
                cv2.putText(frame, status, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, .45,
                            (0, 255, 160), 1, cv2.LINE_AA)
                cv2.imshow('ESP32 hand tracking | Q to quit', frame)
                if cv2.waitKey(1) & 255 == ord('q'):
                    break
    finally:
        if reader is not None:
            reader.close()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
