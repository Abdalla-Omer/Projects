"""Build one offline HTML file from the maintainable shell and script."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = root / 'docs' / 'simulator'
script = (src / 'simulator.js').read_text()
assert '</script' not in script.lower()
html = (src / 'shell.html').read_text().replace('<!--SCRIPT-->', '<script>\n' + script + '\n</script>')
(root / 'docs' / 'circuit_3d.html').write_text(html)
print('Built docs/circuit_3d.html')
