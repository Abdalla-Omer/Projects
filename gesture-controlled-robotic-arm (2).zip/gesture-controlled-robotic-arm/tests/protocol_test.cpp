#include <cassert>
#include <cstdio>
#include "../firmware/arduino_uno_controller/protocol.h"
int main() {
  const uint8_t text[] = "123456789";
  assert(crc8(text, 9) == 0xF4);
  uint8_t packet[] = {0xAA, 0x55, 90, 60, 99, 0}, out[3];
  packet[5] = crc8(packet + 2, 3);
  PacketParser parser;
  int accepted = 0;
  for (uint8_t b : packet) if (parser.feed(b, out)) ++accepted;
  assert(accepted == 1 && out[0] == 90 && out[1] == 60 && out[2] == 99);
  // Corruption never refreshes command state; valid data after noise recovers.
  parser.reset(); packet[3] ^= 1;
  for (uint8_t b : packet) assert(!parser.feed(b, out));
  packet[3] ^= 1;
  for (int drop = 0; drop < 6; ++drop) {
    parser.reset();
    for (int i = 0; i < 6; ++i) if (i != drop) parser.feed(packet[i], out);
    accepted = 0;
    for (uint8_t b : packet) if (parser.feed(b, out)) ++accepted;
    assert(accepted == 1);
  }
  parser.reset();
  const uint8_t noise[] = {0, 255, 0xAA, 0xAA, 0x55, 3, 2, 1, 0, 0xAA};
  for (uint8_t b : noise) parser.feed(b, out);
  accepted = 0;
  for (uint8_t b : packet) if (parser.feed(b, out)) ++accepted;
  assert(accepted == 1);
  puts("PASS: CRC vector, valid packets, corruption, byte loss, noise resynchronization");
}
