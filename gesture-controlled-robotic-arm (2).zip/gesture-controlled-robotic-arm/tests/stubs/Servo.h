#pragma once
// Host-only stub: records commanded angles; does not simulate PWM or a servo.
#include <stdint.h>
#include <deque>
#include <algorithm>
using std::min;
#define constrain(x,a,b) ((x)<(a)?(a):((x)>(b)?(b):(x)))
extern unsigned long simulatedMillis;
inline unsigned long millis() { return simulatedMillis; }
struct Servo {
  int pin = -1, last = -1;
  void attach(int p) { pin = p; }
  void write(int angle) { last = angle; }
};
struct FakeSerial {
  std::deque<uint8_t> incoming;
  void begin(long) {}
  int available() { return incoming.size(); }
  int read() { int b = incoming.front(); incoming.pop_front(); return b; }
};
extern FakeSerial Serial;
