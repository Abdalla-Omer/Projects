import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'software'))
from control import angles_for_hand, packet, crc8, hand_open


class ControlTests(unittest.TestCase):
    def test_corners_and_clamp(self):
        self.assertEqual(angles_for_hand(0, 0, True), (0, 30, 150))
        self.assertEqual(angles_for_hand(1, 1, False), (180, 90, 99))
        self.assertEqual(angles_for_hand(.5, .5, True), (90, 60, 150))
        self.assertEqual(angles_for_hand(-1, 2, False), (0, 90, 99))

    def test_protocol_standard_vector(self):
        self.assertEqual(crc8(b'123456789'), 0xF4)
        data = packet((90, 60, 99))
        self.assertEqual(data[:5], bytes([0xAA, 0x55, 90, 60, 99]))
        self.assertEqual(data[5], crc8(data[2:5]))
        self.assertEqual(packet((-1, 500, 0))[2:5], bytes([0, 90, 99]))
        for n in [0, 2, 4]:
            with self.assertRaises(ValueError):
                packet([90] * n)

    def test_open_fist_and_scale(self):
        points = [SimpleNamespace(x=0., y=0., z=0.) for _ in range(21)]
        for base in [5, 9, 13, 17]:
            for j in range(4):
                points[base+j] = SimpleNamespace(x=(base-11)*.02, y=-(j+1)*.15, z=0.)
        self.assertTrue(hand_open(points, False))
        for p in points:
            p.x *= .2
            p.y *= .2
        self.assertTrue(hand_open(points, False))
        for tip in [8, 12, 16, 20]:
            points[tip].y = 0
        self.assertFalse(hand_open(points, True))


if __name__ == '__main__':
    unittest.main()
