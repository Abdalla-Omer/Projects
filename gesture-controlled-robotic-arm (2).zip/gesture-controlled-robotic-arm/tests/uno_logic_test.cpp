#include <cassert>
#include <cmath>
#include <cstdio>
#include "stubs/Servo.h"
unsigned long simulatedMillis = 0;
FakeSerial Serial;
#include "../firmware/arduino_uno_controller/arduino_uno_controller.ino"
void send(uint8_t base, uint8_t shoulder, uint8_t claw, bool corrupt=false) {
  uint8_t data[] = {base, shoulder, claw};
  Serial.incoming.push_back(0xAA); Serial.incoming.push_back(0x55);
  for (auto b : data) Serial.incoming.push_back(b);
  Serial.incoming.push_back(crc8(data, 3) ^ (corrupt ? 1 : 0));
}
void tick(unsigned long t) { simulatedMillis = t; loop(); }
int main() {
  setup();
  assert(servo[0].pin == 5 && servo[1].pin == 6 && servo[2].pin == 8);
  assert(servo[0].last == 90 && servo[1].last == 90 && servo[2].last == 150);
  send(180, 30, 99); tick(1); tick(20);
  assert(std::abs(current[0] - 91.8f) < .001);
  assert(std::abs(current[1] - 88.8f) < .001);
  assert(std::abs(current[2] - 147.6f) < .001);
  for (unsigned long t = 40; t <= 980; t += 20) tick(t);
  send(90, 60, 150, true); tick(990);
  assert(lastPacket == 1);
  tick(1001);
  assert(target[0] == 90 && target[1] == 90 && target[2] == 150);
  for (unsigned long t = 1021; t < 2300; t += 20) tick(t);
  assert(servo[0].last == 90 && servo[1].last == 90 && servo[2].last == 150);
  send(255, 0, 0); tick(2300);
  assert(target[0] == 180 && target[1] == 30 && target[2] == 99);
  puts("PASS: Uno pins, startup, slew timing, invalid-frame timeout, rest and angle clamps");
}
