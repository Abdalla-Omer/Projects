/* Deterministic scene/interaction tests in Node with a real Canvas 2D rasterizer.
   Browser layout and pointer capture still need a browser check; see VALIDATION.md. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const {createCanvas}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/@napi-rs/canvas':'@napi-rs/canvas');
const root=path.resolve(__dirname,'..');
class Element{
 constructor(id){this.id=id;this.style={};this.listeners={};this.attributes={};this.textContent='';this.value='';this.checked=true;this.options=[];}
 addEventListener(n,fn){this.listeners[n]=fn;}
 setAttribute(k,v){this.attributes[k]=v;}
 getBoundingClientRect(){return {left:0,top:0,width:this.clientWidth,height:this.clientHeight};}
 setPointerCapture(){}
}
const elements={};let html=fs.readFileSync(root+'/docs/simulator/shell.html','utf8');for(const m of html.matchAll(/id="([^"]+)"/g))elements[m[1]]=new Element(m[1]);
elements.inspect.options=Array.from(html.matchAll(/option value="([^"]+)"/g),m=>({value:m[1]}));
for(const [id,w,h] of [['scene',1120,820],['pad',290,188]]){const c=createCanvas(w,h),e=elements[id];e.clientWidth=w;e.clientHeight=h;Object.defineProperty(e,'width',{get:()=>c.width,set:v=>c.width=v});Object.defineProperty(e,'height',{get:()=>c.height,set:v=>c.height=v});e.getContext=()=>c.getContext('2d');e.native=c;}
let errors=[];const context={document:{getElementById:id=>{assert.ok(elements[id],id);return elements[id];}},window:{devicePixelRatio:1,addEventListener(){}},performance:{now:()=>0},requestAnimationFrame(){},console:{error:e=>errors.push(e)},Math,JSON};
vm.createContext(context);vm.runInContext(fs.readFileSync(root+'/docs/simulator/simulator.js','utf8'),context);const sim=context.window.GestureLab;
let t=0;function step(n=60){for(let i=0;i<n;i++){t+=20;sim.step(.02,t);}}
sim.setHand(.5,.5,6,true);step();let s=sim.snapshot();assert.deepEqual([...s.angles],[90,60,150]);assert.equal(s.tracked,true);
sim.setHand(1,0,6,false);step(100);s=sim.snapshot();assert.deepEqual([...s.angles],[180,30,99]);
// Hand outside the frustum must not send a new target; pose changes are ignored.
sim.setHand(1.1,.9,6,true);step(20);s=sim.snapshot();assert.equal(s.tracked,false);assert.deepEqual([...s.target],[180,30,99]);
step(120);s=sim.snapshot();assert.deepEqual([...s.angles],[90,90,150]);
// Near/far limits and re-entry.
for(const d of [1,11]){sim.setHand(.5,.5,d,true);step(2);assert.equal(sim.snapshot().tracked,false);}
sim.setHand(.2,.75,6,true);step(80);assert.deepEqual([...sim.snapshot().angles],[36,90,150]);
// Physical slew is independent of a target jump.
sim.setHand(1,0,6,false);sim.step(.02,t+=20);s=sim.snapshot();assert.ok(Math.abs(s.angles[0]-37.8)<.0001);assert.ok(Math.abs(s.angles[1]-88.8)<.0001);
// Wire toggle, focus, zoom and keyboard hand input exercise their real listeners.
elements.wires.onchange({target:{checked:false}});sim.render();elements.wires.onchange({target:{checked:true}});
elements['view-arm'].onclick();assert.equal(sim.snapshot().camera.distance,15);elements['zoom-in'].onclick();assert.ok(sim.snapshot().camera.distance<15);elements['view-all'].onclick();
elements.pad.listeners.keydown({key:'ArrowLeft',preventDefault(){}});assert.ok(sim.snapshot().hand.x<1);
// Render the default scene after the gesture returns to center.
sim.setHand(.5,.5,6,true);step(100);elements['view-all'].onclick();sim.render();
const out=process.argv[2]||path.resolve(root,'docs/images/simulation-preview.png');fs.mkdirSync(path.dirname(out),{recursive:true});const preview=createCanvas(1120,820),p=preview.getContext('2d');p.fillStyle='#17222d';p.fillRect(0,0,1120,820);p.drawImage(elements.scene.native,0,0);fs.writeFileSync(out,preview.toBuffer('image/png'));
fs.writeFileSync(path.resolve(path.dirname(out),'gesture-pad-preview.png'),elements.pad.native.toBuffer('image/png'));
assert.equal(errors.length,0);assert.ok(sim.snapshot().meshes>180);assert.ok(sim.snapshot().wires>=18);
console.log('PASS: mapping, slew, gesture, frustum limits, hold/rest, re-entry, controls, offline raster rendering');console.log('Preview:',out);console.log('Scene:',sim.snapshot().meshes,'meshes,',sim.snapshot().wires,'cables');
