"""Integration ordering with fake devices; no OpenCV/MediaPipe install required."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'software'))
import hand_tracking as tracker
from control import packet


class TrackerTests(unittest.TestCase):
    def run_tracker(self, stale=False):
        events, writes = [], []
        class Serial:
            def __init__(self, **kwargs):
                pass
            def open(self):
                events.append('serial open')
            def __enter__(self):
                return self
            def __exit__(self, *args):
                events.append('serial closed')
            def write(self, data):
                writes.append(data)
        class Frame:
            def copy(self):
                return self
        class Capture:
            def __init__(self, *args):
                events.append('video open')
            def isOpened(self):
                return True
            def release(self):
                events.append('video released')
        class Reader:
            def __init__(self, cap):
                self.cap = cap
                self.finished = NS(is_set=lambda: False)
            def get(self):
                return (99 if stale else 100, Frame())
            def close(self):
                self.cap.release()
        hand = NS(landmark=[NS(x=.2, y=.5, z=0)] * 21)
        class Hands:
            def __init__(self, **kwargs):
                pass
            def __enter__(self):
                return self
            def __exit__(self, *args):
                events.append('hands closed')
            def process(self, *args):
                return NS(multi_hand_landmarks=[hand])
        noop = lambda *args, **kwargs: None
        cv = NS(VideoCapture=Capture, CAP_FFMPEG=1, CAP_PROP_OPEN_TIMEOUT_MSEC=2,
                CAP_PROP_READ_TIMEOUT_MSEC=3, COLOR_BGR2RGB=4,
                FONT_HERSHEY_SIMPLEX=0, LINE_AA=8, cvtColor=lambda frame, mode: frame,
                putText=noop, imshow=noop, waitKey=lambda n: ord('q'),
                destroyAllWindows=lambda: events.append('windows closed'))
        mp = NS(solutions=NS(hands=NS(Hands=Hands, HAND_CONNECTIONS=[]),
                            drawing_utils=NS(draw_landmarks=noop)))
        with patch.dict(sys.modules, {'cv2': cv, 'mediapipe': mp, 'serial': NS(Serial=Serial)}), \
             patch.object(sys, 'argv', ['tracker', '--stream', 'http://camera:81/stream', '--port', 'FAKE']), \
             patch.object(tracker, 'LatestFrame', Reader), \
             patch.object(tracker, 'hand_open', return_value=True), \
             patch.object(tracker.time, 'sleep'), patch.object(tracker.time, 'monotonic', return_value=100):
            tracker.main()
        return events, writes

    def test_serial_before_video_and_cleanup(self):
        events, writes = self.run_tracker()
        self.assertLess(events.index('serial open'), events.index('video open'))
        self.assertEqual(writes, [packet((36, 60, 150))])
        for event in ('serial closed', 'video released', 'hands closed', 'windows closed'):
            self.assertIn(event, events)

    def test_stale_frame_never_sends(self):
        _, writes = self.run_tracker(stale=True)
        self.assertEqual(writes, [])


if __name__ == '__main__':
    unittest.main()
