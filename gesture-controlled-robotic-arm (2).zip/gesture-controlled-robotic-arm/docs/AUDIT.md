# Audit of the supplied attempt

Reviewed the pasted conversation, repository ZIP, original Python tracker, ESP32 sketch and camera support files. The corrections below address observed code or documentation issues; they do not certify physical hardware.

| Finding | Evidence in the supplied files | Correction |
|---|---|---|
| Conflicting control protocols | Original Python writes three raw bytes; original ESP32 reads newline text and sends `0,0,0,0` on idle; ZIP Uno expects raw bytes | One framed six-byte binary protocol across the complete pipeline |
| Relay starves during streaming | ZIP `handleStream()` stays inside `while (client.connected())`; `loop()` cannot reach the relay while it runs | Camera streaming moved to an independent native HTTP server task |
| Incorrect camera board profile | ZIP uses `pins::AiThinker`; uploaded sketch selects `CAMERA_MODEL_WROVER_KIT` | Preserve uploaded WROVER camera GPIO map |
| Fragile UART relay pins | Uploaded TX is GPIO0; ZIP changes to GPIO12 and speculates about the board | Use TX13/RX14 with explicit SD/JTAG/carrier verification requirements |
| Raw protocol cannot resynchronize | Uno reads every three bytes as a command | Magic header, CRC-8, sliding-window resynchronization and partial-frame timeout |
| Conflicting claw limits | Python closes at 99°, ZIP Uno clamps minimum to 100° | Use 99° consistently as a starting calibration value |
| Loop-dependent servo smoothing | ZIP smooths only shoulder with a blocking delay; base/claw jump | All channels slew by degrees per second on a nonblocking 20 ms schedule |
| Hand openness depends on apparent size | Absolute fingertip-to-wrist threshold `0.2` changes with distance | Finger extension geometry and state hysteresis; limitations remain documented |
| Integer filtering can stop short | Original Python repeatedly truncates smoothed angles | Send mapped targets; Uno keeps floating-point motion state |
| Multiple hands can compete | Original tracker loops over all detected hands | Explicitly track one hand |
| Resource cleanup / hardcoded config | Original script opens serial before validating stream, with hardcoded IP/port | CLI options, context-managed serial/tracker, capture worker cleanup and dry run |
| ESP32 can reset when USB serial opens | Opening video before a USB reset can leave capture permanently disconnected | Open serial first, deassert DTR/RTS, then retry video startup; report a later stream failure |
| Sensitive configuration | Uploaded ESP32 sketch contains actual Wi-Fi credentials | Local ignored `secrets.h` with placeholder example; credentials omitted from the package |
| Blank browser view | ZIP loads `three.js/128/three.min.js` from a CDN | Self-contained renderer with no external scripts |
| Not an assembled arm | Old model places three separate servos near boards | Hierarchical arm, fixed elbow, joint-mounted servos and paired claw jaws |
| No gesture/camera interaction | Old model only supports orbit and component clicks | Virtual hand pad, fist/open pose, camera frustum, visibility gating, timed rest |
| Inconsistent electrical drawing | Old 3D view connects servo supply to Uno VIN and describes USB board power despite external power selection | Separate board/servo positive rails, explicit common ground, correct input labeling |
| Unsupported dimensions/performance | Prior answer asserted exact board dimensions and repeated latency claims without measurements | Mark illustrative geometry and unmeasured performance clearly |

## Intent resolved from the files

The earlier conversation alternates between wireless commands, direct USB to Uno, and USB to ESP32. The uploaded ESP32 receives serial data and relays it to another UART, so the corrected baseline is **laptop USB → ESP32 → Uno**, while video goes **ESP32 Wi-Fi → laptop**. This is a documented interpretation of the supplied interfaces, not independent confirmation of the original wiring.

The code contains three actuators total: base, shoulder and claw. “3-DOF arm with a claw” can also mean three positioning joints plus a separate claw, but that would require a fourth controlled channel and a different mechanism. This package models the supplied three-channel design.

The corrected defaults change behavior in a few explicit ways: all joints have rate limits, commands are framed and checksummed, and ambiguous partial-open hand poses retain the previous claw state. Nominal angle ranges and the rest pose stay aligned with the supplied design, subject to calibration.
