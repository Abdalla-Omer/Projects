# Architecture

The ESP32 performs camera capture and byte relay. The laptop performs vision. The Uno performs validated, timed servo motion. Each stage has one role, and the ESP32 does not interpret hand coordinates.

## Normal operation

1. A dedicated ESP-IDF HTTP server task on ESP32 serves JPEG frames at port 81, `/stream`.
2. A laptop capture worker continuously drains video into one latest-frame slot. The main loop processes only a new recent frame and tracks at most one hand.
3. Wrist x/y maps to servo targets. Finger-joint geometry estimates hand opening; hysteresis retains the prior state when exactly two of four fingers appear extended.
4. The laptop sends at most 20 CRC-framed commands per second over USB serial to the ESP32.
5. ESP32 `loop()` relays inbound serial bytes to UART1 TX on GPIO13 independently of the stream task. Debug output goes only back to the laptop.
6. The Uno finds the six-byte frame, checks CRC, clamps targets and advances all three commanded angles on a 20 ms schedule.

There is no Wi-Fi command receiver. A fully wireless command path would require a separate transport change, not a different diagram label.

## Packet and failure behavior

`AA 55 BASE SHOULDER CLAW CRC8` is six bytes, without newline or decimal text. A sliding six-byte receive window resynchronizes after noise or dropped bytes. A gap over 50 ms discards a partial packet. CRC is an error-detection check, not authentication or a guarantee against all corrupted messages.

Only a valid packet refreshes the Uno timeout. After 1 s without a valid packet, targets become 90°, 90°, 150°, and the same rate limits move the arm to that pose. No `delay()` in the Uno movement loop blocks serial parsing. Rest opens the gripper, so it can release an object. Calibrate the rest pose and use a physical power disconnect; this software behavior is not an emergency stop.

The tracker stops sending when no hand is detected or a frame is too old. It does not turn stale images into heartbeats. Latest-frame capture limits application-side buffering; it does not establish a guaranteed end-to-end latency across camera/network/decoder buffers.

## What is and is not simulated

The browser uses hierarchical 3D transforms, perspective projection, face lighting and depth sorting to render a complete assembled arm. A fixed elbow bracket connects the shoulder-driven links. The three servo housings, board models, laptop, supplies, signals and moving cables are included.

The pad controls a virtual wrist in camera coordinates. The 3D hand lies at the corresponding position in a rectangular camera frustum; only x/y inside [0, 1] and virtual depth in [2, 10] produce targets. The depth limits are a simulation visibility rule, not a feature of the original monocular tracker. A physical camera's usable range depends on lens, lighting and tracking confidence.

Joint targets, rate limits and hold/rest timing match the corrected firmware. Actual mechanical angle offsets, servo backlash, load, torque, collision, power draw, wire bend limits, occlusion and hand-tracker confidence are not modeled. The renderer uses Canvas 2D rasterization of 3D polygons; it has no WebGL or external dependency, and its painter-style depth ordering is an illustration rather than a CAD renderer.

## Dependency choices

The tracker retains the supplied MediaPipe legacy Hands interface and pins a compatible release. Google lists legacy Hands as upgraded to the Tasks API; this project deliberately avoids an unreviewed API migration. See [MediaPipe's solutions guide](https://developers.google.com/edge/mediapipe/solutions/guide).

The camera stream uses Espressif's native `esp_camera` and `esp_http_server` APIs, the same task-based approach found in the [official CameraWebServer example](https://github.com/espressif/arduino-esp32/blob/master/libraries/ESP32/examples/Camera/CameraWebServer/app_httpd.cpp). The old ZIP's blocking Arduino `WebServer` loop is removed.
