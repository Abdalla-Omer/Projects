# Setup and calibration

## Before flashing

The uploaded sources disagreed on both protocol and wiring. This revision is a matched set. Update **both firmware sketches and Python**; do not mix it with the original raw bytes or newline text relay. GPIO13 is the revised ESP32 transmit pin.

Confirm your board exposes the WROVER camera pin map in [WIRING](WIRING.md), has working PSRAM, and makes GPIO13/14 available. The word “WROVER” alone does not establish the camera wiring. No photograph or exact part number was supplied, so this check cannot be completed from software alone.

## ESP32

1. In Arduino IDE, install **esp32 by Espressif Systems**, version **3.0.7**, and select **ESP32 Wrover Module** with PSRAM enabled. This is the code's target configuration; a full toolchain build was not available during this review.
2. Open `firmware/esp32_cam_relay/esp32_cam_relay.ino`.
3. Copy `secrets.example.h` to `secrets.h` in the same folder and enter your Wi-Fi SSID/password. `secrets.h` is ignored by Git. Actual credentials from the upload are not distributed.
4. Upload using the ESP32's USB/UART connection. If your carrier lacks USB, use a suitable USB-UART adapter and the carrier's programming procedure.
5. Open Serial Monitor at 115200. Record the printed `http://...:81/stream` address, then close Serial Monitor.
6. The minimal server has **only `/stream` on port 81**, not the original camera web-control dashboard on port 80. It intentionally excludes the oversized stock dashboard assets and unrelated configuration files.

The camera stream runs in a separate HTTP server task. The main loop remains available for the serial relay even while the laptop is receiving video. Wi-Fi join failures are reported after 20 seconds; correct the configuration and reset.

## Arduino Uno

1. Install Arduino's **Servo** library if it is not available, select **Arduino Uno**, and open `firmware/arduino_uno_controller/arduino_uno_controller.ino`.
2. Disconnect ESP32 TX from D0 while uploading. Keep servo power off initially.
3. Upload. Disconnect the Uno's USB data cable, reconnect ESP32 GPIO13 to Uno D0/RX, and verify common ground.
4. Connect the base, shoulder and claw signal leads to D5, D6 and D8 respectively. Follow the documented external board-power arrangement.

Do not attach an original `app_httpd.cpp` or extra `.ino` file to the new ESP32 sketch folder. The replacement is deliberately self-contained.

## Python

Use a Python **3.11** virtual environment. The requirements pin `mediapipe==0.10.21` because this project uses its legacy `mp.solutions.hands` API; do not automatically upgrade it to an incompatible version.

```bash
python -m venv .venv
# Activate as appropriate for your OS.
python -m pip install -r software/requirements.txt
python software/hand_tracking.py --stream http://ESP32-IP:81/stream --dry-run
```

Once tracking works without commanding hardware, use the **ESP32 serial port**:

```bash
python software/hand_tracking.py --stream http://ESP32-IP:81/stream --port COM9
# Linux example: --port /dev/ttyUSB0
# macOS example: --port /dev/cu.usbserial-...
```

`--mirror` reverses the input image before tracking; the coordinate labels refer to the processed image. A monocular wrist y coordinate is image height, not measured forward/back depth. Hold an upright, clearly visible hand initially. The scale-independent finger heuristic remains sensitive to occlusion and edge-on hands.

## First motion

Remove the load and disconnect linkages or horns as needed to establish travel without forcing hard stops. Confirm each servo's zero, direction and pulse/angle range. The Servo library's nominal degree mapping does not establish your actual mechanical angles.

The starting values are base 0–180°, shoulder 30–90°, claw 99–150°, with rest at 90°, 90°, 150°. Set narrower limits if your mechanism requires them. Mirror changes in `software/control.py`, the Uno sketch and simulator mapping; the simulation's link offsets may also need adjustment to match a particular build.

Test one actuator at a time, then confirm communication-loss behavior without holding an object: removing the hand or stopping Python should start a smooth return to rest after one second. Rest opens the gripper. Cut servo power with a physical disconnect if movement is unexpected.

## Troubleshooting

| Symptom | Check |
|---|---|
| Camera initialization fails | Actual camera pin map, PSRAM selection and board supply |
| Stream works but servos do not | Matched firmware/protocol, ESP32 serial port, TX13 → RX0 and common ground |
| Uno will not upload | Disconnect ESP32 TX from Uno RX during upload |
| ESP32 serial port is busy | Close Serial Monitor and other serial clients |
| Random resets or twitching | Supply sizing, ground layout, connectors and UART noise margin |
| `mediapipe` has no `solutions` | Use Python 3.11 and the pinned requirements in a clean environment |
| Browser shows HTML source | Download the standalone `.html` and open it in a browser |
| Browser movement looks different from hardware | Calibrate actual servo mounting, limits and mechanical geometry |
