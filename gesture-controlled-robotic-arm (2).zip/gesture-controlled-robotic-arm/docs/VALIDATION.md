# Validation record

Checks executed in the repair environment on 2026-09-17. The scripts are included so these results can be reproduced.

| Check | Result / scope |
|---|---|
| Python source compilation | `control.py` and `hand_tracking.py` pass `py_compile` |
| Python mapping/protocol/gesture tests | 5 test methods pass; cover image corners, clamps, CRC reference vector, frame encoding, malformed angle count, open/fist classification, scale invariance, serial-before-video initialization, resource cleanup, and stale-frame command suppression with fake devices |
| Actual C++ serial parser | Compiles with C++11, `-Wall -Wextra -pedantic`; valid frames, CRC failures, byte loss and noise recovery pass |
| Actual Uno sketch with host stubs | Compiles and runs; pin assignments, startup values, timing-based slew, invalid-frame timeout, return-to-rest and clamps pass |
| JavaScript syntax | `node --check` passes |
| Simulation behavior | Deterministic execution passes mapped targets, claw opening/closing, near/far and image-frame rejection, 1 s loss timeout, rest motion, re-entry, slew and control-handler checks |
| Simulation rendering | Actual Canvas 2D rasterization via `@napi-rs/canvas` 0.1.100; 227 modeled meshes, 18 cable paths; scene image inspected and corrected |
| Schematic | SVG parsed and rendered for inspection |
| Offline packaging | Generated HTML embeds all CSS and JavaScript; no network resource or library is needed |
| Repository hygiene | No actual Wi-Fi credentials, build binaries, caches or local environment folders included |

## What remains unverified

- **Browser integration:** no browser binary was installed in this environment, and downloading Chromium was blocked by the environment. Rendering and real JavaScript control handlers ran with a small DOM shim and a real Canvas rasterizer; CSS layout, browser pointer capture, mobile pinch and specific browser compatibility were not end-to-end tested. Open `docs/circuit_3d.html` in a current desktop browser for that check.
- **Full embedded builds:** the Arduino/ESP32 toolchains were unavailable. The parser and Uno host tests are not board builds. ESP32 targets Arduino core 3.0.7; compile and upload with the documented configuration before use.
- **Physical hardware:** no connected boards, camera or servos were available. Camera initialization, board pin availability, supply integrity, UART electrical behavior, PWM, mechanical travel and loaded motion need bench verification.
- **Live vision integration:** OpenCV/MediaPipe camera inference and physical serial transport were not run here. Tests cover pure control logic and protocol, not measured recognition accuracy or camera/network latency.
- **Geometry and physics:** no CAD or photographs were supplied. Visual sizes and offsets are illustrative. No torque, collision, electrical circuit, occlusion or flex-cable simulation is claimed.

## Manual acceptance sequence

1. Open the HTML offline. Confirm the assembled arm, boards, laptop and wiring render immediately.
2. Center the virtual hand: targets are base 90°, shoulder 60°, claw 150°.
3. Move right/top in the pad and close the fist: targets become 180°, 30°, 99°.
4. Move outside the frame. Confirm the old target is held briefly, then the arm slews to 90°, 90°, 150° after one second.
5. Return to center, move the depth slider outside 2–10, and confirm the same loss behavior.
6. Inspect a servo, focus the arm, orbit/zoom/pan, and toggle wires and camera view.
7. Compile both firmware targets. Test the tracker with `--dry-run`; then validate unloaded movement using calibrated limits and a physical power disconnect.
