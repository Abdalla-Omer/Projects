# Wiring

![Circuit schematic](images/circuit_diagram.svg)

The connection map below is authoritative. The 3D board shapes and header spacing are illustrative. Check your board labels and schematic before connecting; the provided camera profile identifies GPIO assignments, not an exact carrier-board layout.

## Commands and servo signals

| Source | Destination | Purpose |
|---|---|---|
| Laptop USB serial | ESP32 USB/UART bridge | Laptop sends six-byte servo frames at 115200 baud |
| ESP32 GPIO13 (UART1 TX) | Uno D0 / RX | One-way framed servo commands, 115200 baud |
| ESP32 GND | Common ground bus | UART reference |
| Uno GND | Common ground bus | Logic and servo signal reference |
| Uno D5 | Base servo signal | Base angle |
| Uno D6 | Shoulder servo signal | Shoulder angle |
| Uno D8 | Claw servo signal | Claw angle |
| Uno D1 / TX | **Unconnected** | No return channel is used |
| ESP32 GPIO14 | **Unconnected** | UART1 RX is configured but unused |

GPIO13/14 are not camera pins in the supplied WROVER map, but can serve SD/JTAG on carrier boards. Disable those functions and confirm availability. GPIO16/17 may belong to WROVER PSRAM. The replacement avoids the previous GPIO0/GPIO12 relay choices, which have boot-strapping roles.

Disconnect ESP32 TX from Uno D0 during Uno uploading. The Uno USB-UART bridge shares D0, so keep its USB data connection disconnected during normal relay operation. Close the ESP32 Serial Monitor before running Python.

ESP32 → Uno is the lower-voltage-to-higher-voltage direction. A nominal 3.3 V high meets the nominal 5 V ATmega328P digital input threshold, but the noise margin is limited. For a noisy installation or long cables, use a suitable unidirectional buffer such as a correctly powered 74AHCT125. Never connect Uno's 5 V TX directly to an ESP32 input. A resistor divider on ESP32 TX would reduce an already limited high level and is not the appropriate fix.

## Power distribution

| Rail | Connections | Constraint |
|---|---|---|
| Servo supply positive | All three servo positive leads | Voltage must match the actual servos; current capacity must cover the load and startup/stall demand |
| Servo supply negative | Servo returns and common ground bus | High-current servo returns run directly to the supply/bus |
| Separate regulated board 5 V | Verified ESP32 board 5 V input and Uno 5 V input | This bypasses Uno's regulator/protection; use a regulated, protected supply and correct polarity |
| Board supply negative | Common ground bus | All signal grounds share a reference |

**Do not power large servos from the Uno 5 V pin, its regulator, or a USB port.** The Uno generates signal pulses; it does not regulate the servo supply. Do not connect the servo positive rail to the board 5 V rail unless an independently designed power system intentionally makes them the same compatible rail.

The external-board-power arrangement matches the user's description. Where the ESP32 USB cable is still attached for data, use the board's documented power-selection circuit or an appropriate USB VBUS isolation arrangement; retain USB data and ground. Do not blindly parallel external 5 V and USB 5 V. Uno **VIN/barrel is a different input from 5 V**; the schematic intentionally does not put a 5 V servo supply into VIN.

Use a fused supply and a physical servo-power disconnect appropriate to the actual load. Size wire, connectors and bulk decoupling from the actual servo specifications and measured current. No servo model or current draw is established by the uploads, so an invented amp rating would be misleading.

## Camera pin map

The firmware preserves the uploaded `CAMERA_MODEL_WROVER_KIT` map:

| Signal | GPIO |
|---|---|
| D0, D1, D2, D3 | 4, 5, 18, 19 |
| D4, D5, D6, D7 | 36, 39, 34, 35 |
| XCLK / PCLK | 21 / 22 |
| VSYNC / HREF | 25 / 23 |
| SCCB SDA / SCL | 26 / 27 |
| Camera power-down / reset | -1 / -1 (not controlled) |

The previous ZIP used an AI-Thinker profile. Do not substitute it for this profile without verifying the physical camera wiring. The new minimal stream server does not drive a flash LED on GPIO22, which is PCLK in this map.

## Reference documents

- [Espressif WROVER-KIT guide](https://docs.espressif.com/projects/esp-idf/en/v3.1.6/get-started/get-started-wrover-kit-v2.html): board power selection, UART/JTAG jumpers and PSRAM pins. Board revisions differ.
- [Microchip ATmega328P datasheet](https://www.microchip.com/content/dam/mchp/documents/MCU08/ProductDocuments/DataSheets/Atmel-7810-Automotive-Microcontrollers-ATmega328P_Datasheet.pdf): electrical characteristics.
- [Arduino Uno Rev3](https://docs.arduino.cc/hardware/uno-rev3/): official board reference.
