/* Dependency-free 3D scene: world transforms, perspective projection, face lighting,
   depth sorting and polygon picking. Canvas 2D works offline without WebGL or CDNs.
   Units and board geometry are illustrative, not measured CAD or circuit simulation. */
'use strict';
(() => {
const $=id=>document.getElementById(id), canvas=$('scene'), ctx=canvas.getContext('2d'), pad=$('pad'), pc=pad.getContext('2d');
const TAU=Math.PI*2, rad=d=>d*Math.PI/180, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const add=(a,b)=>a.map((v,i)=>v+b[i]), sub=(a,b)=>a.map((v,i)=>v-b[i]), mul=(a,s)=>a.map(v=>v*s), dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0), cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]], norm=a=>mul(a,1/(Math.hypot(...a)||1));
const I=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
function mm(a,b){let c=Array(16).fill(0);for(let i=0;i<4;i++)for(let j=0;j<4;j++)for(let k=0;k<4;k++)c[i*4+j]+=a[i*4+k]*b[k*4+j];return c;}
function tr(m,p){return [m[0]*p[0]+m[1]*p[1]+m[2]*p[2]+m[3],m[4]*p[0]+m[5]*p[1]+m[6]*p[2]+m[7],m[8]*p[0]+m[9]*p[1]+m[10]*p[2]+m[11]];}
function matrix(p,r){let [x,y,z]=r, cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);let a=mm([cz,-sz,0,0,sz,cz,0,0,0,0,1,0,0,0,0,1],mm([cy,0,sy,0,0,1,0,0,-sy,0,cy,0,0,0,0,1],[1,0,0,0,0,cx,-sx,0,0,sx,cx,0,0,0,0,1]));a[3]=p[0];a[7]=p[1];a[11]=p[2];return a;}
class Group{constructor(parent=null,p=[0,0,0],r=[0,0,0]){this.parent=parent;this.p=p;this.r=r;this.m=I();groups.push(this);}update(){this.m=mm(this.parent?this.parent.m:I(),matrix(this.p,this.r));}world(p=[0,0,0]){return tr(this.m,p);}}
const groups=[],meshes=[],wires=[],labels=[],COL={metal:'#bacbd6',dark:'#25303a',black:'#131d27',copper:'#d99657',edge:'#ecd1a6',servo:'#31566c',pcb:'#33747b',power:'#ef856b',ground:'#8798ad',signal:'#f3c567',data:'#87c8f4',hand:'#a8dbbc'};
function mesh(g,v,f,color,id){const m={g,v,f,color,id};meshes.push(m);return m;}
function box(g,p,s,color,id){let [x,y,z]=s.map(v=>v/2);let v=[[-x,-y,-z],[x,-y,-z],[x,y,-z],[-x,y,-z],[-x,-y,z],[x,-y,z],[x,y,z],[-x,y,z]].map(a=>add(a,p));return mesh(g,v,[[0,3,2,1],[4,5,6,7],[0,4,7,3],[1,2,6,5],[3,7,6,2],[0,1,5,4]],color,id);}
function cylinder(g,a,b,r,color,id,n=12){let axis=norm(sub(b,a)),u=norm(cross(axis,Math.abs(axis[1])<.9?[0,1,0]:[1,0,0])),v=cross(axis,u),vs=[];for(const p of [a,b])for(let i=0;i<n;i++)vs.push(add(p,add(mul(u,r*Math.cos(i*TAU/n)),mul(v,r*Math.sin(i*TAU/n)))));let fs=[];for(let i=0;i<n;i++)fs.push([i,(i+1)%n,(i+1)%n+n,i+n]);fs.push(Array.from({length:n},(_,i)=>n-1-i),Array.from({length:n},(_,i)=>i+n));return mesh(g,vs,fs,color,id);}
function label(text,g,p,id,offset=[0,-17]){labels.push({text,g,p,id,offset});}
const root=new Group();
function screw(g,p,id){cylinder(g,add(p,[0,-.035,0]),add(p,[0,.035,0]),.09,COL.metal,id,8);}
function servo(g,id){box(g,[0,0,0],[.95,1.3,.72],COL.servo,id);box(g,[0,.53,0],[1.38,.17,.8],COL.dark,id);box(g,[0,.76,0],[.74,.23,.69],COL.black,id);cylinder(g,[0,.78,0],[0,1.02,0],.22,COL.metal,id);box(g,[0,1.04,0],[1,.08,.17],COL.edge,id);for(const x of [-.55,.55])screw(g,[x,.64,0],id);}
// Base, yaw stage and fixed-elbow arm. Every moving mesh shares its real joint parent.
const arm=new Group(root,[4,0,0]);
box(arm,[0,.18,0],[3.4,.35,3],COL.dark,'arm');for(const x of [-1.4,1.4])for(const z of [-1.2,1.2])screw(arm,[x,.39,z],'arm');
const baseServo=new Group(arm,[0,1,0]);servo(baseServo,'base');
for(const x of [-.95,.95])box(arm,[x,1,0],[.25,1.4,.7],COL.dark,'base');
const yaw=new Group(arm,[0,1.9,0]);
cylinder(yaw,[0,-.18,0],[0,.08,0],1.3,COL.copper,'base',24);
for(const z of [-.68,.68])box(yaw,[0,.55,z],[1.55,1.15,.18],COL.copper,'shoulder');
const shoulderServo=new Group(yaw,[0,.85,.88],[Math.PI/2,0,0]);servo(shoulderServo,'shoulder');
const shoulder=new Group(yaw,[0,1.03,0]);
cylinder(shoulder,[0,0,-1],[0,0,1.05],.36,COL.metal,'shoulder',18);
for(const z of [-.46,.46]){box(shoulder,[0,2.1,z],[.6,4.2,.18],COL.copper,'arm');for(const y of [.6,1.5,2.4,3.3])cylinder(shoulder,[0,y,z-.12],[0,y,z+.12],.115,COL.black,'arm',10);}
box(shoulder,[0,2.4,0],[.43,.5,.9],COL.dark,'arm');
const elbow=new Group(shoulder,[0,4.2,0],[0,0,-rad(48)]);
cylinder(elbow,[0,0,-.67],[0,0,.67],.4,COL.metal,'arm',16);
for(const z of [-.44,.44]){box(elbow,[0,1.55,z],[.5,3.1,.17],COL.copper,'arm');for(const y of [.65,1.5,2.35])cylinder(elbow,[0,y,z-.12],[0,y,z+.12],.11,COL.black,'arm',10);}
const gripper=new Group(elbow,[0,3.3,0]);box(gripper,[0,0,0],[1.55,.35,1.1],COL.dark,'claw');
const clawServo=new Group(gripper,[0,.28,0],[0,0,Math.PI/2]);servo(clawServo,'claw');
const leftJaw=new Group(gripper,[-.55,.55,0]),rightJaw=new Group(gripper,[.55,.55,0]);
for(const [g,sgn] of [[leftJaw,-1],[rightJaw,1]]){box(g,[0,.65,0],[.24,1.3,.62],COL.metal,'claw');box(g,[-sgn*.22,1.27,0],[.58,.22,.62],COL.dark,'claw');cylinder(g,[0,0,-.4],[0,0,.4],.18,COL.copper,'claw');}
label('01  BASE / D5',baseServo,[0,.5,0],'base',[-65,22]);label('02  SHOULDER / D6',shoulder,[0,.3,.8],'shoulder',[58,-8]);label('03  CLAW / D8',gripper,[0,1,0],'claw',[25,-32]);
// Miniature laptop, keyboard and luminous display.
const laptop=new Group(root,[-8.3,.2,-4.2],[0,.12,0]);
box(laptop,[0,.12,0],[3.7,.24,2.45],COL.metal,'laptop');box(laptop,[0,.26,-.1],[3.2,.02,1.65],COL.dark,'laptop');
for(let row=0;row<4;row++)for(let col=0;col<10;col++)box(laptop,[-1.38+col*.305,.295,-.69+row*.3],[.24,.03,.19],'#75889b','laptop');
box(laptop,[0,.28,.83],[1,.02,.45],'#8196a7','laptop');
const lid=new Group(laptop,[0,.25,-1.12],[-rad(12),0,0]);box(lid,[0,1.26,0],[3.7,2.52,.13],COL.dark,'laptop');box(lid,[0,1.28,.076],[3.38,2.2,.025],'#183a47','laptop');
for(let i=0;i<7;i++)box(lid,[-.6,.52+i*.23,.099],[1.6-(i%3)*.31,.055,.01],i%2?'#72b89f':'#5b899c','laptop');
label('LAPTOP',lid,[0,2.6,0],'laptop',[0,-20]);
// Uno model with DIP MCU, USB-B, headers and dedicated cable endpoints.
const uno=new Group(root,[-1.8,.33,-3.6],[0,.04,0]);box(uno,[0,0,0],[2.85,.13,2.1],COL.pcb,'uno');box(uno,[.2,.19,.05],[1.32,.29,.42],COL.black,'uno');box(uno,[-1.1,.25,-.45],[.62,.55,.55],COL.metal,'uno');box(uno,[-1.1,.19,.45],[.48,.4,.43],COL.black,'uno');
for(const z of [-.88,.88])for(let i=0;i<12;i++){box(uno,[-1.17+i*.21,.17,z],[.16,.24,.19],COL.black,'uno');box(uno,[-1.17+i*.21,.3,z],[.065,.02,.065],COL.metal,'uno');}
for(let i=0;i<8;i++)for(const z of [-.27,.27])box(uno,[-.37+i*.16,.12,z],[.07,.03,.12],COL.metal,'uno');
label('ARDUINO UNO',uno,[0,.4,0],'uno',[0,-28]);
// Camera mounted upright, optical axis +Z. Exact carrier PCB is unknown.
const esp=new Group(root,[-7,0,.1]);box(esp,[0,.2,0],[2.1,.4,1.7],COL.dark,'esp');cylinder(esp,[0,.4,0],[0,2.1,0],.13,COL.metal,'esp');box(esp,[0,2.7,0],[1.55,2,.15],COL.pcb,'esp');box(esp,[0,2.25,-.16],[1.05,.8,.17],COL.metal,'esp');box(esp,[0,2.25,.15],[.68,.6,.3],COL.black,'esp');cylinder(esp,[0,2.75,.13],[0,2.75,.62],.35,COL.black,'esp',20);cylinder(esp,[0,2.75,.63],[0,2.75,.67],.24,'#5293ae','esp',20);
for(const x of [-.68,.68])for(let i=0;i<8;i++)box(esp,[x,1.89+i*.21,.14],[.1,.1,.16],COL.metal,'esp');
label('ESP32 + CAMERA',esp,[0,3.8,0],'esp',[-8,-16]);
// Independent servo and board rails, sharing only their ground reference.
const supply=new Group(root,[.3,.3,5.4]);box(supply,[0,.35,0],[2.8,.7,1.7],COL.dark,'servo-power');box(supply,[0,.72,0],[2.4,.025,1.28],'#34495a','servo-power');
for(const [x,c] of [[-.75,COL.power],[.75,COL.ground]])cylinder(supply,[x,.72,.48],[x,.92,.48],.17,c,'servo-power');
label('SERVO SUPPLY',supply,[0,1,0],'servo-power',[0,22]);
const logic=new Group(root,[-4,.2,-6]);box(logic,[0,.35,0],[2,.7,1.2],COL.dark,'logic-power');box(logic,[0,.72,0],[1.6,.02,.85],'#345846','logic-power');label('5V BOARD SUPPLY',logic,[0,.8,0],'logic-power',[0,-22]);
const bus=new Group(root,[.5,.26,2.9]);box(bus,[0,0,0],[2.15,.35,.6],COL.black,'ground');for(let i=0;i<6;i++)screw(bus,[-.83+i*.33,.22,0],'ground');
// Virtual hand: wrist is the tracked anchor. Fingers curl into the palm.
const hand=new Group(root),fingerGroups=[];cylinder(hand,[0,-1.75,0],[0,-.5,0],.23,'#6c9c88','hand');box(hand,[0,-1.6,0],[.59,.8,.49],COL.dark,'hand');box(hand,[0,.02,0],[.9,.9,.24],COL.hand,'hand');
for(let i=0;i<4;i++){let f=new Group(hand,[-.33+i*.22,.47,0]);fingerGroups.push(f);cylinder(f,[0,0,0],[0,.7+(i===1?.14:0),0],.09,COL.hand,'hand',8);let t=new Group(f,[0,.7+(i===1?.14:0),0]);fingerGroups.push(t);cylinder(t,[0,0,0],[0,.4,0],.085,COL.hand,'hand',8);}
const thumb=new Group(hand,[-.45,0,0],[0,0,.7]);cylinder(thumb,[0,0,0],[0,.7,0],.115,COL.hand,'hand',8);
function wire(id,color,points,width=.075,dashed=false){wires.push({id,color,points,width,dashed});}
const endpoint=(g,p)=>()=>g.world(p),wp=(x,y,z)=>()=>[x,y,z];
wire('usb',COL.data,[endpoint(laptop,[1.8,.1,.4]),wp(-5.4,.6,-3.4),wp(-5.4,.5,-1.5),endpoint(esp,[-.72,1.7,-.1])],.11);
wire('uart',COL.data,[endpoint(esp,[.68,2.31,.22]),wp(-5.6,1,-.8),wp(-3.8,.5,-2),endpoint(uno,[-1.17,.33,-.88])]);
wire('ground',COL.ground,[endpoint(esp,[.68,1.89,.22]),wp(-5.3,.3,1.2),endpoint(bus,[-.83,.22,0])]);
wire('ground',COL.ground,[endpoint(uno,[-.55,.33,.88]),wp(-2,.3,1.5),endpoint(bus,[-.5,.22,0])]);
wire('ground',COL.ground,[endpoint(supply,[.75,.92,.48]),wp(2,.4,4.5),endpoint(bus,[.83,.22,0])]);
wire('power',COL.power,[endpoint(logic,[-.6,.8,0]),wp(-6.4,.3,-5.7),endpoint(esp,[-.68,1.89,.22])]);
wire('power',COL.power,[endpoint(logic,[.6,.8,0]),wp(-1.4,.4,-5.7),endpoint(uno,[-.76,.33,.88])]);
wire('ground',COL.ground,[endpoint(logic,[0,.8,0]),wp(-3.5,.22,2),endpoint(bus,[-.16,.22,0])]);
// Signal, positive and return cables attach to the moving servo housings.
for(const [index,g,local] of [[0,baseServo,[.47,-.4,0]],[1,shoulderServo,[.47,-.4,0]],[2,clawServo,[.47,-.4,0]]]){
 const via=()=>yaw.world([-.7+index*.16,.3,1.1]);
 const points=(start,offset)=>[start,wp(1.7+offset,.6,1.7),()=>add(via(),[offset,0,0]),...(index===2?[()=>shoulder.world([.42,3.9,.8]),()=>elbow.world([.45,2.7,.75])]:[]),endpoint(g,local)];
 wire(['base','shoulder','claw'][index],COL.signal,points(endpoint(uno,[.08+index*.42,.33,-.88]),index*.13),.055);
 wire('power',COL.power,points(endpoint(supply,[-.75,.92,.48]),-.25+index*.08),.055);
 wire('ground',COL.ground,points(endpoint(bus,[.16+index*.32,.22,0]),.25+index*.08),.05);
}
wire('wifi',COL.data,[endpoint(esp,[-.5,3.6,0]),wp(-8.5,5,-1.5),endpoint(lid,[0,2.6,0])],.035,true);
const info={
 arm:['Three actuators, one control loop','Two positioning axes plus a gripper. The elbow bracket is fixed; no fourth servo is implied.'],
 base:['Base servo · Arduino D5','Rotates the complete upper arm left and right. Image x maps to 0–180°. Maximum command slew: 90°/s.'],
 shoulder:['Shoulder servo · Arduino D6','Raises and lowers both rigid links. Image y maps to 30–90°; lower angles lift this model. Maximum slew: 60°/s.'],
 claw:['Claw servo · Arduino D8','The open hand requests 150°; the closed fist requests 99°. Both jaws move through a conceptual symmetric linkage. Maximum slew: 120°/s.'],
 esp:['ESP32 with WROVER camera pin map','Streams MJPEG over Wi-Fi and relays laptop USB serial bytes from GPIO13 to Uno RX. GPIO14 is unused RX. Board shape is illustrative.'],
 uno:['Arduino Uno · servo controller','Receives framed packets on D0/RX, checks CRC, clamps angles and slews all three servos. Rest targets after 1 s without a valid packet: 90°, 90°, 150°.'],
 laptop:['Laptop · OpenCV + MediaPipe','Receives camera video over Wi-Fi, tracks one hand and sends servo targets through USB serial to the ESP32. The simulator uses a virtual hand.'],
 'servo-power':['External servo supply','Feeds all three servo positive leads directly. Choose voltage and current from the actual servos. Never route servo current through an Uno pin or regulator.'],
 'logic-power':['Regulated 5V board supply','Illustrates the user’s separate external board power. Feed a verified 5V input on each board; isolate USB VBUS when appropriate. Do not feed 5V into Uno VIN.'],
 uart:['UART · ESP32 GPIO13 → Uno D0/RX','115200 baud, one direction. ESP32 TX → Uno RX, plus common ground. Disconnect this lead when flashing the Uno; leave Uno TX unconnected.'],
 usb:['USB serial · laptop → ESP32','The supplied ESP32 sketch reads USB UART data. This is the command path; Wi-Fi carries video. External board power needs correct USB power isolation.'],
 wifi:['Wi-Fi video · ESP32 → laptop','Dashed blue arc represents wireless video, not a cable. Stream endpoint: http://ESP32-IP:81/stream.'],
 ground:['Shared ground reference','Board ground, Uno ground and servo supply negative are connected. Keep high-current servo returns on the power bus, away from logic signal wiring.'],
 power:['Power distribution','Red wires feed the boards from the 5V board supply and the servos from their own rated supply. Separate positive rails, shared ground.'],
 hand:['Virtual hand · camera input','Move in the side pad and change hand pose. Commands are produced only when the wrist is inside the camera frame and simulated distance limits.']
};
const focusPoints={arm:()=>[5.8,4.2,0],base:()=>baseServo.world(),shoulder:()=>shoulder.world(),claw:()=>gripper.world(),esp:()=>esp.world([0,2.5,0]),uno:()=>uno.world(),laptop:()=>laptop.world([0,1,0]),'servo-power':()=>supply.world(),'logic-power':()=>logic.world(),uart:()=>[-4,1,-1.7],ground:()=>bus.world(),usb:()=>[-6,1,-3],wifi:()=>[-8,4,-2]};
const state={hand:{x:.5,y:.5,depth:6,open:true},angles:[90,90,150],target:[90,60,150],lastSeen:0,tracked:true,demo:false,showWires:true,showFov:true,showLabels:true,selected:'arm',status:'IN VIEW'};
const camera={yaw:.32,pitch:.52,distance:37,target:[-.5,2.4,1]}, view={w:900,h:720,eye:[0,0,0],right:[1,0,0],up:[0,1,0],forward:[0,0,-1],scale:1};
let faces=[],pickFaces=[],pointer=null,drag=null,started=performance.now(),last=started,lastUI=0,gestureStart=0;
function cameraBasis(){const cp=Math.cos(camera.pitch);view.eye=add(camera.target,[camera.distance*Math.sin(camera.yaw)*cp,camera.distance*Math.sin(camera.pitch),camera.distance*Math.cos(camera.yaw)*cp]);view.forward=norm(sub(camera.target,view.eye));view.right=norm(cross(view.forward,[0,1,0]));view.up=cross(view.right,view.forward);view.scale=Math.min(view.w,view.h)*1.55;}
function project(p){const v=sub(p,view.eye),z=dot(v,view.forward);if(z<.1)return null;return [view.w/2+dot(v,view.right)*view.scale/z,view.h/2-dot(v,view.up)*view.scale/z,z];}
function shade(hex,light){const n=parseInt(hex.slice(1),16);return `rgb(${[n>>16,(n>>8)&255,n&255].map(v=>Math.round(clamp(v*light,0,255))).join(',')})`;}
function polygon(points,color,id,stroke=null,alpha=1){const p=points.map(project);if(p.some(x=>!x))return;faces.push({p,z:p.reduce((s,v)=>s+v[2],0)/p.length,color,id,stroke,alpha});}
function line(a,b,color,width,id,dashed=false){const p=[project(a),project(b)];if(p.some(v=>!v))return;faces.push({p,z:(p[0][2]+p[1][2])/2,color,id,width:Math.max(1.3,width*view.scale/((p[0][2]+p[1][2])/2)),line:true,dashed,alpha:1});}
function smoothPath(points){let out=[];for(let i=0;i<points.length-1;i++){let p0=points[Math.max(0,i-1)],p1=points[i],p2=points[i+1],p3=points[Math.min(points.length-1,i+2)];for(let j=0;j<10;j++){let t=j/10,t2=t*t,t3=t2*t;out.push(p1.map((_,k)=>.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t2+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t3)));}}out.push(points.at(-1));return out;}
function inPoly(x,y,p){let c=false;for(let i=0,j=p.length-1;i<p.length;j=i++){if(((p[i][1]>y)!==(p[j][1]>y))&&(x<(p[j][0]-p[i][0])*(y-p[i][1])/(p[j][1]-p[i][1])+p[i][0]))c=!c;}return c;}
function segmentDistance(x,y,a,b){let dx=b[0]-a[0],dy=b[1]-a[1],t=clamp(((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy||1),0,1);return Math.hypot(x-a[0]-t*dx,y-a[1]-t*dy);}
function pick(x,y){for(let i=pickFaces.length-1;i>=0;i--){let f=pickFaces[i];if(f.id&&(f.line?segmentDistance(x,y,...f.p)<Math.max(5,f.width):inPoly(x,y,f.p)))return f.id;}return null;}
function select(id){if(!info[id])return;state.selected=id;$('info-title').textContent=info[id][0];$('info-text').textContent=info[id][1];if([...$('inspect').options].some(o=>o.value===id))$('inspect').value=id;}
function focus(id){if(!focusPoints[id])return;camera.target=focusPoints[id]();camera.distance=id==='arm'?15:8;camera.pitch=.43;}
const origin=[-7,2.75,.77],tanV=Math.tan(rad(24)),aspect=4/3;
function handWorld(){let d=state.hand.depth;return [origin[0]+(.5-state.hand.x)*2*d*tanV*aspect,origin[1]+(.5-state.hand.y)*2*d*tanV,origin[2]+d];}
function update(dt,now){
 if(state.demo){let t=(now-gestureStart)/1000;state.hand.x=.5+.66*Math.sin(t*.7);state.hand.y=.5+.38*Math.cos(t*.93);state.hand.depth=6;state.hand.open=Math.sin(t*1.1)>-.2;}
 const h=state.hand;state.tracked=h.x>=0&&h.x<=1&&h.y>=0&&h.y<=1&&h.depth>=2&&h.depth<=10;
 if(state.tracked){state.lastSeen=now;state.target=[Math.round(clamp(h.x,0,1)*180),Math.round(30+clamp((h.y-.25)/.5,0,1)*60),h.open?150:99];}
 else if(now-state.lastSeen>=1000)state.target=[90,90,150];
 state.status=state.tracked?'IN VIEW':now-state.lastSeen<1000?'TRACKING LOST':'RETURNING TO REST';
 const rates=[90,60,120];state.angles=state.angles.map((v,i)=>v+clamp(state.target[i]-v,-rates[i]*dt,rates[i]*dt));
 yaw.r[1]=-rad(state.angles[0]-90);shoulder.r[2]=-rad(15+(state.angles[1]-30)*.65);
 let opening=(state.angles[2]-99)/51;leftJaw.r[2]=rad(4+opening*28);rightJaw.r[2]=-leftJaw.r[2];
 hand.p=handWorld();hand.r[1]=Math.PI;fingerGroups.forEach((f,i)=>{f.r[0]=h.open?0:rad(i%2?100:85);});thumb.r[2]=h.open?.7:-.4;thumb.r[0]=h.open?0:rad(50);
 groups.forEach(g=>g.update());
}
function draw(){
 cameraBasis();ctx.clearRect(0,0,view.w,view.h);faces=[];
 // Ground plane and dimensionless workbench grid.
 polygon([[-17,-.04,-12],[-17,-.04,15],[17,-.04,15],[17,-.04,-12]],'#192630',null);
 for(let x=-16;x<=16;x+=1)line([x,0,-12],[x,0,15],x%5===0?'#354552':'#263844',.018,null);
 for(let z=-12;z<=15;z+=1)line([-17,0,z],[17,0,z],z%5===0?'#354552':'#263844',.018,null);
 const background=faces;faces=[];
 for(const m of meshes){const vertices=m.v.map(p=>m.g.world(p));for(const f of m.f){let p=f.map(i=>vertices[i]),n=norm(cross(sub(p[1],p[0]),sub(p[2],p[0]))),light=.55+.43*Math.max(0,dot(n,norm([-.5,1,.8])));polygon(p,shade(m.color,light),m.id,'#00000015');}}
 if(state.showWires)for(const w of wires){let pts=smoothPath(w.points.map(f=>f()));for(let i=0;i<pts.length-1;i++)if(!w.dashed||Math.floor(i/3)%2===0)line(pts[i],pts[i+1],w.color,w.width,w.id);}
 if(state.showFov){const d=8.5,v=d*tanV,h=v*aspect,corners=[[-h,-v],[h,-v],[h,v],[-h,v]].map(([x,y])=>[origin[0]+x,origin[1]+y,origin[2]+d]);for(let i=0;i<4;i++){polygon([origin,corners[i],corners[(i+1)%4]],'#8fdcb5',null,null,.035);line(origin,corners[i],'#577f77',.022,null);line(corners[i],corners[(i+1)%4],'#83c5a5',.025,null);}const p=project(hand.world());if(p){ctx.fillStyle='#9ce7b2';}}
 faces.sort((a,b)=>b.z-a.z);faces=[...background,...faces];pickFaces=faces;
 for(const f of faces){ctx.globalAlpha=f.alpha;ctx.beginPath();ctx.moveTo(f.p[0][0],f.p[0][1]);for(let i=1;i<f.p.length;i++)ctx.lineTo(f.p[i][0],f.p[i][1]);if(f.line){ctx.strokeStyle=f.color;ctx.lineWidth=f.width;ctx.lineCap='round';ctx.stroke();}else{ctx.closePath();ctx.fillStyle=f.color;ctx.fill();if(f.stroke){ctx.strokeStyle=f.stroke;ctx.lineWidth=.5;ctx.stroke();}}}ctx.globalAlpha=1;
 if(state.showLabels){const placed=[];ctx.font='10px ui-monospace, monospace';for(const l of labels){let p=project(l.g.world(l.p));if(!p)continue;const width=ctx.measureText(l.text).width+16;let x=clamp(p[0]+l.offset[0]-width/2,8,view.w-width-8),y=p[1]+l.offset[1];if(y<105||y>view.h-88)continue;for(let tries=0;tries<5&&placed.some(r=>x<r.x+r.w&&x+width>r.x&&Math.abs(y-r.y)<22);tries++)y-=23;placed.push({x,y,w:width});ctx.strokeStyle='#617485';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(x+width/2,y+9);ctx.stroke();ctx.fillStyle='#111c27ed';ctx.fillRect(x,y-9,width,20);ctx.fillStyle='#d0dfeb';ctx.fillText(l.text,x+8,y+5);}}
 if(pointer&&!drag){const id=pick(...pointer),tip=$('tooltip');if(id&&info[id]){tip.style.display='block';tip.style.left=clamp(pointer[0]+14,5,view.w-244)+'px';tip.style.top=clamp(pointer[1]+14,70,view.h-80)+'px';tip.textContent=info[id][0];canvas.style.cursor='pointer';}else{tip.style.display='none';canvas.style.cursor='grab';}}
}
function padGeometry(){return {x:38,y:25,w:pad.clientWidth-76,h:pad.clientHeight-50};}
function drawPad(){const w=pad.clientWidth,h=pad.clientHeight,r=padGeometry();pc.clearRect(0,0,w,h);pc.fillStyle='#111a24';pc.fillRect(0,0,w,h);pc.fillStyle='#1e302f';pc.fillRect(r.x,r.y,r.w,r.h);pc.strokeStyle='#699c87';pc.lineWidth=1;pc.setLineDash([4,4]);pc.strokeRect(r.x,r.y,r.w,r.h);pc.setLineDash([]);pc.strokeStyle='#35494b';for(let i=1;i<4;i++){pc.beginPath();pc.moveTo(r.x+r.w*i/4,r.y);pc.lineTo(r.x+r.w*i/4,r.y+r.h);pc.stroke();pc.beginPath();pc.moveTo(r.x,r.y+r.h*i/4);pc.lineTo(r.x+r.w,r.y+r.h*i/4);pc.stroke();}
 pc.font='9px ui-monospace,monospace';pc.fillStyle='#9cb3b7';pc.fillText('CAMERA FRAME',r.x,r.y-8);pc.fillText('x →',w-36,h-8);pc.fillText('y ↓',7,h-8);
 let x=r.x+state.hand.x*r.w,y=r.y+state.hand.y*r.h;pc.save();pc.translate(x,y);pc.fillStyle=state.tracked?'#ace5bc':'#eaa68d';pc.strokeStyle=pc.fillStyle;pc.lineCap='round';pc.lineWidth=5;pc.fillRect(-7,-3,14,15);if(state.hand.open){for(let i=0;i<4;i++){pc.beginPath();pc.moveTo(-6+i*4,-1);pc.lineTo(-7+i*4,-15-(i===1?3:0));pc.stroke();}pc.beginPath();pc.moveTo(-7,5);pc.lineTo(-15,-2);pc.stroke();}else{pc.beginPath();pc.arc(0,0,9,0,TAU);pc.fill();}pc.restore();pc.strokeStyle=state.tracked?'#9ce7b277':'#ed9c7877';pc.beginPath();pc.arc(x,y,25,0,TAU);pc.stroke();
}
function refreshUI(){const names=['base','shoulder','claw'];names.forEach((n,i)=>$(n+'-value').textContent=Math.round(state.angles[i])+'°');$('status').textContent=state.status;$('status').style.color=state.tracked?'#9ce7b2':'#f3b38e';$('tracking-note').textContent=state.tracked?'Tracking → commands → servo motion':state.status==='TRACKING LOST'?'No commands. Holding last target for 1 s.':'No commands. Slewing to 90°, 90°, 150°.';$('open').setAttribute('aria-pressed',String(state.hand.open));$('closed').setAttribute('aria-pressed',String(!state.hand.open));$('depth-value').textContent=state.hand.depth.toFixed(1)+' units';$('depth').value=state.hand.depth;drawPad();}
function resize(){let ratio=Math.min(window.devicePixelRatio||1,2);view.w=canvas.clientWidth;view.h=canvas.clientHeight;canvas.width=view.w*ratio;canvas.height=view.h*ratio;ctx.setTransform(ratio,0,0,ratio,0,0);pad.width=pad.clientWidth*ratio;pad.height=pad.clientHeight*ratio;pc.setTransform(ratio,0,0,ratio,0,0);drawPad();}
function stopDemo(){state.demo=false;$('demo').setAttribute('aria-pressed','false');$('demo').textContent='Play gesture demo';}
function setHand(x,y){stopDemo();state.hand.x=clamp(x,-.2,1.2);state.hand.y=clamp(y,-.18,1.18);}
function padMove(e){const rect=pad.getBoundingClientRect(),r=padGeometry();setHand((e.clientX-rect.left-r.x)/r.w,(e.clientY-rect.top-r.y)/r.h);}
let padDrag=false;pad.addEventListener('pointerdown',e=>{padDrag=true;pad.setPointerCapture(e.pointerId);padMove(e);});pad.addEventListener('pointermove',e=>{if(padDrag)padMove(e);});for(const ev of ['pointerup','pointercancel','lostpointercapture'])pad.addEventListener(ev,()=>padDrag=false);
pad.addEventListener('keydown',e=>{let x=state.hand.x,y=state.hand.y;if(e.key==='ArrowLeft')x-=.04;else if(e.key==='ArrowRight')x+=.04;else if(e.key==='ArrowUp')y-=.04;else if(e.key==='ArrowDown')y+=.04;else if(e.key===' '){state.hand.open=!state.hand.open;}else return;e.preventDefault();setHand(x,y);});
$('open').onclick=()=>{stopDemo();state.hand.open=true;};$('closed').onclick=()=>{stopDemo();state.hand.open=false;};$('depth').oninput=e=>{stopDemo();state.hand.depth=Number(e.target.value);};$('outside').onclick=()=>setHand(1.16,.5);$('center').onclick=()=>{setHand(.5,.5);state.hand.depth=6;};$('demo').onclick=()=>{if(state.demo)stopDemo();else{state.demo=true;gestureStart=performance.now();$('demo').textContent='Pause gesture demo';$('demo').setAttribute('aria-pressed','true');}};
$('view-all').onclick=()=>{camera.yaw=.32;camera.pitch=.52;camera.distance=37;camera.target=[-.5,2.4,1];};$('view-arm').onclick=()=>focus('arm');$('view-wiring').onclick=()=>{camera.yaw=.1;camera.pitch=.95;camera.distance=23;camera.target=[-3.4,1,-.3];};$('zoom-in').onclick=()=>camera.distance=clamp(camera.distance*.82,5,65);$('zoom-out').onclick=()=>camera.distance=clamp(camera.distance/ .82,5,65);
$('wires').onchange=e=>state.showWires=e.target.checked;$('fov').onchange=e=>state.showFov=e.target.checked;$('labels').onchange=e=>state.showLabels=e.target.checked;$('inspect').onchange=e=>select(e.target.value);$('focus').onclick=()=>focus(state.selected);
const pointers=new Map();let pinchDistance=0;
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);drag={x:e.clientX,y:e.clientY,pan:e.shiftKey||e.button===2,moved:0};$('tooltip').style.display='none';if(pointers.size===2){let a=[...pointers.values()];pinchDistance=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);}});
canvas.addEventListener('pointermove',e=>{const rect=canvas.getBoundingClientRect();pointer=[e.clientX-rect.left,e.clientY-rect.top];if(!pointers.has(e.pointerId))return;pointers.set(e.pointerId,[e.clientX,e.clientY]);if(pointers.size===2){let a=[...pointers.values()],d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);camera.distance=clamp(camera.distance*pinchDistance/Math.max(d,1),5,65);pinchDistance=d;drag.moved=20;return;}if(!drag)return;let dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved+=Math.abs(dx)+Math.abs(dy);drag.x=e.clientX;drag.y=e.clientY;if(drag.pan){const scale=camera.distance/view.scale;camera.target=add(camera.target,add(mul(view.right,-dx*scale),mul(view.up,dy*scale)));}else{camera.yaw-=dx*.007;camera.pitch=clamp(camera.pitch+dy*.006,.08,1.48);}});
function endPointer(e){pointers.delete(e.pointerId);if(drag&&drag.moved<5&&pointer)select(pick(...pointer));drag=null;}
for(const ev of ['pointerup','pointercancel'])canvas.addEventListener(ev,endPointer);canvas.addEventListener('pointerleave',()=>{pointer=null;$('tooltip').style.display='none';});canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('dblclick',()=>{if(pointer){const id=pick(...pointer);if(id)focus(id);}});
canvas.addEventListener('wheel',e=>{e.preventDefault();camera.distance=clamp(camera.distance*Math.exp(e.deltaY*.001),5,65);},{passive:false});canvas.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')camera.yaw-=.1;else if(e.key==='ArrowRight')camera.yaw+=.1;else if(e.key==='ArrowUp')camera.pitch=clamp(camera.pitch+.08,.08,1.48);else if(e.key==='ArrowDown')camera.pitch=clamp(camera.pitch-.08,.08,1.48);else if(e.key==='+'||e.key==='=')camera.distance=clamp(camera.distance*.9,5,65);else if(e.key==='-')camera.distance=clamp(camera.distance/ .9,5,65);else return;e.preventDefault();});
function tick(now){try{let dt=clamp((now-last)/1000,0,.1);last=now;update(dt,now);draw();if(now-lastUI>50){refreshUI();lastUI=now;}requestAnimationFrame(tick);}catch(e){$('error').style.display='block';$('error').textContent='The simulation stopped: '+e.message;console.error(e);}}
window.addEventListener('resize',resize);resize();update(0,started);refreshUI();requestAnimationFrame(tick);
// Read-only snapshots plus deterministic test stepping; no hardware/network side effects.
window.GestureLab={snapshot:()=>JSON.parse(JSON.stringify({hand:state.hand,angles:state.angles,target:state.target,tracked:state.tracked,status:state.status,camera,meshes:meshes.length,wires:wires.length})),setHand:(x,y,depth,open)=>{setHand(x,y);state.hand.depth=depth;state.hand.open=open;},step:(seconds,now)=>{update(seconds,now);draw();refreshUI();},project,focus,render:draw};
})();
