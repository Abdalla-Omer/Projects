"""Small, lossless-atom S-expression reader for this repository's KiCad files."""
import json
import re


class Atom(str):
    def __new__(cls, value, raw=None):
        result = str.__new__(cls, value)
        result.raw = value if raw is None else raw
        return result


def quoted(value):
    return Atom(value, json.dumps(value, ensure_ascii=False))


def parse(text):
    stack = []
    root = None
    for token in re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+', text):
        if token == '(':
            node = []
            if stack:
                stack[-1].append(node)
            elif root is not None:
                raise ValueError('Multiple root expressions')
            else:
                root = node
            stack.append(node)
        elif token == ')':
            if not stack:
                raise ValueError('Unmatched closing parenthesis')
            stack.pop()
        else:
            if not stack:
                raise ValueError('Atom outside a root expression')
            value = json.loads(token) if token.startswith('"') else token
            stack[-1].append(Atom(value, token))
    if stack or root is None:
        raise ValueError('Unbalanced or empty expression')
    return root


def children(node, name):
    return [item for item in node if isinstance(item, list) and item and item[0] == name]


def emit(node, level=0):
    if not isinstance(node, list):
        return node.raw
    if not any(isinstance(item, list) for item in node):
        return '(' + ' '.join(emit(item) for item in node) + ')'
    first_nested = next(i for i, item in enumerate(node) if isinstance(item, list))
    opening = '(' + ' '.join(emit(item) for item in node[:first_nested])
    nested = ['\t' * (level + 1) + emit(item, level + 1) for item in node[first_nested:]]
    return opening + '\n' + '\n'.join(nested) + '\n' + '\t' * level + ')'
