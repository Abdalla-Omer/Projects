"""Verify packaging integrity only. This does NOT run KiCad ERC or DRC."""
import hashlib
import json
from pathlib import Path
import zipfile

from kicad_sexpr import children, parse
from recover_footprints import expected_footprints

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    manifest = json.loads((ROOT / 'provenance/upload-manifest.json').read_text())
    records = manifest['files']
    require(len(records) == 9, 'Expected all nine supplied files')
    with zipfile.ZipFile(ROOT / 'provenance/original-uploads.zip') as archive:
        require(set(archive.namelist()) == {r['archive_member'] for r in records}, 'Archive inventory differs')
        for record in records:
            original = archive.read(record['archive_member'])
            require(len(original) == record['size_bytes'], 'Original byte count differs')
            require(hashlib.sha256(original).hexdigest() == record['sha256'], 'Original hash differs')
            if record['repository_path']:
                require((ROOT / record['repository_path']).read_bytes() == original,
                        'Mapped source changed: ' + record['repository_path'])
    print('PASS: all nine originals and eight active source copies preserved')

    project = json.loads((ROOT / 'hardware/Drone_sensors.kicad_pro').read_text())
    json.loads((ROOT / 'docs/source/custom_checks.json').read_text())
    require(project['meta']['filename'] == 'Drone_sensors.kicad_pro', 'Project filename mismatch')
    for sheet in project['schematic']['top_level_sheets']:
        require((ROOT / 'hardware' / sheet['filename']).is_file(), 'Missing project sheet')
    board = parse((ROOT / 'hardware/Drone_sensors.kicad_pcb').read_text())
    schematic = parse((ROOT / 'hardware/Drone_sensors.kicad_sch').read_text())
    require(board[0] == 'kicad_pcb' and schematic[0] == 'kicad_sch', 'Unexpected file root')
    require(len(children(board, 'footprint')) == 60, 'Placed footprint count differs')
    require(len(children(board, 'segment')) == 622, 'Track count differs')
    require(len(children(board, 'via')) == 106, 'Via count differs')
    print('PASS: project naming, parsed source formats, and PCB inventory')

    for table_name in ['fp-lib-table', 'sym-lib-table']:
        table = parse((ROOT / 'hardware' / table_name).read_text())
        for library in children(table, 'lib'):
            uri = str(children(library, 'uri')[0][1])
            require(uri.startswith('${KIPRJMOD}/'), 'Unexpected non-local library URI')
            path = ROOT / 'hardware' / uri.removeprefix('${KIPRJMOD}/')
            require(path.exists(), 'Unresolved library: ' + uri)
    symbols = parse((ROOT / 'hardware/Drone_Sensors.kicad_sym').read_text())
    names = {str(s[1]) for s in children(symbols, 'symbol')}
    for instance in children(schematic, 'symbol'):
        for lib_id in children(instance, 'lib_id'):
            if lib_id[1].startswith('Drone_Sensors:'):
                require(str(lib_id[1]).split(':', 1)[1] in names, 'Missing local symbol')
    print('PASS: project-local library tables and custom symbol references resolve')

    expected = expected_footprints()
    actual_paths = list((ROOT / 'hardware/Drone_Sensors.pretty').glob('*.kicad_mod'))
    require({p.stem for p in actual_paths} == set(expected), 'Custom footprint file set differs')
    for name, definition in expected.items():
        actual = parse((ROOT / 'hardware/Drone_Sensors.pretty' / (name + '.kicad_mod')).read_text())
        require(actual == definition, 'Recovered definition differs from board: ' + name)
    print('PASS: all four recovered footprint definitions match normalized board instances')
    print('Native KiCad ERC/DRC has NOT been run by this check.')


if __name__ == '__main__':
    main()
