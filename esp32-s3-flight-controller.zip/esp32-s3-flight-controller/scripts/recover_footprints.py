"""Recover this board's four unrotated project-local footprint definitions.

The PCB itself is never modified. Native KiCad validation remains required.
"""
from copy import deepcopy
from pathlib import Path

from kicad_sexpr import Atom, children, emit, parse, quoted

ROOT = Path(__file__).resolve().parents[1]
BOARD = ROOT / 'hardware/Drone_sensors.kicad_pcb'
LIBRARY = ROOT / 'hardware/Drone_Sensors.pretty'


def normalized_footprint(footprint, board_version):
    placement = children(footprint, 'at')
    if len(placement) != 1:
        raise ValueError('Expected one placement')
    if len(placement[0]) > 3 and float(placement[0][3]) % 360 != 0:
        raise ValueError('Rotated footprints require native KiCad export')
    if children(footprint, 'layer') != [['layer', 'F.Cu']]:
        raise ValueError('Back-side footprints require native KiCad export')

    def clean(node, top=False):
        result = []
        for item in node:
            if isinstance(item, list):
                key = item[0]
                if key == 'uuid':
                    continue
                if top and key in {'at', 'path', 'sheetname', 'sheetfile', 'units', 'version', 'generator'}:
                    continue
                if node[0] == 'pad' and key in {'net', 'pinfunction', 'pintype'}:
                    continue
                if top and key == 'property' and item[1] == 'ki_fp_filters':
                    continue
                item = clean(item)
                if top and key == 'property' and item[1] == 'Reference':
                    item[2] = quoted('REF**')
            result.append(item)
        return result

    result = clean(deepcopy(footprint), top=True)
    result[1] = quoted(str(result[1]).split(':', 1)[1])
    result[2:2] = [[Atom('version'), board_version], [Atom('generator'), quoted('pcbnew')]]
    return result


def expected_footprints():
    board = parse(BOARD.read_text())
    version = children(board, 'version')[0][1]
    found = {}
    for footprint in children(board, 'footprint'):
        if footprint[1].startswith('Drone_Sensors:'):
            name = str(footprint[1]).split(':', 1)[1]
            if name in found:
                raise ValueError('Duplicate project-local footprint name: ' + name)
            found[name] = normalized_footprint(footprint, version)
    if len(found) != 4:
        raise ValueError('Expected exactly four custom footprints')
    return found


def main():
    expected = expected_footprints()
    LIBRARY.mkdir(parents=True, exist_ok=True)
    for name, footprint in expected.items():
        target = LIBRARY / (name + '.kicad_mod')
        target.write_text(emit(footprint) + '\n')
        if parse(target.read_text()) != footprint:
            raise ValueError('Recovery round-trip failed: ' + name)
        print('Recovered ' + target.relative_to(ROOT).as_posix())


if __name__ == '__main__':
    main()
