# Validation and release checks

## Supplied baseline

The uploaded notes report a previous native DRC result of **17 errors and 19 warnings**, and an ERC result of **0 errors and 20 warnings**. These baseline reports themselves were not attached, and the counts do not establish the state of the current revision.

The supplied custom-check JSON records 43 connected active nets, 622 track segments, 106 vias, a minimum drill of 0.30 mm, and no violations in its custom clearance lists. Those results were supplied with the design; the custom electrical/clearance checker was not attached and has not been rerun here.

See the unchanged [change notes](source/FIXES_AND_CHECKS.txt) and [custom-check results](source/custom_checks.json).

## Checks performed during repository preparation

- Parsed the PCB, schematic, custom symbols, and recovered footprints as balanced S-expressions, and parsed both supplied JSON files.
- Confirmed project, PCB, and schematic naming matches the existing project metadata and schematic instance name.
- Preserved the uploaded project, PCB, schematic, symbol library, library tables, and check records byte for byte at their mapped paths.
- Preserved all nine originals inside `provenance/original-uploads.zip` and recorded SHA-256 hashes.
- Recovered all four project-local footprints, removing instance-specific metadata while retaining geometry, pad numbers, drills, models, and antenna keepout rules.
- Compared every recovered definition against its corresponding board instance after the same documented metadata normalization.
- Resolved project-local symbol and footprint references to the included files.

These are repository-integrity checks. Native KiCad was unavailable during packaging, so no native load, ERC, DRC, schematic parity check, 3D inspection, or fabrication export was performed.

## Native KiCad verification

Open `hardware/Drone_sensors.kicad_pro` in KiCad 10. Verify that both local libraries load and compare the recovered footprints with the board instances. In the GUI, run ERC and DRC with schematic parity enabled, inspect all findings, and save the reports.

From the repository root, with KiCad 10 installed, these commands can produce reports:

```sh
mkdir -p reports
kicad-cli sch erc --exit-code-violations --output reports/erc.rpt hardware/Drone_sensors.kicad_sch
kicad-cli pcb drc --schematic-parity --exit-code-violations --output reports/drc.rpt hardware/Drone_sensors.kicad_pcb
```

Check `kicad-cli sch erc --help` and `kicad-cli pcb drc --help` for the installed build. No execution of these commands is claimed in this repository.

Command reference: [official KiCad 10 CLI documentation](https://docs.kicad.org/10.0/en/cli/cli.html).

Before a fabrication release, also verify the U2 land pattern and grounded FSYNC configuration, U4 antenna keepout and thermal drills, connector orientation, input power selection, and resolved standard-library 3D models. Then regenerate fabrication outputs and any enclosure model from the validated board.

No Gerbers, drill package, STL, assembly evidence, or flight-test results were provided or generated as release artifacts.
