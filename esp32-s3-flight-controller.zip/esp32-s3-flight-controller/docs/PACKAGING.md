# Repository packaging

The repository name is `esp32-s3-flight-controller`. The KiCad project retains its existing internal name, `Drone_sensors`.

## File mapping

| Uploaded name | Active location |
| --- | --- |
| `Drone(1).kicad_pro` | `hardware/Drone_sensors.kicad_pro` |
| `Drone(1).kicad_pcb` | `hardware/Drone_sensors.kicad_pcb` |
| `Drone_sensors(1).kicad_sch` | `hardware/Drone_sensors.kicad_sch` |
| `Drone.kicad_sym` | `hardware/Drone_Sensors.kicad_sym` |
| `fp-lib-table` | `hardware/fp-lib-table` |
| `sym-lib-table` | `hardware/sym-lib-table` |
| `FIXES_AND_CHECKS.txt` | `docs/source/FIXES_AND_CHECKS.txt` |
| `custom_checks.json` | `docs/source/custom_checks.json` |
| `Drone(1).kicad_prl` | Original archive only; per-user view preferences are excluded from active version control |

All original bytes are retained in `provenance/original-uploads.zip`, including the original names. The mapped active files also retain their original bytes. No tracks, component positions, net assignments, or project rule settings were edited during packaging.

## Footprint recovery

The attached `fp-lib-table` referenced `Drone_Sensors.pretty`, which was not supplied. Four embedded board footprints use that library namespace. All four are on `F.Cu` with zero module rotation; the recovery script rejects other placements rather than guessing coordinate transforms.

The script removes board placement, schematic linkage, UUIDs, per-pad nets and electrical pin metadata, and the schematic filter property. It substitutes `REF**` for the instance reference and removes the library prefix from the footprint name. It retains the pad geometry, drills, local graphic coordinates, models, and footprint rule areas. The standard KiCad footprint version and generator header are added.

To regenerate the four standalone files from the unchanged board:

```sh
python3 scripts/recover_footprints.py
python3 scripts/check_repository.py
```

The recovered files are derived assets, not a claim that the missing standalone originals were found or that the land patterns have been independently qualified. Their KiCad-native behavior remains to be checked.

## GitHub publishing

Suggested repository description: `Custom ESP32-S3 drone flight-controller PCB with IIM-42652, MS5611, USB-C, and GPS UART; KiCad hardware prototype.`

Suggested topics: `esp32-s3`, `flight-controller`, `kicad`, `pcb-design`, `embedded-systems`, `drone`.

Git is initialized on `main` in the prepared working repository. To publish after connecting GitHub, create a repository named `esp32-s3-flight-controller` and push `main`. No hosted repository URL is asserted until creation and push are confirmed.

If using GitHub CLI from a fresh extracted source ZIP, initialize Git first if needed, then create a private repository:

```sh
git init -b main
git add .
git commit -m "Import ESP32-S3 flight-controller hardware"
gh repo create esp32-s3-flight-controller --private --source=. --remote=origin --push
```

The ZIP is a source distribution and excludes `.git`. Skip initialization and the initial commit if using the already initialized working repository. Choose public visibility only if you intend to publish the design openly.
