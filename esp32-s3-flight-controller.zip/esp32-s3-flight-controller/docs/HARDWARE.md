# Hardware reference

This is a source-derived inventory, not a bring-up report. Component values and net names below were read from the uploaded PCB. Connector pin numbers refer to pad numbers; check the schematic and physical pin-1 marking before wiring.

## Main components

| Reference | Value | Role |
| --- | --- | --- |
| U4 | ESP32-S3-WROOM-1 | Main controller module |
| U2 | IIM-42652 | Inertial sensor |
| U5 | MS5611-01BA | Pressure sensor |
| U1 | AP63203WU | Power conversion |
| U3 | USBLC6-2SC6 | USB protection |
| J2 | USB_C_Receptacle_USB2.0_16P | USB interface |
| J3 | GPS_UART | GPS header |

## Selected connector mappings

These tables describe present connectivity only. They do not certify compatibility with an external module or define a complete firmware pin assignment.

| Connector | Pin | Board connection |
| --- | --- | --- |
| J3 | 1 | +3V3 |
| J3 | 2 | GND |
| J3 | 3 | U4 IO18 |
| J3 | 4 | U4 IO17 |
| J10 | 1 | GND |
| J10 | 2 | U4 TXD0 |
| J10 | 3 | U4 RXD0 |
| J10 | 4 | U4 EN |
| J10 | 5 | U4 IO0 |
| J10 | 6 | +3V3 |
| J11 | 1 | GND |
| J11 | 2 | +3V3 |
| J11 | 3 | U4 IO12 / U2 pad 13 |
| J11 | 4 | U4 IO13 / U2 pad 14 |
| J11 | 5 | U4 IO14 / U2 pad 1 |
| J11 | 6 | U4 IO21 / U2 pad 12 |

The board labels J3 as `GPS_UART`; no external GPS model, supply compatibility, or UART direction is assumed from that label. The wider project discussion mentioned a DJI GPS puck, but its adapter and electrical compatibility are outside this uploaded design package.

## Recorded firmware requirement

The following is carried forward from [FIXES_AND_CHECKS.txt](source/FIXES_AND_CHECKS.txt), rather than newly verified here:

- U2 pin 9 is grounded and is intended to remain an unused FSYNC input.
- The notes specify bank 1, `INTF_CONFIG5` at `0x7B`, and `PIN9_FUNCTION[2:1] = 01` during initialization, preserving the other bits.
- Keep INT2 output disabled on this grounded pin.
- INT1 is connected to ESP32 GPIO15.

Confirm that requirement against the exact sensor revision and its documentation before implementing firmware or powering assembled hardware.

## Local library provenance

The local symbol file was supplied as `Drone.kicad_sym` and is installed here as `Drone_Sensors.kicad_sym` to match the existing table. It contains `PWR_FLAG` and `IIM-42652_FSYNC`.

Four board footprints use the `Drone_Sensors` namespace. Their standalone definitions were absent from the attachments and have been recovered from the embedded board instances:

| Board reference | Library footprint |
| --- | --- |
| U4 | `Drone_Sensors:ESP32-S3-WROOM-1` |
| U2 | `Drone_Sensors:Bosch_LGA-14_3x2.5mm_P0.5mm` |
| U5 | `Drone_Sensors:LGA-8_3x5mm_P1.25mm` |
| J3 | `Drone_Sensors:PinHeader_1x04_P2.54mm_Vertical` |

U2's footprint identifier retains the uploaded `Bosch_LGA-14` name. The fitted symbol value is IIM-42652. The name and geometry have been preserved; confirm the land pattern against the intended device before fabrication.
