# ESP32-S3 Flight Controller PCB

A custom two-layer drone flight-controller PCB built around the **ESP32-S3-WROOM-1**, with an **IIM-42652** inertial sensor, **MS5611-01BA** pressure sensor, USB-C, and a GPS UART header.

**Status: hardware design prototype.** This repository contains the schematic, routed PCB, project rules, and local libraries. Native KiCad ERC/DRC remains pending for the supplied revision. Firmware, assembly results, and flight-test evidence are not included.

## Hardware at a glance

| Block | Implementation in the uploaded design |
| --- | --- |
| Controller | U4 — ESP32-S3-WROOM-1 |
| Inertial sensor | U2 — IIM-42652 |
| Pressure sensor | U5 — MS5611-01BA |
| Power | U1 — AP63203WU; +5V and +3V3 rails; input jumper and polyfuse |
| USB | J2 — USB-C USB 2.0 connector; U3 — USBLC6-2SC6 protection |
| GPS interface | J3 — four-pin GPS_UART header |
| PCB | Front and back copper; 1.6 mm nominal thickness; 60 placed footprints |
| CAD source | KiCad 10.0 file headers |

The wider project has been discussed as a custom flight controller for flood reconnaissance, with a separate UNO Q ground station. This repository covers the controller hardware; that mission concept is future system context.

## Open the design

1. Install KiCad 10 with its standard symbol, footprint, and 3D-model libraries.
2. Clone or download this repository and keep the `hardware` folder intact.
3. Open **[hardware/Drone_sensors.kicad_pro](hardware/Drone_sensors.kicad_pro)** through KiCad Project Manager.
4. Open the schematic and PCB from that project. Both files share its basename.
5. Follow **[Validation and release checks](docs/VALIDATION.md)** before fabrication.

The custom symbol-library filename now matches `sym-lib-table`. The missing standalone footprint folder has been recovered from the four custom footprints embedded in the uploaded board. Their geometric definitions are checked against that board; a native KiCad load and library comparison is still required.

## Repository contents

| Location | Contents |
| --- | --- |
| `hardware/` | Editable project, schematic, PCB, and project-local library tables |
| `hardware/Drone_Sensors.kicad_sym` | Supplied custom power-flag and IIM-42652 FSYNC symbols |
| `hardware/Drone_Sensors.pretty/` | Four footprints recovered from the board |
| [docs/HARDWARE.md](docs/HARDWARE.md) | Components, connector mappings, and the firmware requirement recorded in the source notes |
| [docs/VALIDATION.md](docs/VALIDATION.md) | Baseline reports, verification limits, and native KiCad commands |
| `docs/source/` | Original change notes and custom-check results, unchanged |
| [docs/PACKAGING.md](docs/PACKAGING.md) | File mapping and footprint-recovery details |
| `provenance/` | All nine original uploads in a ZIP, with SHA-256 manifest |
| `scripts/` | Dependency-free footprint recovery and repository-integrity checks |

## Check repository integrity

```sh
python3 scripts/check_repository.py
```

The GitHub Actions workflow runs this same check. It verifies file preservation, local library references, and recovered footprint geometry. **It does not run electrical or PCB design-rule checks.**

## Design note to carry into firmware

The supplied revision notes state that **U2 pin 9 is tied to GND** and must be configured as an unused FSYNC input, with INT2 output disabled. See [the recorded requirement](docs/HARDWARE.md#recorded-firmware-requirement) and verify it against the device documentation before implementing initialization.

## Licensing

No project license has been selected. Existing third-party library notices and provenance are retained; packaging these files does not relicense those assets.
