"""Export static, editable SVG versions of both circuit views."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
text=(root/'src/circuit.svg').read_text()
text=re.sub(r'&(?!amp;|lt;|gt;|quot;|apos;|#)', '&amp;', text)
(root/'src/circuit.svg').write_text(text)
css=(root/'src/style.css').read_text()
styles=''.join(re.findall(r'\.schematic[^{}]*\{[^{}]*\}',css))
ET.register_namespace('', 'http://www.w3.org/2000/svg')
ns={'s':'http://www.w3.org/2000/svg'}
for kind in ['system','original']:
 tree=ET.fromstring(text)
 tree.set('width','1320');tree.set('height','850')
 for group in list(tree.findall('s:g',ns)):
  keep=(group.get('id')=='functional-circuit')==(kind=='system')
  if not keep:tree.remove(group)
  else:group.attrib.pop('style',None)
 style=ET.Element('{http://www.w3.org/2000/svg}style');style.text=styles
 tree.insert(0,style)
 if kind=='system':
  for node in tree.iter():
   if node.get('id')=='s-cap':node.text='4.00 V · 96.0 J'
 output=root/'hardware'/('system-circuit.svg' if kind=='system' else 'original-switch-audit.svg')
 output.write_bytes(ET.tostring(tree,encoding='utf-8',xml_declaration=True))
 print(output.name)
