"""Build two fully standalone offline pages from shared source. Python stdlib only."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
src, docs = root/'src', root/'docs'
base=(src/'shell.html').read_text()
base=base.replace('{{CSS}}',(src/'style.css').read_text())
for view,filename in [('3d','solar-cleaner-3d.html'),('2d','solar-cleaner-circuit.html')]:
    is3d=view=='3d'
    values={
        'TITLE':'3D desert installation' if is3d else '2D circuit explorer',
        'VIEW':view,'ACTIVE3D':'active' if is3d else '', 'ACTIVE2D':'' if is3d else 'active',
        'EYEBROW':'01 / THERMAL LANDSCAPE' if is3d else '01 / ELECTRICAL PATH',
        'SCENETITLE':'Desert installation · underground concept' if is3d else 'Harvest, store, enable, sweep',
        'HINT':'Drag to orbit · Scroll to zoom · Shift-drag to pan<br>Hover for names · Click to inspect' if is3d else 'Drag to pan · Scroll or buttons to zoom<br>Click a component to inspect its role',
        'CANVAS':'<canvas id="scene" tabindex="0" aria-label="3D desert solar cleaner with panel, brush, TEGs, capacitor bank and underground thermal cutaway"></canvas>' if is3d else (src/'circuit.svg').read_text(),
        'TOOLS':'<button id="overview">Overview</button>'+('<button id="heat-view">Heat path</button><button id="panel-view">Panel</button><button id="wire-view">Wiring</button>' if is3d else '<button id="system-view" aria-pressed="true">System circuit</button><button id="original-view" aria-pressed="false">Original sketch</button>')+'<button id="zoom-in" aria-label="Zoom in">＋</button><button id="zoom-out" aria-label="Zoom out">−</button>',
        'CHECKS':'<label><input id="show-labels" type="checkbox" checked> Labels</label><label><input id="show-heat" type="checkbox" checked> Heat flow</label><label><input id="show-wires" type="checkbox" checked> Wiring</label><label><input id="cutaway" type="checkbox" checked> Soil cutaway</label>' if is3d else '',
    }
    scripts=['model.js']+(['renderer.js','scene.js'] if is3d else ['circuit.js'])+['app.js']
    values['SCRIPTS']='\n'.join('<script>\n'+(src/name).read_text()+'\n</script>' for name in scripts)
    html=base
    for k,v in values.items():html=html.replace('{{'+k+'}}',v)
    assert '{{' not in html and 'src="http' not in html
    (docs/filename).write_text(html)
    print('Built',filename,len(html.encode()),'bytes')
