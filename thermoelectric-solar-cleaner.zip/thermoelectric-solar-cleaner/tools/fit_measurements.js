#!/usr/bin/env node
/* Derives a source model from measured open/loaded voltage, current and ΔT.
   Does not pretend that an open-circuit voltage provides resistance or power. */
'use strict';const fs=require('node:fs');
if(!process.argv[2])throw Error('Usage: node tools/fit_measurements.js measurements.json');
const m=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
for(const k of['tegCount','hotC','coldC','openCircuitV','loadedV','loadedA'])if(!Number.isFinite(m[k]))throw Error('A measured number is required: '+k);
const delta=m.hotC-m.coldC;
if(delta<=0||m.loadedA<=0||m.loadedV<=0||m.loadedV>=m.openCircuitV||m.tegCount<1)throw Error('Need hot > cold, current > 0 and 0 < loaded voltage < open-circuit voltage');
const seriesR=(m.openCircuitV-m.loadedV)/m.loadedA;
console.log(JSON.stringify({note:'Linear source fit at the recorded temperatures, not a universal TEG rating',parameters:{tegCount:m.tegCount,seebeck:m.openCircuitV/(m.tegCount*delta),rPerTeg:seriesR/m.tegCount},derived:{deltaK:delta,seriesResistanceOhm:seriesR,observedLoadedPowerW:m.loadedV*m.loadedA,linearMaximumPowerW:m.openCircuitV**2/(4*seriesR)}},null,2));
