#!/usr/bin/env node
'use strict';
const fs=require('node:fs'),path=require('node:path'),M=require('../src/model.js');
const args=process.argv.slice(2),value=(flag,fallback)=>args.includes(flag)?args[args.indexOf(flag)+1]:fallback;
if(args.includes('--help')){console.log('node tools/calculate.js [--config parameters.json] [--hours 24] [--out results.json]');process.exit(0);}
const configPath=value('--config',null),config=configPath?JSON.parse(fs.readFileSync(configPath,'utf8')):{},p=M.parameters(config.parameters||config),hours=Number(value('--hours','24'));
if(!Number.isFinite(hours)||hours<0||hours>168)throw Error('--hours must be between 0 and 168');
const simulation=new M.Simulation(p),before=simulation.snapshot();simulation.advance(hours*3600);const after=simulation.snapshot();
const result={schema:'thermoelectric-solar-cleaner/results-v1',classification:'Assumption-based prediction; not a measured project result',parameters:p,thermal:M.thermal(p),electrical:M.source(p),predictions:{firstChargeSeconds:before.firstCharge,rechargeSeconds:before.recharge,poweredBurstSeconds:before.sweepEstimate,energyAtOnJ:M.energy(p,p.vOn),energyAtOffJ:M.energy(p,p.vOff),usableBurstJ:before.usableJ,maximumRatedEnergyJ:M.energy(p,p.capRating)},run:{hours,...after,totalPoweredSeconds:simulation.totalOn,harvestedJ:simulation.harvestedJ,leakageJ:simulation.leakJ,loadFromCapJ:simulation.loadJ,loadTerminalJ:simulation.loadJ-simulation.esrJ,curtailedJ:simulation.curtailedJ},events:simulation.events};
const out=value('--out',null);if(out){fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,JSON.stringify(result,null,2)+'\n');console.log('Saved',out);}else console.log(JSON.stringify(result,null,2));
