# System and repository architecture

```mermaid
flowchart TD
  H["Heated absorber"] -->|"Heat"| T["Three TEGs"]
  T -->|"Heat"| C["Cold plate and sink"]
  T -->|"Electrical power"| B["BQ25570 boost charger"]
  B --> S["Parallel supercapacitors"]
  S --> G["Hysteretic load gate"]
  S -->|"Voltage sense"| K["Threshold controller"]
  K -->|"Enable"| G
  G --> P["Servo tester and servo"]
  P --> W["Brush on solar panel"]
```

Thermal and electrical connections are different systems: the TEGs are side by side thermally and in series electrically. The panel contributes no electrical supply to the cleaner. The ground in the circuit is an electrical return; soil is a thermal reservoir.

## Software

`src/model.js` is the sole numerical implementation. It is usable as a browser global or a CommonJS module, so the CLI, tests and both HTML pages execute the same equations.

- `renderer.js`: small dependency-free perspective renderer, face lighting, depth ordering and picking.
- `scene.js`: desert installation, panel, brush, circuit components, thermal links, animated heat and component descriptions.
- `circuit.svg` + `circuit.js`: functional electrical diagram, live node labels, zoom/pan and original-sketch audit.
- `app.js`: time controls, condition inputs, charge history, inspector and data export.
- `shell.html` + `style.css`: shared responsive interface.
- `tools/build.py`: embeds sources into two independent offline HTML files.
- `tools/calculate.js`: repeats numerical predictions without a UI.
- `tools/fit_measurements.js`: derives a linear source fit from actual user-entered data.

The pages have no network calls or external font/JavaScript requirements. Exported run data are downloaded by the user's browser. The two pages maintain independent runs; opening both is not a live synchronized connection.

The renderer uses Canvas 2D to rasterize transformed 3D polygons. It supports orbit, zoom, pan and picking but is not a CAD renderer, photorealistic reconstruction or rigid-body physics engine. The 2D diagram is an electrical connectivity illustration tied to a behavioral energy model, not SPICE.
