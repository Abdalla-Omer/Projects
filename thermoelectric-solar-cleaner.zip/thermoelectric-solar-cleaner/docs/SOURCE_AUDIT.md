# Source and circuit audit

Inputs reviewed: the current project description, the uploaded GENS 101 report, `Final project circuit(1).txt`, and its screenshot. The original circuit text and image are preserved under `hardware/original/` without changing their bytes. The report is summarized in the evidence register instead of distributing its cover sheet.

## What the Falstad file contains

The text describes an ideal 3 V source, a 3 F storage-capacitor placeholder, a 1 mF load-side capacitor, a motor-like load element, an NPN, a P-channel MOSFET, and resistors of **30 kΩ, 4.7 kΩ, 1 kΩ and 100 kΩ**. It does not contain an actual TEG model, BQ25570 power stage, servo controller or three distinct supercapacitors.

Tracing the connections shows:

- 30 kΩ and 4.7 kΩ feed the NPN base from the storage rail and return.
- The NPN pulls the high-side MOSFET gate through the 1 kΩ resistor.
- The 100 kΩ resistor returns the MOSFET gate toward its source/storage rail.
- The load is on the switched side of the P-channel MOSFET.

This establishes a **voltage-dependent high-side switch**. No explicit regenerative feedback path from the switched output to the NPN sensing divider is visible, so a calibrated Schmitt window cannot be derived from these resistor values alone. Device gain, transistor junction voltage, leakage, load and transients can still create observed switching behavior; that is not sufficient to establish robust designed hysteresis.

A rough unloaded-divider estimate illustrates the issue:

\[
V_{base}\approx V_{cap}\frac{4.7}{30+4.7};\qquad
V_{cap,turn-on}\approx V_{BE}\frac{34.7}{4.7}.
\]

Assuming 0.65 V only for this rough calculation gives about **4.80 V**, not a precise or temperature-stable threshold. Base current loads the divider, and `VBE` is not a fixed 0.65 V reference. This equation supplies no independently chosen turn-off voltage. At 5.1 V the divider alone draws roughly 147 µA before base loading.

An ideal voltage source connected across a capacitor fixes its voltage; it cannot reproduce slow energy harvesting and boost charging. The original text's stored simulator state should not be interpreted as a measured charging trajectory.

## What the repository changes

1. Treat the three TEGs as a temperature-dependent source with explicit series resistance.
2. Separate open-circuit voltage, loaded input voltage, converter output power, stored voltage and stored energy.
3. Sum parallel capacitance while preserving the individual voltage rating.
4. Include the servo tester named in the report.
5. Use an explicit behavioral two-threshold controller for the system demonstration. Its defaults are assumptions, not results from the sketch.
6. Include startup, leakage, source limitations, capacitor ESR and a motor-start diagnostic.
7. Keep underground cooling labeled as a proposed extension rather than a tested part of the prototype.
8. Offer an **optional unbuilt revision** using the harvester's programmable `VBAT_OK` hysteresis in [REFERENCE_DESIGN](../hardware/REFERENCE_DESIGN.md).

Neither the 2D animation nor the preserved Falstad file is presented as a transistor-level verification of the completed device. Exact transistor identities, module configuration, capacitor ESR and servo/tester requirements remain necessary for a reproducible physical build.
