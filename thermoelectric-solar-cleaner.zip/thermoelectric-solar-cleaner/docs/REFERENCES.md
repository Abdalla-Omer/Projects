# Technical references and provenance

Sources checked during repository preparation, 2026-09-17. Manufacturer specifications are distinct from assumptions about the unmeasured project parts.

- [TI BQ25570 product page](https://www.ti.com/product/BQ25570): describes separate boost-charger/storage and buck-output functions, programmable battery-good hysteresis, and the buck's approximately 110 mA typical peak capability. A servo surge cannot be assigned that supply capability without checking its load.
- [TI BQ25570 datasheet, SLUSBH2G](https://www.ti.com/lit/gpn/BQ25570): §§6–7 and the TEG application. Grounds the input/storage limits, startup distinctions, source tracking, divider equations and `VBAT_OK` interface. The simulator's efficiency curves, currents and large-capacitor startup duration are **not** supplied by that document.
- [TI TIDA-00246 TEG reference design](https://www.ti.com/tool/TIDA-00246): additional manufacturer context for a complete TEG harvesting system, including treatment of negative temperature gradients. It is a separate reference design, not the user's prototype.
- [Pololu: Servo control interface in detail](https://www.pololu.com/blog/17/servo-control-interface-in-detail): explains servo signal timing and the distinction between position pulses and power. The actual tester/servo models and operating limits must still be identified.

Project-specific evidence comes from the uploaded GENS 101 report, circuit text, screenshot and current description. Their conflicts and missing measurements are recorded in [EVIDENCE](EVIDENCE.md) and [SOURCE_AUDIT](SOURCE_AUDIT.md). The report's literature-review statistics about regional soiling losses, water use and industry costs were not independently audited or reused as new factual claims in this repository.

First-principles capacitor energy, Thevenin-source and thermal-resistance equations are implemented openly in `src/model.js`. Matching a reported voltage range or burst duration with assumed values is not independent experimental validation.
