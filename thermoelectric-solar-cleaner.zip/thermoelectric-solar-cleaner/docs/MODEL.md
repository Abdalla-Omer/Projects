# Thermal, electrical and motion model

Both interactive pages and the command-line calculator execute the same `src/model.js`. Time, capacitance, energy, resistance and current use seconds, farads, joules, ohms and amperes internally. Values are estimates for an illustrative configuration until replaced with measurements.

## 1. Thermal network

Three TEGs sit **side by side between shared plates**. They are electrically in series and thermally in parallel. The model therefore uses one equivalent through-TEG thermal resistance, not three thermal resistances in series.

For fixed hot temperature `Th`, sink temperature `Ts`, equivalent TEG thermal resistance `Rθ,TEG`, and cold-side path resistance `Rθ,path`:

\[
\dot Q = \frac{T_h-T_s}{R_{\theta,TEG}+R_{\theta,path}},\qquad
T_c=T_h-\dot Q R_{\theta,TEG},\qquad
\Delta T_{TEG}=T_h-T_c.
\]

In the underground default, `Rθ,path = 0.2 + 1.0 + 1.0 + 1.0 = 3.2 K/W`: contact, two equivalent conductor sections, and the last spreader/soil contact. These values abstract a continuous heat path; three displayed spreaders do not represent three independently additive cooling sources. The equivalent through-TEG resistance is 2 K/W.

With `Th = 80 °C` and `Ts = 28 °C`, the modeled conductive flow is 10 W; TEG cold temperature is 60 °C and the across-TEG difference is 20 K. The displayed path nodes are 60 → 58 → 48 → 38 → 28 °C. Higher thermal resistance reduces heat flow and the temperature difference across the TEGs for fixed boundary temperatures.

The surface mode uses an assumed 40 °C surface reservoir and `0.2 + 4.2 K/W` path resistance. Its preset is a comparison, not a calibrated recreation of the heat-lamp test. Switching modes resets the run.

**Approximations:** instantaneous steady-state conduction; fixed hot and far-field sink temperatures; no convection/radiation balance, sunlight-to-hot-plate calculation, contact-pressure dependence, ground warm-up, moisture transport, Peltier term or Joule thermal feedback. Electrical extraction is small relative to the example conductive heat flow. Animated particles show direction, not measured heat packets or a travel-time solution. Below-ground parts are magnified for inspection and have no claimed real depth scale.

## 2. TEG source and harvester

The source is a linear Thevenin approximation at a chosen thermal condition:

\[
V_{OC}=N\alpha\max(\Delta T_{TEG},0),\quad R_s=N R_{module},\quad
V_{in}=f V_{OC},\quad I_{in}=\frac{V_{OC}-V_{in}}{R_s}.
\]

\[
P_{in}=V_{in}I_{in}=\frac{f(1-f)V_{OC}^{2}}{R_s}.
\]

At the linear-source maximum-power point, `f = 0.5`. Defaults are `N = 3`, `α = 0.045 V/K per module`, and **40 Ω effective resistance per module**. That resistance is an example effective source model, not a typical rating claimed for the unknown physical TEGs. The 2.70 V default open-circuit result does not establish its own available power.

Normal modeled output power is:

\[
P_h=\eta P_{in}\times0.984.
\]

The normal efficiency is an assumed 75%. The 0.984 factor approximates periodic sampling downtime. The nominal normal operating result is 1.35 V at 11.25 mA, or 15.1875 mW input and 11.2084 mW before storage losses.

For startup below an **approximate storage-boundary proxy of 1.8 V**, the model uses a 0.6 V input clamp, requires at least 0.7 V open circuit and 15 µW available under that clamp, and applies an assumed 20% startup efficiency. The startup input current is therefore different from the normal MPPT current. Both are shown correctly in the live telemetry.

This deliberately simple startup-energy penalty **does not model the BQ25570's separate VSTOR/VBAT nodes, internal switching or large-capacitor start/restart transients**. Actual first-charge time can differ substantially. Repeat-cycle estimates avoid this startup phase. Settings exceeding the model's 5.1 V open-circuit input or 400 mW normal input limit are rejected as valid harvesting conditions rather than silently clipped.

When the thermal polarity reverses, the model provides no usable harvested power. That does not mean an actual unprotected IC can accept a reversed TEG voltage; the hardware requires its own polarity analysis.

## 3. Parallel storage, voltage and energy

Three parallel capacitors share the same voltage:

\[
C_{eq}=C_1+C_2+C_3,\qquad E=\tfrac12 C_{eq}V^2,\qquad
E_{usable}=\tfrac12 C_{eq}(V_{on}^2-V_{off}^2).
\]

The latest-description default is `3 × 4 F = 12 F`, still rated **5.5 V**. The report-capacitance preset is `3 × 1 F = 3 F`. Neither parallel arrangement produces a 16.5 V rating.

At 12 F: 5.10 V stores 156.06 J, 4.60 V retains 126.96 J, and the usable window is 29.10 J. The rated-voltage energy of 181.5 J at 5.5 V is a mathematical comparison, not the charging target. The model stops at 5.2 V if the load is blocked. The interface's percentage meter is `E / E_at_ON`, not `V / V_ON`.

Leakage is approximated as constant current: 25 µA per capacitor plus 25 µA for always-on control. The latter is an illustrative low-power controller allowance, **not a reconstruction of the uploaded 30 kΩ / 4.7 kΩ divider**, whose current alone is about 147 µA at 5.1 V. Substitute measured total drain when estimating the original board.

## 4. Charge-time calculation

With the load off:

\[
\frac{dE}{dt}=P_h(V)-I_qV,\qquad
 t=\int_{V_a}^{V_b}\frac{C_{eq}V}{P_h(V)-I_qV}\,dV.
\]

`chargeTime()` evaluates this integral separately on each side of the approximate startup boundary. If net input power is zero or negative at any required voltage, the target is marked **not reachable**, rather than returning an arbitrary long time.

Ignoring losses gives the familiar comparison `t = C(Vb² − Va²)/(2P)`. This shortcut does not include startup or leakage and is not the headline default estimate. Numerical integration and the time-stepping engine independently agree on the default first-charge estimate within the test tolerance.

## 5. Hysteresis, burst and ESR

The behavioral gate switches on at 5.10 V and off at 4.60 V. It retains its previous state between them. These are assumed thresholds and are not calculated from the original transistor values. No transistor-level hysteresis is claimed.

While powered, the combined servo/tester draws an assumed 0.9 A for 0.25 s, then 0.4 A. There is an assumed 0.4 s boot period before brush movement. Load current is constant within these two phases; this is not a servo torque/current model.

\[
V_{load}=V_{cap}-I_LR_{ESR},\quad
P_{cap\to load}=V_{cap}I_L,\quad P_{ESR}=I_L^2R_{ESR}.
\]

Default total bank/wiring/switch ESR is 0.15 Ω. An assumed 4.5 V operating minimum is checked before startup and during operation. A failed start is latched as a model fault until reset or reconfiguration, avoiding a fabricated endless series of successful sweeps. That lockout is a simulator diagnostic, not an implemented hardware protection circuit.

During a burst:

\[
\frac{dE}{dt}=P_h(V)-I_qV-I_LV.
\]

The energy ledger records harvested energy, leakage, capacitor-side load energy, ESR heat, curtailed energy and remaining storage. ESR loss is part of capacitor-side load energy; it is not subtracted twice. With default settings the gate remains on about 14.77 s, and terminal voltage stays above the assumed minimum until the intended lower threshold.

## 6. Brush, dust and time acceleration

The servo sweeps through a modeled ±90° range with a 3 s half-stroke. The brush pivots at the panel's lower edge and has a finite radial reach. Deterministically placed dust samples are removed only when crossed by the actual angular sweep and within brush length. A configurable **85% removal per pass** and 2%/hour normalized redeposition rate are demonstration assumptions, not measured dust-removal efficiency, mass flux or recovered PV power. Unswept corners remain dirty.

The engine uses up to 20 s charging steps and 0.02 s active steps. Midpoint energy integration and threshold-event interpolation prevent time acceleration from skipping the hysteresis crossings. The **Next sweep** button numerically advances the clock to a start, with a seven-day limit. Auto slowdown makes a burst visible; it does not change physical model time or power. Separate pages start separate runs and share code, not live browser state.

## Exclusions

No transistor SPICE solution, PWM electronics waveform solver, three-dimensional soil solver, outdoor weather cycle, photovoltaic production model, dust abrasion model, torque/collision model, capacitor aging model, exact CAD, measured source I–V curve or validated startup circuit is included. The complete source and parameter file are provided so these assumptions can be inspected and replaced rather than mistaken for measured behavior.
