# Validation record

Checks executed during repository preparation on 2026-09-17. These validate the delivered software model and files, not the historical prototype or proposed underground installation.

| Check | Result and scope |
|---|---|
| Model tests | 14 tests pass: capacitor energy, thermal/electrical topology, increasing thermal resistance, no-gradient behavior, startup telemetry, charge/burst timing, energy balance, hysteresis, ESR failure, excessive leakage, input limits, capacitance scaling, timestep comparison and invalid configuration |
| Energy conservation | A 24-hour modeled run balances harvested, stored, leakage, load and curtailed energy to numerical precision; ESR is counted once |
| Time estimates | Independently evaluated voltage-domain charge integral agrees with the time-stepping engine within 0.15 s for the default first charge; burst-duration approximation agrees within 0.02 s |
| Standalone-page initialization | Actual inline scripts from both generated HTML files execute successfully with a DOM shim and real Canvas 2D rasterization |
| UI handlers | Both views pass next-sweep, zoom/reset/focus, capacitance preset, cooling-mode and no-temperature-gradient checks; 2D mode switching and 3D cutaway handlers execute |
| Dust/motion behavior | The numerical model crosses only reachable dust samples; a powered run visibly changes the rendered panel |
| JavaScript | Source files pass syntax checking |
| Visual review | 3D overview, active sweep and thermal close-up raster images inspected; both static circuit diagrams rendered and inspected |
| Source preservation | Original circuit text and screenshot copied byte-for-byte |
| Packaging | Standalone pages contain embedded assets; local documentation links and archive integrity checked |

The default 24-hour calculation produces 24 modeled power bursts under **unchanging assumed temperatures**. It is not a daily outdoor prediction: the model does not include night, weather or soil warm-up.

## Not verified here

- **Full browser integration:** no browser runtime was available for an end-to-end run. DOM/CSS layout, browser pointer capture, touch-device behavior and compatibility with particular browsers still require opening the HTML in a current browser. Canvas rendering and the real JavaScript handlers were exercised separately; a DOM shim is not a substitute for that check.
- **Physical electrical performance:** no actual source I–V curves, efficiency measurements, capacitance/ESR tests, transistor measurements, startup traces or motor-current captures were available.
- **Transistor-level simulation:** the behavior model implements two thresholds; it does not solve the original NPN/P-MOSFET network. The optional VBAT_OK revision is unbuilt and unvalidated.
- **Thermal deployment:** no actual buried conductor or soil thermal test was supplied. Geometric dimensions and depth are illustrative.
- **Dust-removal percentage / PV benefit:** animation parameters are not measured cleaning effectiveness or electrical generation recovery.
- **GitHub CI execution:** the workflow is included but no repository was pushed and no remote Actions run was claimed.

## Manual acceptance sequence

1. Download both HTML files to one folder and open each offline. Confirm no missing external resources and no browser-console errors.
2. In 3D, inspect the collector, capacitor bank and underground links. Orbit, pan, zoom and toggle heat, wiring and cutaway.
3. Press **Next sweep**. Verify the clock advances approximately 6.23 h with the defaults, voltage reaches 5.10 V and the brush moves at visible speed.
4. Verify the power window lasts approximately 14.8 s, storage falls to 4.60 V, and charging resumes. Observe dust left outside the brush reach.
5. Verify the 2D view shows the same model values and that its original-sketch tab explains its separate, uncalibrated topology.
6. Choose the 3 F preset and compare timing. Raise ESR to 1 Ω to test a blocked startup, or set hot and sink temperatures equal to prevent harvesting.
7. Use the bench procedure in [BUILD_AND_TEST](BUILD_AND_TEST.md) to replace assumptions before drawing hardware conclusions.
