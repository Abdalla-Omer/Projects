# Build and bench verification

The repository is complete as an inspectable demonstration and engineering record. A faithful physical rebuild still needs the original part identities and measured settings listed below. Do not replace them with guessed ratings merely because the animation runs.

## 1. Identify the actual build

Record the TEG model, dimensions, polarity and maximum temperature; capacitor capacitance, rated voltage, ESR and leakage; BQ25570 module schematic and resistor settings; transistor types; and servo/tester voltage and current requirements. Resolve whether the capacitors were 1 F or 4 F each. The model exposes both possibilities without claiming both were used together.

The report's tester was separately tested at 5.5 V and described as needing 5–6 V, then the integrated circuit was said to run at 4 V. Verify that behavior directly. A brief movement at an undervoltage is not a specification for repeatable operation.

## 2. Assemble the thermal collector

Place all three modules between shared hot/cold spreaders, with proper orientation, flat contact, paste and uniform clamping appropriate to their construction. Heat the plate under controlled conditions and record **both** TEG face temperatures. A 90 °C hot plate does not establish the across-TEG temperature difference by itself.

Start with the demonstrated single-heatsink arrangement. Treat buried conductors as a separate experimental extension. Measure soil temperature and the thermal path under sustained heat input; colder soil at depth is useful only if the connection can transfer sufficient heat. Fin surface area underground is constrained by soil contact rather than airflow.

## 3. Measure the source

At stable temperatures, record open-circuit voltage. Apply a known load and record loaded voltage/current without exceeding the TEG or instrument limits. Use multiple loads if possible to see whether a linear approximation is adequate. For one load point:

\[
R_s\approx(V_{OC}-V_L)/I_L,\qquad
\alpha\approx V_{OC}/[N(T_h-T_c)].
\]

Fill a copy of `analysis/measurements.example.json`. The fitting utility requires actual values and deliberately refuses the blank template:

```bash
node tools/fit_measurements.js local-measurements/teg-test.json
```

Repeat at relevant temperature differences. Fitting at one condition does not create a universal TEG datasheet.

## 4. Configure and test storage

Verify input polarity, the module's source-tracking setup, accessible storage node and charge ceiling. Connect the three capacitors in parallel with matching polarity. Use the actual module instructions and datasheet for decoupling and layout.

Measure bank capacitance, equivalent series resistance and self-discharge/always-on drain. A 5.5 V rating alone does not establish the pulse current a capacitor can provide. Measure the cold-start trajectory as well as the 4.60→5.10 V recharge window. The simple model's startup penalty cannot capture every VSTOR/VBAT transition on a large bank.

Disconnect the source and load as appropriate for leakage measurement. A first estimate is `I_loss ≈ −C ΔV/Δt`, using a region with reasonably constant drain. Include sensing circuits and instrument loading. Use a controlled resistor for discharge rather than a direct short.

## 5. Verify the gate and servo separately

Use a current-limited supply to ramp the gate input slowly in both directions. Record the upper/lower switching voltages and their dependence on temperature and load. If the original circuit has no reproducible hysteresis, document that result; do not assign a simulated threshold pair to the hardware.

Power the servo tester and servo within their rated range. Verify automatic sweep mode, startup delay, mechanical endpoints and brush contact force. Record average current and peak/inrush current with adequate bandwidth. A hobby servo needs position pulses as well as power.

Estimate startup droop with `ΔV ≈ I_peak R_ESR`, then measure it. Confirm the lowest switched-rail voltage stays within both tester and servo requirements throughout the useful burst. Keep motor-current returns and sensitive voltage sensing arranged to limit unintended ground drops.

## 6. Integrated acceptance test

1. Begin with a discharged or documented initial capacitor voltage, an unloaded brush, and recorded temperatures.
2. Log source voltage/current, storage voltage, gate state and load voltage throughout charge and one complete burst.
3. Confirm the switch turns off and stays off until a new upper-threshold crossing; check for chatter and stalled-motor drain.
4. Repeat at least three cycles at stable thermal conditions. Record first-charge and recharge times separately.
5. Add a known initial dust condition and inspect the actual swept area. Photographs can support a visual result; quantitative removal needs a defined mass or optical measurement method.
6. Compare measured curves with `analysis/default-results.json` only after replacing the unknown defaults. Report any remaining error instead of tuning the animation alone.

## Outdoor extension

Evaluate soil heat accumulation, seasonal temperature reversal, water ingress, corrosion, abrasive dust, cable strain, moving-part exposure and component temperature limits before outdoor use. The class prototype and this renderer do not establish long-term performance in a Middle Eastern installation. The panel itself is not used as the cleaner's electrical energy source in this architecture.
