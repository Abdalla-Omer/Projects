# Evidence and parameter register

There are three evidence classes: **user description**, **submitted report/sketch**, and **model assumption**. None of the modeled current, resistance or timing traces is a measurement from the classroom build.

## Source reconciliation

| Item | Evidence | Repository treatment |
|---|---|---|
| Project and course | Thermoelectric Solar Panel Cleaner, Fall 2025; Khalifa University GENS 101 report | Preserve project identity; no claim of deployment |
| Three electrically series TEGs | Description and report agree | Three-source model; physically side by side |
| Hot/cold construction | Report: metal plates, paste, three TEGs, one heatsink | Modeled collector follows that arrangement |
| Underground cooling | User describes it as an idea not implemented in the prototype | Default 3D cutaway is explicitly a proposed installation |
| TEG voltage | Report: 2.4–3.3 V with hot side near 90 °C; latest summary: 2–3 V | Report as observed voltage; no matching current, cold-side temperature or load trace supplied |
| Capacitance | Latest: 3 × 4 F; report: 3 × 1 F; Falstad: equivalent 3 F | Latest 12 F default, report-capacitance 3 F preset |
| Capacitor rating | Both descriptions say 5.5 V | Remains 5.5 V in parallel; charge target below rating |
| Storage/activation voltage | Latest: 5–5.5 V; report: 4 V | Use assumed 5.10/4.60 V hysteresis and 5.20 V ceiling; do not claim these were measured |
| Switching devices | Latest: NPN/PNP; report and circuit: NPN/P-channel MOSFET | Diagram follows report/sketch and explains discrepancy |
| Servo control | Report explicitly includes a servo tester | Tester shown, included in load estimate |
| Servo tester supply | Report says 5–6 V during separate testing, then describes operation at 4 V | Unresolved compatibility issue; no assertion of reliable rated operation at 4 V |
| Sweep duration | Report: approximately 10–15 s power window | Preserve as reported; model's similar result is not a fitted or validated reproduction |
| Charge duration | Latest: hours; report: long time and elsewhere minutes | No single historical charge-time value asserted |
| Dust removal | User says most visible dust; report includes a 90% design objective | No measured removal percentage or recovered PV power claimed |

## Model defaults that need measurement

| Quantity | Default | Role |
|---|---:|---|
| Hot / underground sink | 80 / 28 °C | Imposed thermal boundary conditions |
| Surface sink | 40 °C | Comparison boundary |
| Aggregate TEG thermal resistance | 2 K/W | Three side-by-side thermal paths represented as one |
| Underground contact / links / soil path | 0.2 + 1 + 1 + 1 K/W | Temperature drop along proposed conduction route |
| Surface path | 0.2 + 4.2 K/W | Uncalibrated comparison |
| Seebeck coefficient per module | 45 mV/K | Converts actual across-TEG ΔT to voltage |
| Effective resistance of three-source string | 120 Ω | Determines available current and power; not inferred from voltage alone |
| Normal / startup efficiency | 75% / 20% | Simplified conversion model |
| Leakage per capacitor | 25 µA | Storage loss |
| Always-on control current | 25 µA | Illustrative controller; not the original resistor network's calculated current |
| Total bank + wire + switch ESR | 0.15 Ω | Instantaneous motor-start droop and heating |
| Servo + tester average / startup current | 0.40 / 0.90 A | Burst power draw |
| Startup pulse / tester boot | 0.25 / 0.40 s | Startup energy and movement delay |
| Minimum operating load voltage | 4.5 V | Placeholder requiring actual servo/tester validation |
| Gate on / off / storage ceiling | 5.10 / 4.60 / 5.20 V | Behavioral control settings |
| Half-stroke duration | 3 s | Illustrative sweeper speed under load |
| Dust removed per crossed sample per pass | 85% | Visual demonstration assumption |
| Dust redeposition coefficient | 2%/hour of the unfilled fraction | Visual demonstration assumption |

Values can be changed in `analysis/default-parameters.json` for the CLI or `src/model.js` for a rebuilt UI. Frequently varied ones are exposed directly in both pages. The 3 F selector changes capacitance only; the report's other uncertain conditions are not silently substituted.
