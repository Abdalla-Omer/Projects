# Hardware bill of materials

This is a component and specification checklist, not a shopping list with invented original part numbers. The uploaded material does not identify exact TEG, capacitor, transistor, module-board or servo variants.

| Item | Quantity | Known role / selection requirement |
|---|---:|---|
| Thermoelectric generator | 3 | Electrical series; same orientation between common hot/cold plates. Measure I–V at intended temperatures. Confirm hot-side and assembly limits. |
| Hot absorber plates | Report: 2 | Spread heat over all TEGs; size and material not specified. The 3D model combines them visually. |
| Cold spreader / heatsink | Prototype: 1 | Maintain cold-side contact. Do not equate ambient air temperature with loaded TEG cold temperature. |
| Thermal interface material | As required | Thin, even interfaces with appropriate mechanical clamping |
| Underground conductors / spreaders | Concept only | Continuous heat path with measured contact and soil resistance; not merely disconnected buried fins |
| BQ25570 module | 1 | Verify board schematic, VBAT/storage access, MPPT configuration and adjustable overvoltage thresholds |
| Supercapacitors | 3 | Latest description: 4 F, 5.5 V each; report: 1 F, 5.5 V each. Parallel, matching polarity. Measure leakage, ESR and pulse-current capability. |
| NPN small-signal transistor | 1 | Report/sketch gate driver; exact device and gain unreported |
| P-channel MOSFET | 1 | Report/sketch load switch. Choose low on-resistance at the available gate voltage, adequate surge current and correct source/drain orientation. |
| Resistor network | As built | Original sketch: 30 kΩ, 4.7 kΩ, 1 kΩ, 100 kΩ; these alone do not establish verified two-threshold hysteresis |
| Servo tester / pulse source | 1 | Named in report; supports automatic back-and-forth mode and the actual available supply range |
| Microservo | 1 | Confirm running/stall current, required voltage, torque and travel before attaching brush |
| Printed wiper/brush | 1 assembly | Soft contact surface, limited force and no abrasive trapped sand; geometry must suit the actual panel |
| Solar-panel specimen and stand | 1 each | Report: 30° tilt; not an electrical power source for the cleaner |
| Load fuse / power disconnect | As required | Size from actual wiring and motor surge. Supercapacitors can deliver much more current than the TEG source. |
| Connectors, wire, test points | As required | Separate motor-current return from sensitive sensing traces; all electrical grounds join intentionally |
| Input reverse-polarity / transient provision | Verify design | Required analysis if thermal gradient reverses or leads can be reversed; voltage drop changes startup behavior |
| Local decoupling | Per board/load requirements | Follow harvester-module layout and servo tester requirements; the sketch's 1 mF is not a universal design value |

The module's small regulated buck output should not be assumed capable of the servo surge. The reference system draws the brief load from the storage node through an external rated switch. No PCB layout or exact fabricated mechanical dimensions are claimed by the schematic.
