# Optional revision: defined hysteresis using VBAT_OK

**Status: design proposal, not the tested 2025 circuit and not a bench-validated replacement.** The supplied report describes discrete switching; this option addresses the missing calibrated feedback/threshold definition without pretending it existed in the original sketch.

Use the BQ25570's programmable battery-good signal as the hysteresis decision, then use a suitable low-current interface to operate an external P-channel MOSFET on the capacitor-side load rail. Keep the servo tester after that switch. This preserves slow energy collection and brief autonomous bursts while defining separate voltage thresholds. The IC signal is a control output, not a motor supply. See the [TI product description](https://www.ti.com/product/BQ25570).

## Nominal threshold calculation

Using the names and equations in TI's [BQ25570 datasheet, §7.3.3–7.3.4](https://www.ti.com/lit/gpn/BQ25570), a 1.21 V nominal bias and 13 MΩ divider totals give these ideal, unrounded values:

| Setting | Target | Ideal resistor values |
|---|---:|---|
| Storage overvoltage | 5.20 V | ROV1 = 4.537500 MΩ; ROV2 = 8.462500 MΩ |
| Load on / load off | 5.10 / 4.60 V | ROK1 = 3.084314 MΩ; ROK2 = 8.641176 MΩ; ROK3 = 1.274510 MΩ |

The corresponding nominal checks are:

\[
V_{OV}=1.5V_{BIAS}(1+R_{OV2}/R_{OV1}),
\]
\[
V_{OFF}=V_{BIAS}(1+R_{OK2}/R_{OK1}),\quad
V_{ON}=V_{BIAS}[1+(R_{OK2}+R_{OK3})/R_{OK1}].
\]

These are ratios for a design calculation, **not a bill of standard resistor values**. Use the actual datasheet pin network, module schematic and permitted divider connections; do not assume the three-resistor network is an arbitrary external ladder. Recalculate after choosing available values. Check reference, resistor, temperature and leakage tolerances against both the load window and the 5.5 V component limits. Existing module resistors change the effective network and may need removal rather than parallel additions.

## Driver interface and power path

A candidate NPN interface keeps the original project's transistor roles: control high turns the NPN on, the NPN pulls the P-MOSFET gate low, and a source-to-gate resistor turns the MOSFET off when the NPN releases it. Include base-current limiting and a base-emitter return. Respect the control pin's small available current; size the pull-up current and base drive together rather than copying a power-transistor example.

The original 100 kΩ gate pull-up and 1 kΩ series gate resistor can be starting points for analysis, but no base-resistor value, NPN gain, gate leakage or MOSFET identity has been verified for this project. Select and bench-test the interface at voltage/temperature extremes. A suitable low-leakage buffer is another option if a reliable NPN interface cannot fit the control-current budget.

Connect capacitor positive → appropriately selected fuse → P-MOSFET source, drain → servo/tester positive, and all returns to common ground. Use a switch with an on-resistance specified at the actual negative gate-to-source voltage and with adequate surge capability. Include its resistance in the total ESR calculation. Confirm the module's storage terminal is directly accessible and that motor bursts do not pass through an unsuitable internal switch or its low-current buck rail.

## Acceptance criteria before replacing the original circuit

- Slowly ramp a current-limited substitute storage supply up and down. Record the actual enable/disable points and verify distinct hysteresis with no load.
- Repeat with the tester, unloaded servo and then representative brush load. Observe voltage at the capacitor, switched rail and gate during startup.
- Verify the gate defaults off at startup, on a disconnected control input and below the intended window.
- Measure total always-on drain and substitute that value in the model. A nominally low-power harvester does not make a resistor-heavy external trigger low power.
- Confirm charge-ceiling tolerances, thermal limits, polarity protection, motor surge and fuse behavior.

The current HTML's controller block represents the **function** of measured hysteresis. It does not claim to solve this optional driver or the original discrete circuit at transistor level.
