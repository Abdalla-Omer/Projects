# Wiring and thermal assembly

![System circuit](system-circuit.svg)

The 2D HTML provides zoom and live node values. This static SVG is a module-level reference, not an internally detailed BQ25570 schematic or a verified reproduction of the original threshold network.

## Electrical connections

| From | To | Purpose |
|---|---|---|
| TEG 1 positive | TEG 2 negative | First series junction |
| TEG 2 positive | TEG 3 negative | Second series junction |
| TEG 1 negative | Harvester input return | Negative end of string |
| TEG 3 positive | Harvester input positive | Positive end, after any required polarity/transient protection |
| Harvester VBAT / designated storage positive | C1+, C2+, C3+ | Parallel capacitor charging |
| Storage return | C1−, C2−, C3− | Common capacitor negative |
| Capacitor positive bus | Fuse, then Q2 source | Burst-current supply to high-side P-channel switch |
| Q2 drain | Servo tester V+ and servo V+ | Switched load rail |
| Q2 gate | Gate pull-up to source and NPN driver collector through gate resistor | Off by pull-up; on when driver pulls low |
| NPN emitter | Common return | Gate-drive return |
| Hysteresis output | Suitable NPN base interface | Enable only above upper threshold; retain state to lower threshold |
| Servo tester signal | Servo signal lead | Position commands; power switching alone is insufficient |
| Servo tester ground and servo ground | Common return | Reference for supply and signal |

Identify pins from the actual module and transistor datasheets. `VBAT`, `VSTOR` and `VOUT` are different IC nodes; a board terminal labeled `OUT` cannot be assumed to be the capacitor bus. The main reference draws motor bursts directly from the capacitor-side rail, avoiding the small buck output and unnecessary internal storage-switch voltage drop. Confirm that this access is provided on your module.

The functional controller block is deliberately explicit: the supplied transistor sketch does not define verified separate switching thresholds. Keep the original topology for documentation, or implement and validate a chosen hysteresis design. The optional [VBAT_OK revision](REFERENCE_DESIGN.md) is one candidate.

## Thermal connections

| Thermal contact | Prototype | Proposed underground extension |
|---|---|---|
| Heat source → hot plate | Heat lamps | Sun-heated absorber |
| Hot plate → TEG hot faces | Paste and clamping | Same function |
| TEG cold faces → cold plate/heatsink | One heatsink | Same collector interface |
| Cold assembly → sink | Calm supporting surface / local dissipation as described | Continuous thermal links to a cooler soil reservoir |
| Added underground stages | Not demonstrated | Contacts and conductors in series add resistance |

All three TEGs should bridge the same hot and cold plates. Their **electrical series wiring does not mean stacking them thermally one after another**. Buried fins exchange heat with soil; the airflow behavior of an ordinary heatsink does not transfer unchanged underground. Verify the full conductive route and soil temperature under sustained heat flow.

## Before applying power

Verify capacitor polarity and ratings, program the harvester's charge ceiling, confirm switch orientation and current capacity, and check the servo/tester voltage range. Keep sensitive electronics and capacitors away from the heated absorber. Use a controlled discharge resistor for stored energy; do not short the capacitor bank. Start tests with a current-limited supply and an unloaded servo before connecting the complete thermal source.

A reversed thermal gradient can reverse TEG polarity. The simulator's zero-harvest rule is not a substitute for actual reverse-voltage protection. Account for protection losses in measured charge-time estimates.
