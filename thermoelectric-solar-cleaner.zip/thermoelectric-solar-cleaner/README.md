# Thermoelectric Solar Panel Cleaner

**Fall 2025 · Grand Challenges course project · Circuit design and energy harvesting**

A waterless solar-panel cleaning concept that harvests a temperature difference through three series-connected thermoelectric generators, stores energy in parallel supercapacitors, and briefly powers a servo-driven brush when enough energy is available.

This repository contains a complete **offline demonstration, calculation model, hardware documentation and source audit**. It distinguishes the reported classroom prototype from the proposed underground cooling system. It is not a validated PCB, a measured digital twin, or a claim that the underground installation was built.

![Proposed desert installation with visible underground thermal links](docs/images/installation-preview.png)

## Open the two interactive views

- **[3D installation](docs/solar-cleaner-3d.html):** a tilted dusty panel, servo and brush, TEG stack, harvester, capacitor bank, load gate, servo tester and a soil cutaway. Orbit, zoom, inspect components and follow heat into the ground.
- **[2D circuit explorer](docs/solar-cleaner-circuit.html):** clearly wired series TEGs, parallel storage, high-side load switching, control and servo pulse generation. Includes a separate view auditing the uploaded transistor sketch.

Download the HTML files and open them in a browser. Each file contains everything it needs and works without a server, internet access, installation or external assets. Keep both in the same folder to use their navigation links. GitHub's repository viewer displays HTML source; use the downloaded files or GitHub Pages for an interactive view.

### Try the cycle

1. Watch the hot/cold temperatures, TEG open-circuit voltage, actual modeled input voltage and storage voltage separately.
2. Choose a time multiplier or press **Next sweep**. This advances the energy calculation to the threshold; it does not insert free energy.
3. At **5.10 V**, the load gate turns on. The servo tester drives the brush while capacitor voltage falls.
4. At **4.60 V**, the gate disconnects the load and charging resumes. By default, each burst is shown at real speed so it remains visible during fast-forward.
5. Change temperature, cooling arrangement, source resistance, leakage, ESR or current draw. Parameters reset the run for a consistent comparison. Try high ESR to see a failed motor start.
6. Switch between **three 4 F capacitors** and the report's **three 1 F capacitors**. This comparison changes capacitance only; it does not silently reproduce the report's separate 4 V operating claim.

## Example calculations, not measured performance

The default model assumes 80 °C on the hot plate, 28 °C at the ground reservoir, a total 3.2 K/W cold-side path, 120 Ω effective series source resistance, 75% normal conversion efficiency, 0.40 A running load and 0.15 Ω bank/wiring ESR. These missing values are **unmeasured examples**, not recovered specifications of the original components.

| Default calculation | Result |
|---|---:|
| Across-TEG temperature difference | 20 K |
| Three-TEG open-circuit voltage | 2.70 V |
| Normal MPPT voltage / source current | 1.35 V / 11.25 mA |
| Normal modeled power into storage | 11.21 mW before storage losses |
| Parallel bank | 12 F, still rated 5.5 V |
| Stored energy at 5.10 V | 156.06 J |
| Usable energy from 5.10 to 4.60 V | 29.10 J |
| First charge from empty | about 6.23 h, including approximate startup |
| Recharge from 4.60 to 5.10 V | about 45.2 min |
| Powered burst | about 14.8 s |

The first charge and repeat recharge are different: a burst only uses part of the stored energy. Voltage alone cannot establish either time; source impedance, conversion losses, leakage and load current matter. See [MODEL](docs/MODEL.md), the [assumption register](docs/EVIDENCE.md), and the reproducible [default results](analysis/default-results.json).

## What the supplied sources establish

The report describes three side-by-side TEGs wired electrically in series, two heated plates, thermal paste, one heatsink, a BQ25570, a parallel capacitor bank, a transistor-controlled power gate, a servo tester and a servo with a printed wiper. It reports heat-lamp tests at a hot-side temperature of 90 °C, approximately 2.4–3.3 V from the TEG string, and intermittent cleaning.

Some details conflict across the supplied material:

| Detail | Latest description | Course report / sketch |
|---|---|---|
| Capacitors | 3 × 4 F, 5.5 V | Report: 3 × 1 F; sketch: 3 F equivalent |
| Trigger devices | NPN / PNP | Report and sketch: NPN + P-channel MOSFET |
| Activation voltage | Around 5–5.5 V | Report: 4 V, despite a stated 5–6 V tester requirement |
| Cooling | Proposed links underground | Demonstrated single surface heatsink |
| Recharge duration | Several hours | Report also says “several minutes”; no timed trace supplied |

The original sketch is preserved unchanged under [`hardware/original/`](hardware/original/). The live model uses explicit, adjustable assumptions instead of hiding these discrepancies. See [SOURCE_AUDIT](docs/SOURCE_AUDIT.md).

## Repository map

| Path | Contents |
|---|---|
| `docs/solar-cleaner-3d.html` | Standalone 3D simulation |
| `docs/solar-cleaner-circuit.html` | Standalone 2D circuit explorer |
| `src/` | Shared model, renderer, circuit, controls and page templates |
| `hardware/system-circuit.svg` | Editable module-level schematic |
| `hardware/original-switch-audit.svg` | Reconstructed sketch topology and limitations |
| `hardware/BOM.md` | Component roles and selection requirements |
| `hardware/WIRING.md` | Power, signal and thermal connection tables |
| `hardware/REFERENCE_DESIGN.md` | Optional, unbuilt VBAT_OK-based hysteresis revision |
| `docs/MODEL.md` | Equations, defaults, interpretation and exclusions |
| `docs/BUILD_AND_TEST.md` | Bench setup, measurement and acceptance procedure |
| `docs/VALIDATION.md` | Automated checks and remaining verification |
| `analysis/` | Parameter file, calculated results and blank measurement template |
| `tools/` | Build, calculation, source-fit and schematic export scripts |
| `tests/` | Physics/control and standalone-page checks |

No microcontroller firmware is required by the reported build: the **servo tester generates the position pulses**, and the analog power gate decides when the load receives energy.

## Reproduce the calculations and build

Node.js 18+ and Python 3.9+ are sufficient for the model and build; the delivered pages need neither.

```bash
node tests/model.test.js
node tools/calculate.js --hours 24
node tools/calculate.js --config analysis/default-parameters.json --hours 24 --out analysis/default-results.json
python tools/export_schematics.py
python tools/build.py
```

To derive a source model from measurements, fill the appropriate fields in a copy of `analysis/measurements.example.json`, then run:

```bash
node tools/fit_measurements.js local-measurements/teg-test.json
```

Optional Canvas raster checks use `npm install` and `npm run test:render`. They execute the actual page scripts with a DOM shim and inspectable images, not a full browser. Included CI checks the energy model, source syntax and reproducibility of the standalone build.

To host on GitHub Pages, serve the repository's `/docs` directory and visit `/solar-cleaner-3d.html` or `/solar-cleaner-circuit.html`. This package has not been pushed or published.

## Hardware boundaries

The BQ25570's boost charger, storage node and buck output are different functions. Do not assume its small buck output can supply a motor surge. The diagrams route the burst from storage through an appropriately rated external switch. Verify the actual module's pin labels, regulation settings, capacitor ESR, servo/tester voltage range and trigger thresholds before assembly.

The simulator uses a 5.2 V charge ceiling rather than targeting the components' 5.5 V rating. Full tolerances still need checking. The underground design needs a real thermal conductor and characterized soil contact; adding heatsinks in series adds resistance and does not guarantee a colder TEG.

## License

New software and documentation are MIT licensed; see [LICENSE](LICENSE). Preserved course-project materials in `hardware/original/` retain their original rights. Technical references and measurement limitations are listed in [REFERENCES](docs/REFERENCES.md) and [VALIDATION](docs/VALIDATION.md).
