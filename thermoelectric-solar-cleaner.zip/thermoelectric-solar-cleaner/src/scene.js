(function(root){'use strict';
const {Scene,clamp}=root.Offline3D,rad=d=>d*Math.PI/180;
class DesertScene{
 constructor(canvas,sim){this.sim=sim;this.s=new Scene(canvas);this.labels=true;this.heat=true;this.wiring=true;this.cutaway=true;const s=this.s,g=s.root;this.info={panel:['Solar panel & brush','The PV panel is the surface being cleaned. It does not supply energy to this cleaner. The servo sweeps a semicircular brush path; corners outside its reach retain dust.'],teg:['Three TEGs','Electrically in series, thermally side by side. Each has the same hot and cold plates. More series voltage does not imply more free energy.'],hot:['Hot absorber plate','An imposed temperature boundary representing sun or a heat lamp. Solar irradiance, convection and plate warm-up are not solved.'],cold:['Cold plate and top heatsink','Heat crosses the TEGs into this plate. The modeled temperature difference across the TEGs determines their open-circuit voltage.'],underground:['Underground thermal link · proposed','A visible concept extension beyond the single-heatsink classroom prototype. Connected conductors and soil contacts add thermal resistance; buried fins do not act like fins in open air.'],ground:['Cooler ground reservoir','Assumed fixed far-field soil temperature. Soil drying, seasonal changes and accumulated heat can weaken this sink; transient soil heating is not modeled.'],bq:['BQ25570 harvesting module','Runs a boost charger at an assumed TEG maximum-power operating point. The lower-current buck output is not used as the servo power rail.'],caps:['Parallel supercapacitor bank','Three capacitors share one voltage. Capacitance adds; voltage rating does not. Stored energy is ½CV². ESR and leakage are included as assumptions.'],trigger:['Hysteretic load gate','Behavioral turn-on and turn-off thresholds. The uploaded NPN + P-MOSFET sketch does not establish a calibrated Schmitt hysteresis window; see the circuit audit.'],tester:['Servo tester · pulse generator','Powers up with the motor and generates servo position commands. Merely switching supply voltage does not command a hobby servo to sweep.'],servo:['Microservo and printed extension','Average current, startup surge and minimum load voltage are adjustable assumptions. The simulation can block a start when ESR causes excessive voltage droop.']};
 // Terrain is a cutaway exhibit: top tiles leave the foreground trench open.
 this.groundPolys=[{p:[[-11,0,-9],[11,0,-9],[11,0,7],[-1.9,0,7],[-1.9,0,.3],[-9.2,0,.3],[-9.2,0,7],[-11,0,7]],color:'#d8ba87'},{p:[[-9.2,-5.5,.3],[-1.9,-5.5,.3],[-1.9,-5.5,7],[-9.2,-5.5,7]],color:'#927057'},{p:[[-9.2,0,.3],[-1.9,0,.3],[-1.9,-5.5,.3],[-9.2,-5.5,.3]],color:'#b39167'},{p:[[-1.9,0,.3],[-1.9,0,7],[-1.9,-5.5,7],[-1.9,-5.5,.3]],color:'#c19d70'}];
 const panel=this.panel=s.group(g,[3,2.45,-1.5],[rad(30),0,0]);
 // Individual cells avoid a large painter-sorted backing face covering the dust.
 for(let x=0;x<6;x++)for(let z=0;z<4;z++){let cx=-3.75+x*1.5,cz=-2.25+z*1.5;s.box(panel,[cx,0,cz],[1.43,.12,1.43],(x+z)%2?'#315c76':'#2d536d','panel');for(let i=0;i<3;i++)s.box(panel,[cx-.45+i*.45,.065,cz],[.015,.008,1.4],'#94aebe','panel');}
 for(const x of[-4.59,4.59])s.box(panel,[x,0,0],[.12,.24,6.18],'#c6d0d0','panel');for(const z of[-3.09,3.09])s.box(panel,[0,0,z],[9.3,.24,.12],'#c6d0d0','panel');
 for(const x of[-.7,6.7]){s.box(g,[x,.55,.9],[.15,1.1,.18],'#8b9998','panel');s.box(g,[x,1.9,-3.9],[.15,3.8,.18],'#8b9998','panel');s.box(g,[x,.1,-1.5],[.6,.2,6],'#aaa999','panel');}
 const servo=this.servo=s.group(panel,[0,-.32,3.15]);s.box(servo,[0,0,0],[.65,.54,.85],'#33669a','servo');s.box(servo,[0,.27,0],[.82,.10,1.02],'#243e52','servo');s.cylinder(servo,[0,.32,0],[0,.45,0],.15,'#d7c99e','servo');
 const wiper=this.wiper=s.group(panel,[0,.15,3.15]);s.cylinder(wiper,[0,0,0],[0,.17,0],.14,'#c4b38b','servo');s.box(wiper,[0,.08,-3.17],[.11,.14,6.35],'#d5d8d0','servo');s.box(wiper,[0,.025,-3.17],[.26,.10,6.35],'#273e3a','panel');for(let z=-.1;z>=-6.2;z-=.25)s.box(wiper,[0,-.025,z],[.32,.065,.025],'#586454','panel');
 s.label('SOLAR PANEL · 30°',panel,[3,.2,-2],'panel',[8,-30]);s.label('SERVO + BRUSH',servo,[0,.5,0],'servo',[58,-16]);
 // Heat collector: three adjacent TEG sandwiches, electrical series jumpers.
 const collector=this.collector=s.group(g,[-5.65,0,.65]);
 s.box(collector,[0,.72,0],[3.7,.22,1.7],'#8d9e9b','cold');
 for(let j=0;j<3;j++){let x=(j-1)*1.12;s.box(collector,[x,1.02,0],[1.02,.28,1.26],'#e9e9d9','teg');s.box(collector,[x,1.22,0],[1.06,.07,1.3],'#bb6f46','hot');s.label('TEG '+(j+1),collector,[x,1.32,0],'teg',[0,-18-j%2*20]);}
 s.box(collector,[0,1.44,0],[3.65,.3,1.75],'#b57147','hot');
 for(let k=0;k<9;k++)s.box(collector,[-1.6+k*.4,.3,0],[.10,.68,1.65],'#97aaa9','cold');
 s.label(()=>`HOT ${this.sim.src.thermal.hot.toFixed(0)}°C`,collector,[0,1.7,0],'hot',[-70,-55]);s.label(()=>`COLD ${this.sim.src.thermal.cold.toFixed(0)}°C`,collector,[0,.7,.9],'cold',[-38,24]);
 for(let i=0;i<2;i++)s.wire([()=>collector.world([-.65+i*1.12,1,.68]),()=>collector.world([-.48+i*1.12,1.16,.97]),()=>collector.world([-.07+i*1.12,1,.68])],'#b9654e','teg',.045);
 // Conduction links and buried spreaders. Hollow trench exposes the proposed path.
 const underground=this.underground=s.group(collector);
 s.cylinder(underground,[0,.3,0],[0,-1.2,1.25],.22,'#a37650','underground');
 s.cylinder(underground,[0,-1.2,1.25],[0,-2.9,2.8],.22,'#96916c','underground');
 s.cylinder(underground,[0,-2.9,2.8],[0,-4.6,4.45],.22,'#6d9794','underground');
 this.finGroups=[];for(let j=0;j<3;j++){const fg=s.group(underground,[0,-1.2-j*1.7,1.25+j*1.6]);this.finGroups.push(fg);s.box(fg,[0,0,0],[2.6,.2,1.45],['#ac8862','#8b9a83','#6c9290'][j],'underground');for(let i=0;i<8;i++)s.box(fg,[-1.05+i*.30,-.30,0],[.06,.6,1.4],['#b69472','#99a88f','#81a4a0'][j],'underground');s.label(()=>{const th=this.sim.src.thermal;return `LINK ${j+1} · ${(th.nodes[j+2]??th.sink).toFixed(0)}°C`;},fg,[1.3,0,0],'underground',[61,0]);}
 s.label(()=>`SOIL ${this.sim.src.thermal.sink.toFixed(0)}°C`,underground,[0,-5.1,4.45],'ground',[-5,22]);
 // Electronics rack outside the hot plate, with exposed modules and parallel bank.
 const rack=s.group(g,[1,.38,4.8]);s.box(rack,[0,0,0],[7.7,.18,2.1],'#c6b797','ground');
 const bq=this.bq=s.group(rack,[-2.7,.21,0]);s.box(bq,[0,0,0],[1.55,.1,1.55],'#347c70','bq');s.box(bq,[0,.14,0],[.35,.2,.35],'#243a3e','bq');s.box(bq,[-.45,.19,.15],[.35,.25,.4],'#777f74','bq');for(let i=0;i<5;i++)s.box(bq,[-.6+i*.28,.13,-.65],[.09,.14,.09],'#c4c8b1','bq');
 s.label('BQ25570',bq,[0,.3,0],'bq',[-15,-31]);
 const caps=this.caps=s.group(rack,[-.7,.15,0]);for(let j=0;j<3;j++){s.cylinder(caps,[j*.68,.07,0],[j*.68,.85,0],.27,'#536e67','caps',14);s.cylinder(caps,[j*.68,.85,0],[j*.68,.9,0],.26,'#d2d5bc','caps',14);s.box(caps,[j*.68,.91,0],[.3,.015,.025],'#59716d','caps');}
 s.label(()=>`3 × ${this.sim.p.capEach} F · PARALLEL`,caps,[.68,1,0],'caps',[0,-16]);
 const gate=this.gate=s.group(rack,[1.65,.18,0]);s.box(gate,[0,0,0],[1,.08,1.45],'#bc8d54','trigger');s.box(gate,[.18,.25,0],[.35,.45,.25],'#26373b','trigger');s.cylinder(gate,[-.27,.08,-.25],[-.27,.36,-.25],.13,'#304447','trigger');for(let j=0;j<3;j++)s.box(gate,[-.3+j*.26,.1,.4],[.18,.12,.1],'#d6c3a1','trigger');s.label('LOAD GATE',gate,[0,.4,0],'trigger',[25,-28]);
 const tester=this.tester=s.group(rack,[2.95,.18,0]);s.box(tester,[0,0,0],[1,.10,1.4],'#407e74','tester');s.cylinder(tester,[0,.05,0],[0,.35,0],.27,'#5b7584','tester');s.label('SERVO TESTER',tester,[0,.4,0],'tester',[25,27]);
 const end=(group,p)=>()=>group.world(p);
 s.wire([end(collector,[1.65,1,.75]),[-3.5,.5,2.3],end(bq,[-.7,.12,.4])],'#bc6950','bq');s.wire([end(collector,[-1.65,1,.75]),[-7.2,.4,0],[-3.2,.3,3.8],end(bq,[-.7,.12,-.4])],'#6d7375','bq');
 // Two visible buses connect all capacitor positive and negative terminals.
 s.wire([end(bq,[.7,.12,.4]),end(caps,[-.2,.07,.35]),end(caps,[1.56,.07,.35]),end(gate,[-.45,.12,.35])],'#bc6950','caps');s.wire([end(bq,[.7,.12,-.4]),end(caps,[-.2,.07,-.35]),end(caps,[1.56,.07,-.35]),end(tester,[.45,.12,-.5])],'#6d7375','caps');
 for(let j=0;j<3;j++){s.wire([end(caps,[j*.68,.07,.35]),end(caps,[j*.68,.05,.13])],'#bc6950','caps',.045);s.wire([end(caps,[j*.68,.07,-.35]),end(caps,[j*.68,.05,-.13])],'#6d7375','caps',.045);}
 s.wire([end(gate,[.45,.12,.35]),end(tester,[-.45,.12,.35]),[5.4,.65,2.5],end(servo,[.3,0,.3])],'#bc6950','servo');s.wire([end(tester,[.45,.12,-.5]),[5.8,.5,2.3],end(servo,[.3,0,.1])],'#6d7375','servo');s.wire([end(tester,[0,.12,.65]),[6.1,.7,2.1],end(servo,[.3,0,-.1])],'#d7ab52','tester');
 // Small distant panel silhouettes and rocks give context without obscuring the assembly.
 for(let i=0;i<4;i++){let q=s.group(g,[i*3-4,.9,-7.8],[rad(30),0,0]);s.box(q,[0,0,0],[2.25,.08,1.35],'#6b8084','panel');}
 for(let i=0;i<12;i++){let x=-10+(i*4.71)%21,z=-6+(i*2.41)%12;if(x>-9&&x<-2&&z>.2)continue;s.box(g,[x,.08,z],[.2+(i%3)*.12,.16,.23],'#b8996a','ground');}
 this.pointer=null;this.drag=null;this.onSelect=()=>{};const c=canvas;
 c.addEventListener('pointerdown',e=>{this.drag={x:e.clientX,y:e.clientY,pan:e.shiftKey||e.button===2,moved:0};c.setPointerCapture(e.pointerId);});
 c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();this.pointer=[e.clientX-r.left,e.clientY-r.top];if(this.drag){const dx=e.clientX-this.drag.x,dy=e.clientY-this.drag.y;this.drag.moved+=Math.abs(dx)+Math.abs(dy);this.drag.x=e.clientX;this.drag.y=e.clientY;if(this.drag.pan){s.camera.target=s.camera.target.map((v,i)=>v-dx*s.right[i]*s.camera.distance/s.focal+dy*s.up[i]*s.camera.distance/s.focal);}else{s.camera.yaw-=dx*.007;s.camera.pitch=clamp(s.camera.pitch+dy*.006,-.1,1.35);}}});
 c.addEventListener('pointerup',()=>{if(this.drag&&this.drag.moved<5&&this.pointer){let id=s.pick(...this.pointer);if(id)this.onSelect(id);}this.drag=null;});c.addEventListener('pointercancel',()=>this.drag=null);c.addEventListener('pointerleave',()=>this.pointer=null);c.addEventListener('dblclick',()=>{const id=this.pointer&&s.pick(...this.pointer);if(id)this.focus(id);});c.addEventListener('contextmenu',e=>e.preventDefault());c.addEventListener('wheel',e=>{e.preventDefault();s.camera.distance=clamp(s.camera.distance*Math.exp(e.deltaY*.001),8,55);},{passive:false});
 c.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')s.camera.yaw-=.1;else if(e.key==='ArrowRight')s.camera.yaw+=.1;else if(e.key==='ArrowUp')s.camera.pitch=clamp(s.camera.pitch+.08,-.1,1.35);else if(e.key==='ArrowDown')s.camera.pitch=clamp(s.camera.pitch-.08,-.1,1.35);else if(e.key==='+'||e.key==='=')this.zoom(.9);else if(e.key==='-')this.zoom(1/.9);else return;e.preventDefault();});
 }
 zoom(f){this.s.camera.distance=clamp(this.s.camera.distance*f,8,55);}
 focus(id){if(id==='underground'&&this.sim.p.cooling==='surface')id='teg';const camera=this.s.camera;if(id==='overview'){Object.assign(camera,{yaw:.46,pitch:.36,distance:26,target:[0,-.3,0]});return;}const configs={panel:[[3,1.7,-1],16,.65],servo:[[3,1.7,-1],16,.65],underground:[[-5.5,-1.8,2.4],16,.20],teg:[[-5.5,.3,1],13,.36],hot:[[-5.5,.3,1],13,.36],cold:[[-5.5,.3,1],13,.36],ground:[[-5.5,-1.8,2.4],16,.20],bq:[[1,.7,4.8],13,.95],caps:[[1,.7,4.8],13,.95],trigger:[[1,.7,4.8],13,.95],tester:[[1,.7,4.8],13,.95]};if(configs[id]){let[t,d,p]=configs[id];Object.assign(camera,{target:t,distance:d,pitch:p,yaw:.15});}}
 render(realSeconds=0){const s=this.s,p=this.sim.p;this.underground.visible=p.cooling==='underground'&&this.cutaway;this.wiper.r[1]=this.sim.angle;s.begin();const c=s.ctx,gradient=c.createLinearGradient(0,0,0,s.h);gradient.addColorStop(0,'#edf0e3');gradient.addColorStop(.50,'#eddbb7');gradient.addColorStop(1,'#e4c59a');c.fillStyle=gradient;c.fillRect(0,0,s.w,s.h);
 // Sun and a horizon are scene atmosphere, not a solar irradiance calculation.
 c.fillStyle='#fff5c1';c.beginPath();c.arc(s.w*.85,70,28,0,Math.PI*2);c.fill();
 for(const [i,poly] of this.groundPolys.entries())if(i===0||(this.cutaway&&p.cooling==='underground'))s.poly(poly.p,poly.color);s.paint(false);s.faces=[];
 if(!this.cutaway||p.cooling==='surface'){s.poly([[-9.2,0,.3],[-1.9,0,.3],[-1.9,0,7],[-9.2,0,7]],'#d8ba87');s.paint(false);s.faces=[];}
 if(this.cutaway&&p.cooling==='underground')for(let y=-1;y>=-5;y--)s.line([-9.1,y,.31],[-2,y,.31],'#9b784f',.022);
 for(const w of s.lines)w.visible=this.wiring;
 const pn=this.panel.world([0,1,0]),po=this.panel.world();const above=pn.reduce((sum,v,i)=>sum+(v-po[i])*(s.eye[i]-po[i]),0)>0;for(const m of s.meshes)m.overlay=(m.g===this.wiper&&above)?1:0;
 s.geometry();
 if(!this.cutaway){/* Keep below-ground parts out of the visible assembly. */s.faces=s.faces.filter(f=>f.id!=='underground');}
 for(const d of this.sim.dust)if(d.amount>.01)s.point(this.panel.world([d.x,.105,d.z]),d.size,'#d9b06c','panel',clamp(d.amount,.02,1));
 if(this.heat){const q=this.sim.src.thermal.heat;if(q>0){const path=p.cooling==='underground'&&this.cutaway?[[0,1.6,0],[0,.8,0],[0,-1.2,1.25],[0,-2.9,2.8],[0,-4.6,4.45]]:[[0,1.6,0],[0,.8,0],[1.4,.25,0]];for(let j=0;j<path.length-1;j++){let a=this.collector.world(path[j]),b=this.collector.world(path[j+1]);s.line(a,b,['#ce633f','#c28043','#b39058','#548e86'][j],.045);for(let i=0;i<5;i++){let t=(realSeconds*.38+i/5)%1,pt=a.map((v,k)=>v+(b[k]-v)*t);s.point(pt,.075,['#e17847','#d99446','#c3a262','#70aba0'][j],null,.85);}}for(let i=0;i<4;i++){const a=this.collector.world([-1.5+i,4,-2]),b=this.collector.world([-1.5+i,1.7,0]);s.line(a,b,'#d8a34c',.025,null,.7);}}}
 s.paint();if(this.labels)s.drawLabels();
 return this.pointer?s.pick(...this.pointer):null;
 }
}
root.DesertScene=DesertScene;
})(typeof window!=='undefined'?window:globalThis);
