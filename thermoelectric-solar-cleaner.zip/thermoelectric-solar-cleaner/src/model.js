/* Shared engineering model for browser, CLI and tests. SI units internally.
   Unknown prototype parameters are explicitly assumptions; see docs/MODEL.md.
   No transistor SPICE solver, soil transient model or measured efficiency curve. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CleanerModel=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const DEFAULTS=Object.freeze({hotC:80,groundC:28,surfaceC:40,cooling:'underground',rTegThermal:2,rContact:.2,rLink1:1,rLink2:1,rSoil:1,rSurface:4.2,tegCount:3,seebeck:.045,rPerTeg:40,mppt:.5,eta:.75,startEta:.20,startBoundary:1.8,capCount:3,capEach:4,capRating:5.5,vOn:5.1,vOff:4.6,vMax:5.2,leakPerCap:25e-6,controlCurrent:25e-6,loadCurrent:.4,startCurrent:.9,startSeconds:.25,bootSeconds:.4,loadMin:4.5,esr:.15,halfStroke:3,brushLength:6.35,dustRemoval:.85,depositionPerHour:.02});
function parameters(overrides={}){for(const key of Object.keys(overrides))if(!Object.prototype.hasOwnProperty.call(DEFAULTS,key))throw Error('Unknown parameter: '+key);const p={...DEFAULTS,...overrides};for(const [key,value]of Object.entries(p))if(typeof DEFAULTS[key]==='number'&&(!Number.isFinite(value)||value<0))throw Error('Invalid parameter: '+key);if(!(p.vOff>2&&p.vOff<p.vOn&&p.vOn<p.vMax&&p.vMax<p.capRating&&p.capRating<=5.5))throw Error('Require 2 V < off < on < charge ceiling < capacitor rating ≤ 5.5 V');if(!Number.isInteger(p.tegCount)||!Number.isInteger(p.capCount)||p.dustRemoval>1||p.brushLength<=0)throw Error('Invalid component count or dust/brush parameter');if(!['surface','underground'].includes(p.cooling))throw Error('Unknown cooling mode');if(!(p.rPerTeg>0&&p.rTegThermal>0&&p.mppt>0&&p.mppt<1&&p.eta>0&&p.eta<=1&&p.startEta>0&&p.startEta<=1&&p.capEach>0&&p.capCount>0&&p.tegCount>0&&p.halfStroke>0&&p.loadCurrent>0))throw Error('Invalid positive parameter or efficiency');return p;}
function thermal(p){const sink=p.cooling==='underground'?p.groundC:p.surfaceC;const path=p.cooling==='underground'?[p.rContact,p.rLink1,p.rLink2,p.rSoil]:[p.rContact,p.rSurface];const heat=(p.hotC-sink)/(p.rTegThermal+path.reduce((a,b)=>a+b,0));const cold=p.hotC-heat*p.rTegThermal;let t=cold;const nodes=[p.hotC,cold];for(const r of path){t-=heat*r;nodes.push(t);}return {hot:p.hotC,cold,sink,heat,delta:p.hotC-cold,nodes,pathResistance:path.reduce((a,b)=>a+b,0)};}
function source(p){const th=thermal(p),voc=p.tegCount*p.seebeck*Math.max(0,th.delta),resistance=p.tegCount*p.rPerTeg,vin=p.mppt*voc,current=(voc-vin)/resistance,power=vin*current;let reason='';if(th.delta<=0)reason='No useful temperature difference';else if(voc>5.1)reason='TEG open-circuit voltage exceeds 5.1 V model limit';else if(power>.4)reason='Input exceeds 400 mW recommended-power model limit';return {thermal:th,voc,perTeg:voc/p.tegCount,vin,current,power,resistance,reason};}
function harvested(p,s,v){if(s.reason)return 0;if(v<p.startBoundary){const pin=.6*Math.max(0,s.voc-.6)/s.resistance;return s.voc>=.7&&pin>=15e-6?pin*p.startEta:0;}return s.vin>=.1?s.power*p.eta*.984:0;}
function capacitance(p){return p.capCount*p.capEach;}
function energy(p,v){return .5*capacitance(p)*v*v;}
function voltage(p,e){return Math.sqrt(Math.max(0,2*e/capacitance(p)));}
function leakage(p){return p.capCount*p.leakPerCap+p.controlCurrent;}
// Numerical quadrature; split at the approximate cold-start boundary.
function chargeTime(p,from=0,to=p.vOn){if(from>=to)return 0;const s=source(p),cuts=[from,...(from<p.startBoundary&&to>p.startBoundary?[p.startBoundary]:[]),to];let result=0;for(let k=0;k<cuts.length-1;k++){const a=cuts[k],b=cuts[k+1],n=600,h=(b-a)/n;for(let j=0;j<n;j++){const v=a+(j+.5)*h,net=harvested(p,s,v)-leakage(p)*v;if(net<=0)return Infinity;result+=capacitance(p)*v*h/net;}}return result;}
function sweepTime(p){const s=source(p);if(p.vOn-p.startCurrent*p.esr<p.loadMin)return 0;const endpoint=Math.max(p.vOff,p.loadMin+p.loadCurrent*p.esr);if(endpoint>=p.vOn)return 0;const net=p.loadCurrent+leakage(p)-harvested(p,s,(p.vOn+endpoint)/2)/((p.vOn+endpoint)/2);if(net<=0)return Infinity;return Math.max(0,(capacitance(p)*(p.vOn-endpoint)-(p.startCurrent-p.loadCurrent)*p.startSeconds)/net);}
function rng(seed){return ()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};}
class Simulation{
 constructor(overrides={}){this.p=parameters(overrides);this.reset();}
 reset(){this.time=0;this.e=0;this.on=false;this.fault='';this.bursts=0;this.strokes=0;this.onTime=0;this.totalOn=0;this.angle=-Math.PI/2;this.direction=1;this.harvestedJ=0;this.leakJ=0;this.loadJ=0;this.esrJ=0;this.curtailedJ=0;this.events=[];this.history=[];this.lastSample=-Infinity;const random=rng(240925);this.dust=Array.from({length:210},()=>{let x=(random()-.5)*8.8,z=(random()-.5)*5.8;return {x,z,amount:1,size:.022+random()*.032,r:Math.hypot(x,z-3.15),a:Math.atan2(-x,3.15-z)};});this.record();}
 configure(overrides){this.p=parameters({...this.p,...overrides});this.reset();}
 get v(){return voltage(this.p,this.e);}
 get src(){return source(this.p);}
 get current(){return this.on?(this.onTime<this.p.startSeconds?this.p.startCurrent:this.p.loadCurrent):0;}
 get terminal(){return this.on?Math.max(0,this.v-this.current*this.p.esr):0;}
 event(type){this.events.push({type,time:this.time,voltage:this.v});if(this.events.length>100)this.events.shift();}
 record(){if(this.time-this.lastSample>=30||this.on||this.history.length===0){this.history.push([this.time,this.v,this.on?1:0]);if(this.history.length>1400)this.history=this.history.filter((_,i)=>i%2===0);this.lastSample=this.time;}}
 enable(){if(this.v-this.p.startCurrent*this.p.esr<this.p.loadMin){this.fault='Start blocked: ESR drop leaves insufficient load voltage';this.event('brownout');return;}this.on=true;this.onTime=0;this.bursts++;this.event('load-on');}
 disable(reason='load-off'){this.on=false;this.event(reason);this.record();}
 advance(seconds,{stopOnStart=false}={}){
  if(!Number.isFinite(seconds)||seconds<0||seconds>7*86400)throw Error('Advance must be between 0 and seven days');
  let remain=seconds,used=0,iterations=0;const p=this.p,s=this.src,eq=energy(p,p.vMax),eOn=energy(p,p.vOn),eOff=energy(p,p.vOff),iq=leakage(p);
  while(remain>1e-8){if(++iterations>2000000)throw Error('Simulation step budget exceeded');
   if(!this.on&&!this.fault&&this.e>=eOn-1e-9){this.enable();if(this.on&&stopOnStart)break;}
   if(this.on&&(this.e<=eOff+1e-9||this.terminal<p.loadMin)){this.disable(this.terminal<p.loadMin?'load-undervoltage':'load-off');if(this.e>eOff)this.fault='Load undervoltage before the hysteresis cutoff';}
   let dt=Math.min(remain,this.on?.02:20);if(this.on){if(this.onTime<p.startSeconds)dt=Math.min(dt,p.startSeconds-this.onTime);if(this.onTime<p.bootSeconds)dt=Math.min(dt,p.bootSeconds-this.onTime);}
   const old=this.e,v0=this.v,i=this.current;
   let ph=harvested(p,s,v0),net=ph-(iq+i)*v0,mid=Math.max(0,old+.5*net*dt),vm=voltage(p,mid);
   // Do not integrate across the cold-start boundary with the wrong efficiency.
   const startE=energy(p,p.startBoundary);
   if(old<startE-1e-9&&old+net*dt>startE){dt=(startE-old)/Math.max(net,1e-12);vm=voltage(p,(old+startE)/2);}
   ph=harvested(p,s,Math.min(vm,old<startE?Math.max(0,p.startBoundary-1e-10):vm));net=ph-(iq+i)*vm;
   let next=old+net*dt,hitStart=false,hitOff=false;
   if(!this.on&&!this.fault&&next>=eOn&&net>0){dt=(eOn-old)/net;next=eOn;hitStart=true;}
   else if(this.on&&next<=eOff&&net<0){dt=(eOff-old)/net;next=eOff;hitOff=true;}
   if(dt<1e-10){dt=Math.min(remain,.001);next=old+net*dt;}
   const pLeak=iq*vm,pLoad=i*vm,raw=next;
   this.e=clamp(next,0,eq);this.harvestedJ+=ph*dt;this.leakJ+=pLeak*dt;this.loadJ+=pLoad*dt;this.esrJ+=i*i*p.esr*dt;this.curtailedJ+=Math.max(0,raw-eq);
   this.time+=dt;used+=dt;remain-=dt;
   const deposit=1-Math.exp(-p.depositionPerHour*dt/3600);for(const d of this.dust)d.amount+=(1-d.amount)*deposit;
   if(this.on){this.totalOn+=dt;this.onTime+=dt;if(this.onTime>p.bootSeconds){let previous=this.angle;this.angle+=this.direction*Math.PI/p.halfStroke*dt;if(this.angle>=Math.PI/2){this.angle=Math.PI-this.angle;this.direction=-1;this.strokes++;}else if(this.angle<=-Math.PI/2){this.angle=-Math.PI-this.angle;this.direction=1;this.strokes++;}const lo=Math.min(previous,this.angle),hi=Math.max(previous,this.angle);for(const d of this.dust)if(d.r<=p.brushLength&&d.a>=lo&&d.a<=hi)d.amount*=1-p.dustRemoval;}}
   this.record();
   if(hitOff)this.disable();
   if(hitStart){this.enable();this.record();if(this.on&&stopOnStart)break;}
  }
  return used;
 }
 snapshot(){const s=this.src,p=this.p,ph=harvested(p,s,this.v),dust=this.dust.reduce((t,d)=>t+d.amount,0)/this.dust.length;const inputVoltage=ph>0?(this.v<p.startBoundary?.6:s.vin):s.voc,inputCurrent=ph>0?Math.max(0,(s.voc-inputVoltage)/s.resistance):0;return {inputVoltage,inputCurrent,time:this.time,v:this.v,energy:this.e,capacitance:capacitance(p),on:this.on,fault:this.fault,bursts:this.bursts,strokes:this.strokes,angle:this.angle,dust,dustRemoved:1-dust,src:s,harvest:ph,chargeCurrent:this.v>.05?ph/this.v:0,terminal:this.terminal,current:this.current,firstCharge:chargeTime(p),recharge:chargeTime(p,p.vOff),remaining:chargeTime(p,this.v),sweepEstimate:sweepTime(p),usableJ:energy(p,p.vOn)-energy(p,p.vOff),balanceError:this.harvestedJ-this.leakJ-this.loadJ-this.curtailedJ-this.e,esrLoss:this.esrJ,status:this.fault?'LOAD BLOCKED':this.on?'SWEEPING':s.reason?'NO HARVEST':ph<=leakage(p)*this.v?'NOT CHARGING':this.v<p.startBoundary?'COLD START':'CHARGING'};}
}
return {DEFAULTS,parameters,thermal,source,harvested,capacitance,energy,voltage,leakage,chargeTime,sweepTime,Simulation};
});
