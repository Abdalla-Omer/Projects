'use strict';
const assert=require('node:assert/strict'),M=require('../src/model.js');let passed=0;
function test(name,fn){fn();passed++;console.log('PASS',name);}
function near(a,b,tol=1e-8){assert.ok(Math.abs(a-b)<tol,`${a} vs ${b}`);}
test('Parallel capacitors add capacitance, not voltage',()=>{near(M.capacitance(M.DEFAULTS),12);near(M.energy(M.DEFAULTS,5),150);near(M.energy(M.DEFAULTS,5.5),181.5);near(M.capacitance(M.parameters({capEach:1})),3);});
test('Thermal series resistance and electrical series TEGs',()=>{const s=M.source(M.DEFAULTS);near(s.thermal.heat,10);near(s.thermal.delta,20);near(s.thermal.cold,60);near(s.voc,2.7);near(s.vin,1.35);near(s.current,.01125);near(s.power,.0151875);near(s.resistance,120);});
test('Adding thermal resistance worsens output at fixed boundary temperatures',()=>{const p=M.parameters({rLink1:3});assert.ok(M.source(p).voc<M.source(M.DEFAULTS).voc);});
test('No useful gradient gives no harvest or motion',()=>{const s=new M.Simulation({hotC:28});s.advance(86400);near(s.v,0);assert.equal(s.bursts,0);assert.equal(s.snapshot().firstCharge,Infinity);});
test('Cold-start telemetry matches the startup input clamp',()=>{const s=new M.Simulation();near(s.snapshot().inputVoltage,.6);near(s.snapshot().inputCurrent,(2.7-.6)/120);});
test('Default empty charge and burst match independent timing estimates',()=>{const s=new M.Simulation();s.advance(86400,{stopOnStart:true});assert.equal(s.on,true);near(s.v,5.1);near(s.time,M.chargeTime(s.p),.15);const start=s.time;s.advance(25);const off=s.events.find(e=>e.type==='load-off');near(off.time-start,M.sweepTime(s.p),.02);assert.equal(s.on,false);assert.ok(s.strokes>=4);assert.ok(s.snapshot().dustRemoved>.8);});
test('Energy ledger conserves harvested energy across charge, sweep and recharge',()=>{const s=new M.Simulation();s.advance(86400);assert.ok(s.bursts>2);assert.ok(Math.abs(s.snapshot().balanceError)<1e-7);assert.ok(s.loadJ>s.esrJ);assert.ok(s.e>=0&&s.v<=s.p.vMax);});
test('Hysteresis switches only at upper and lower voltage thresholds',()=>{const s=new M.Simulation();s.advance(86400);for(const e of s.events){if(e.type==='load-on')near(e.voltage,s.p.vOn);if(e.type==='load-off')near(e.voltage,s.p.vOff);}assert.ok(s.events.length>=4);});
test('Excess ESR blocks startup instead of fake sweeps or chatter',()=>{const s=new M.Simulation({esr:1});s.advance(86400);assert.ok(s.fault);assert.equal(s.bursts,0);assert.equal(s.strokes,0);});
test('High leakage can make the upper threshold unreachable',()=>{const p=M.parameters({leakPerCap:.002});assert.equal(M.chargeTime(p),Infinity);const s=new M.Simulation(p);s.advance(86400);assert.equal(s.bursts,0);});
test('Oversized TEG voltage is identified and not treated as valid charging',()=>{const p=M.parameters({hotC:100,groundC:15,rLink1:.1,rLink2:.1,rSoil:.1});assert.ok(M.source(p).voc>5.1);assert.equal(M.chargeTime(p),Infinity);});
test('A 3 F bank reduces charge time and usable energy by four',()=>{const p=M.parameters({capEach:1,leakPerCap:0,controlCurrent:0}),q=M.parameters({capEach:4,leakPerCap:0,controlCurrent:0});near(M.chargeTime(q)/M.chargeTime(p),4,1e-8);});
test('Time-step chunking retains timing and energy accuracy',()=>{const a=new M.Simulation(),b=new M.Simulation();a.advance(5000);for(let i=0;i<500;i++)b.advance(10);near(a.v,b.v,.00001);});
test('Invalid settings and unsafe threshold ordering are rejected',()=>{for(const p of[{vMax:5.5},{vOff:5.2},{eta:1.3},{rPerTeg:0},{capEach:-1}])assert.throws(()=>M.parameters(p));});
console.log(`${passed} model tests passed.`);
