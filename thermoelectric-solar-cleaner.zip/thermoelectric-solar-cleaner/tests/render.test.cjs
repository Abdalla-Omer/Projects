/* Executes the actual standalone-page scripts with a real Canvas rasterizer.
   This is a DOM shim, not full browser/CSS verification. */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const deps=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, {createCanvas}=require(deps?deps+'/@napi-rs/canvas':'@napi-rs/canvas');
const root=path.resolve(__dirname,'..'),out=process.argv[2]||path.join(root,'docs/images');fs.mkdirSync(out,{recursive:true});
class Element{constructor(id){this.id=id;this.style={};this.attrs={};this.listeners={};this.textContent='';this.value='';this.checked=true;this.disabled=false;}setAttribute(k,v){this.attrs[k]=v;}getAttribute(k){return this.attrs[k];}addEventListener(k,f){this.listeners[k]=f;}setPointerCapture(){}getBoundingClientRect(){return {left:0,top:0,width:this.clientWidth||1100,height:this.clientHeight||710};}click(){if(this.onclick)this.onclick();}}
for(const mode of['3d','2d']){
 const file=mode==='3d'?'solar-cleaner-3d.html':'solar-cleaner-circuit.html',html=fs.readFileSync(root+'/docs/'+file,'utf8'),elements={};for(const m of html.matchAll(/id="([^"]+)"/g))elements[m[1]]=new Element(m[1]);
 for(const[id,w,h]of[['scene',1100,710],['chart',1060,108]])if(elements[id]){const e=elements[id],native=createCanvas(w,h);e.clientWidth=w;e.clientHeight=h;e.native=native;e.getContext=()=>native.getContext('2d');Object.defineProperty(e,'width',{get:()=>native.width,set:v=>native.width=v});Object.defineProperty(e,'height',{get:()=>native.height,set:v=>native.height=v});}
 let errors=[];const context={Math,JSON,Blob:class{},URL:{createObjectURL:()=>'',revokeObjectURL(){}},setTimeout(){},devicePixelRatio:1,performance:{now:()=>0},requestAnimationFrame(){},addEventListener(){},console:{error:e=>errors.push(e)},document:{body:{dataset:{view:mode}},getElementById:id=>{assert.ok(elements[id],'Missing DOM element '+id);return elements[id];},createElement:()=>new Element('dynamic')}};context.window=context;vm.createContext(context);for(const m of html.matchAll(/<script>([\s\S]*?)<\/script>/g))vm.runInContext(m[1],context,{filename:file});const app=context.SolarCleaner;assert.ok(app);assert.equal(app.snapshot().status,'COLD START');
 if(mode==='3d'){fs.writeFileSync(path.join(out,'installation-preview.png'),elements.scene.native.toBuffer('image/png'));}
 // The button advances simulated time through actual energy integration.
 elements.next.onclick();assert.equal(app.sim.on,true);assert.ok(app.sim.time>22000);app.sim.advance(4);app.refresh();app.render();assert.ok(app.snapshot().dustRemoved>0);
 if(mode==='3d')fs.writeFileSync(path.join(out,'sweeping-preview.png'),elements.scene.native.toBuffer('image/png'));
 elements['zoom-in'].onclick();elements.overview.onclick();elements.component.onchange({target:{value:'caps'}});elements.focus.onclick();
 if(mode==='3d'){elements['heat-view'].onclick();app.render();fs.writeFileSync(path.join(out,'thermal-cutaway-preview.png'),elements.scene.native.toBuffer('image/png'));elements['cutaway'].onchange({target:{checked:false}});app.render();elements['cutaway'].onchange({target:{checked:true}});}
 else{elements['original-view'].onclick();assert.equal(elements['original-circuit'].style.display,'');elements['system-view'].onclick();assert.equal(elements['original-circuit'].style.display,'none');}
 elements['bank-select'].onchange({target:{value:'1'}});assert.equal(app.sim.p.capEach,1);assert.equal(app.sim.time,0);elements['cooling'].onchange({target:{value:'surface'}});assert.equal(app.sim.p.cooling,'surface');elements['hot'].oninput({target:{value:'40'}});assert.equal(app.snapshot().src.thermal.delta,0);assert.equal(elements.next.disabled,true);
 assert.equal(errors.length,0);console.log('PASS',mode,'page initialization, next-sweep, modeled dust, controls, presets and no-gradient state');
}
