# Water alarm PCB

A KiCad water-contact alarm using a 2N7000 MOSFET and an active buzzer. This repository contains my uploaded CAD files, five KiCad screenshots, and a browser demonstration of the intended alarm behavior.

## Intended operation

Two external probes connect to J2. Water bridging the probes forms a conductive path that raises Q1's gate voltage. Q1 then allows current through the active buzzer. With dry probes, R1 pulls the gate toward ground. C1 is connected between gate and ground. The PCB stays dry; only the probe tips contact the water.

| Reference | Component shown in the uploaded schematic |
| --- | --- |
| Q1 | 2N7000 N-channel MOSFET |
| BZ1 | AI-1223-TWT-5V-R active buzzer, intended for a 5 V supply |
| R1 | 10 MΩ gate pull-down |
| C1 | 1 nF gate-to-ground capacitor |
| J1 | DC power input |
| J2 | Two-terminal connection for the water probes |

## Interactive demonstration

Open [docs/index.html](docs/index.html) in a browser and click **Run demo**. Water rises toward the probes. At the illustrated high-water line, the visual alarm turns on and a buzzer tone sounds. Click **Lower water** to bring the water below the probes and stop the alarm. You can also change the water level manually, pause, reset, or mute the sound.

The page works offline and needs no installation or downloaded libraries. Browser audio starts after a button click. The alarm tone is synthesized by the browser; it is not a recording of a tested board.

**This is an illustration of the intended behavior, not an electrical simulation or a hardware test.** The 85% line is a chosen position in the animation, not a measured circuit threshold. Actual water contact depends on probe placement and water conductivity. No hardware measurements or completed physical tests are claimed.

## Files

- `hardware/` — uploaded KiCad project, schematic, PCB, and local view settings; file contents unchanged.
- `docs/images/` — the five supplied screenshots; file contents unchanged.
- `docs/index.html` — self-contained website with the interactive alarm and screenshot gallery.

Open `hardware/Water alarm PCB(1).kicad_pro` in KiCad. Temporary `.lck` files are omitted.

**Current CAD snapshot:** the schematic names the active buzzer and references `WaterAlarm:ActiveBuzzer_D12_P7.6`. That custom library was not included in this upload. The PCB still embeds the earlier TDK buzzer footprint with 5 mm pin spacing. Its footprint needs updating to match the selected part before assembly. Other manufacturing checks remain necessary; these files are presented as supplied, not as a certified fabrication release.

## Publish the website on GitHub Pages

1. Create a GitHub repository and upload the contents of this folder, including `docs/` and `hardware/`.
2. Open **Settings → Pages**.
3. Select **Deploy from a branch**, choose your branch (usually `main`) and the **`/docs`** folder, then save.
4. GitHub will show the website address after deployment.

See [GitHub's Pages setup instructions](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) for details.

## Supplied screenshots

![Uploaded KiCad schematic](docs/images/schematic.png)

![Uploaded PCB layout](docs/images/pcb-layout.png)

![Uploaded KiCad top view](docs/images/pcb-top.png)

![Uploaded KiCad front view](docs/images/pcb-front.png)

![Uploaded KiCad perspective view](docs/images/pcb-perspective.png)
